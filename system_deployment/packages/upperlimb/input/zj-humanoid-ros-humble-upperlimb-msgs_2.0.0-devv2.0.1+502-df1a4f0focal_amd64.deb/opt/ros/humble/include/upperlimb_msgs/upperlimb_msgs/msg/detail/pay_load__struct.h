﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/PayLoad.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'cog'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/PayLoad in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__PayLoad
{
  /// 负载质量  unit:kg
  double mass;
  /// 负载质心位置（x,y,z）（末端坐标系为参考） unit:m
  geometry_msgs__msg__Point cog;
} upperlimb_msgs__msg__PayLoad;

// Struct for a sequence of upperlimb_msgs__msg__PayLoad.
typedef struct upperlimb_msgs__msg__PayLoad__Sequence
{
  upperlimb_msgs__msg__PayLoad * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__PayLoad__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__STRUCT_H_
