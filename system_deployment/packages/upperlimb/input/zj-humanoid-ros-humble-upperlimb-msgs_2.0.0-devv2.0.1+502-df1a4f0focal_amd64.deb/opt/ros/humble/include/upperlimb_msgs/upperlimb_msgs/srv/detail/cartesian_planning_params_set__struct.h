﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/CartesianPlanningParamsSet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_SET__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_SET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'joint_mask'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/CartesianPlanningParamsSet in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__CartesianPlanningParamsSet_Request
{
  /// 机器人身体部位。 可以通过8421码进行叠加。参考 ArmTypeEnum.msg (Add on 1.4.0+)
  int8_t arm_type;
  /// 指定部位参与笛卡尔空间规划的机器人身体部位关节开关数组. true为参与, false为不参与, 数组长度需要与arm_type对应的关节数量一致 (Add on 1.4.0+)
  rosidl_runtime_c__boolean__Sequence joint_mask;
} upperlimb_msgs__srv__CartesianPlanningParamsSet_Request;

// Struct for a sequence of upperlimb_msgs__srv__CartesianPlanningParamsSet_Request.
typedef struct upperlimb_msgs__srv__CartesianPlanningParamsSet_Request__Sequence
{
  upperlimb_msgs__srv__CartesianPlanningParamsSet_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__CartesianPlanningParamsSet_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/CartesianPlanningParamsSet in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__CartesianPlanningParamsSet_Response
{
  bool success;
  rosidl_runtime_c__String message;
} upperlimb_msgs__srv__CartesianPlanningParamsSet_Response;

// Struct for a sequence of upperlimb_msgs__srv__CartesianPlanningParamsSet_Response.
typedef struct upperlimb_msgs__srv__CartesianPlanningParamsSet_Response__Sequence
{
  upperlimb_msgs__srv__CartesianPlanningParamsSet_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__CartesianPlanningParamsSet_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_SET__STRUCT_H_
