// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/IsSingular.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__IS_SINGULAR__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__IS_SINGULAR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/is_singular__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_IsSingular_Request_arm_type
{
public:
  explicit Init_IsSingular_Request_arm_type(::upperlimb_msgs::srv::IsSingular_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::IsSingular_Request arm_type(::upperlimb_msgs::srv::IsSingular_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::IsSingular_Request msg_;
};

class Init_IsSingular_Request_joints
{
public:
  Init_IsSingular_Request_joints()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_IsSingular_Request_arm_type joints(::upperlimb_msgs::srv::IsSingular_Request::_joints_type arg)
  {
    msg_.joints = std::move(arg);
    return Init_IsSingular_Request_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::IsSingular_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::IsSingular_Request>()
{
  return upperlimb_msgs::srv::builder::Init_IsSingular_Request_joints();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_IsSingular_Response_is_singular
{
public:
  explicit Init_IsSingular_Response_is_singular(::upperlimb_msgs::srv::IsSingular_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::IsSingular_Response is_singular(::upperlimb_msgs::srv::IsSingular_Response::_is_singular_type arg)
  {
    msg_.is_singular = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::IsSingular_Response msg_;
};

class Init_IsSingular_Response_message
{
public:
  explicit Init_IsSingular_Response_message(::upperlimb_msgs::srv::IsSingular_Response & msg)
  : msg_(msg)
  {}
  Init_IsSingular_Response_is_singular message(::upperlimb_msgs::srv::IsSingular_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_IsSingular_Response_is_singular(msg_);
  }

private:
  ::upperlimb_msgs::srv::IsSingular_Response msg_;
};

class Init_IsSingular_Response_success
{
public:
  Init_IsSingular_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_IsSingular_Response_message success(::upperlimb_msgs::srv::IsSingular_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_IsSingular_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::IsSingular_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::IsSingular_Response>()
{
  return upperlimb_msgs::srv::builder::Init_IsSingular_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__IS_SINGULAR__BUILDER_HPP_
