// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:msg/SpeedJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__TRAITS_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/msg/detail/speed_j__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace upperlimb_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SpeedJ & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: joint_speed
  {
    if (msg.joint_speed.size() == 0) {
      out << "joint_speed: []";
    } else {
      out << "joint_speed: [";
      size_t pending_items = msg.joint_speed.size();
      for (auto item : msg.joint_speed) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: acc
  {
    out << "acc: ";
    rosidl_generator_traits::value_to_yaml(msg.acc, out);
    out << ", ";
  }

  // member: arm_type
  {
    out << "arm_type: ";
    rosidl_generator_traits::value_to_yaml(msg.arm_type, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SpeedJ & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: joint_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joint_speed.size() == 0) {
      out << "joint_speed: []\n";
    } else {
      out << "joint_speed:\n";
      for (auto item : msg.joint_speed) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: acc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc: ";
    rosidl_generator_traits::value_to_yaml(msg.acc, out);
    out << "\n";
  }

  // member: arm_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "arm_type: ";
    rosidl_generator_traits::value_to_yaml(msg.arm_type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SpeedJ & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::msg::SpeedJ & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::msg::SpeedJ & msg)
{
  return upperlimb_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::msg::SpeedJ>()
{
  return "upperlimb_msgs::msg::SpeedJ";
}

template<>
inline const char * name<upperlimb_msgs::msg::SpeedJ>()
{
  return "upperlimb_msgs/msg/SpeedJ";
}

template<>
struct has_fixed_size<upperlimb_msgs::msg::SpeedJ>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::msg::SpeedJ>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::msg::SpeedJ>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__TRAITS_HPP_
