// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__UPLIMB_STATE_HPP_
#define UPPERLIMB_MSGS__MSG__UPLIMB_STATE_HPP_

#include "upperlimb_msgs/msg/detail/uplimb_state__struct.hpp"
#include "upperlimb_msgs/msg/detail/uplimb_state__builder.hpp"
#include "upperlimb_msgs/msg/detail/uplimb_state__traits.hpp"
#include "upperlimb_msgs/msg/detail/uplimb_state__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__UPLIMB_STATE_HPP_
