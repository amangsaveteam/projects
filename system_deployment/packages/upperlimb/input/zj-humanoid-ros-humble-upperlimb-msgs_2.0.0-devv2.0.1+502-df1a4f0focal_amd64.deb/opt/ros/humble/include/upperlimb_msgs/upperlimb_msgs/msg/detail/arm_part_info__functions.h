// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from upperlimb_msgs:msg/ArmPartInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__FUNCTIONS_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "upperlimb_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "upperlimb_msgs/msg/detail/arm_part_info__struct.h"

/// Initialize msg/ArmPartInfo message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__msg__ArmPartInfo
 * )) before or use
 * upperlimb_msgs__msg__ArmPartInfo__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmPartInfo__init(upperlimb_msgs__msg__ArmPartInfo * msg);

/// Finalize msg/ArmPartInfo message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmPartInfo__fini(upperlimb_msgs__msg__ArmPartInfo * msg);

/// Create msg/ArmPartInfo message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__msg__ArmPartInfo__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__msg__ArmPartInfo *
upperlimb_msgs__msg__ArmPartInfo__create();

/// Destroy msg/ArmPartInfo message.
/**
 * It calls
 * upperlimb_msgs__msg__ArmPartInfo__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmPartInfo__destroy(upperlimb_msgs__msg__ArmPartInfo * msg);

/// Check for msg/ArmPartInfo message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmPartInfo__are_equal(const upperlimb_msgs__msg__ArmPartInfo * lhs, const upperlimb_msgs__msg__ArmPartInfo * rhs);

/// Copy a msg/ArmPartInfo message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmPartInfo__copy(
  const upperlimb_msgs__msg__ArmPartInfo * input,
  upperlimb_msgs__msg__ArmPartInfo * output);

/// Initialize array of msg/ArmPartInfo messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__msg__ArmPartInfo__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmPartInfo__Sequence__init(upperlimb_msgs__msg__ArmPartInfo__Sequence * array, size_t size);

/// Finalize array of msg/ArmPartInfo messages.
/**
 * It calls
 * upperlimb_msgs__msg__ArmPartInfo__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmPartInfo__Sequence__fini(upperlimb_msgs__msg__ArmPartInfo__Sequence * array);

/// Create array of msg/ArmPartInfo messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__msg__ArmPartInfo__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__msg__ArmPartInfo__Sequence *
upperlimb_msgs__msg__ArmPartInfo__Sequence__create(size_t size);

/// Destroy array of msg/ArmPartInfo messages.
/**
 * It calls
 * upperlimb_msgs__msg__ArmPartInfo__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmPartInfo__Sequence__destroy(upperlimb_msgs__msg__ArmPartInfo__Sequence * array);

/// Check for msg/ArmPartInfo message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmPartInfo__Sequence__are_equal(const upperlimb_msgs__msg__ArmPartInfo__Sequence * lhs, const upperlimb_msgs__msg__ArmPartInfo__Sequence * rhs);

/// Copy an array of msg/ArmPartInfo messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmPartInfo__Sequence__copy(
  const upperlimb_msgs__msg__ArmPartInfo__Sequence * input,
  upperlimb_msgs__msg__ArmPartInfo__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__FUNCTIONS_H_
