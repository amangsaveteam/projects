// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from upperlimb_msgs:srv/IK.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "upperlimb_msgs/srv/detail/ik__rosidl_typesupport_introspection_c.h"
#include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "upperlimb_msgs/srv/detail/ik__functions.h"
#include "upperlimb_msgs/srv/detail/ik__struct.h"


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/pose.h"
// Member `pose`
#include "geometry_msgs/msg/detail/pose__rosidl_typesupport_introspection_c.h"
// Member `q_init`
// Member `q_ref`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__IK_Request__init(message_memory);
}

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__IK_Request__fini(message_memory);
}

size_t upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__size_function__IK_Request__pose(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__pose(
  const void * untyped_member, size_t index)
{
  const geometry_msgs__msg__Pose * member =
    (const geometry_msgs__msg__Pose *)(untyped_member);
  return &member[index];
}

void * upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__pose(
  void * untyped_member, size_t index)
{
  geometry_msgs__msg__Pose * member =
    (geometry_msgs__msg__Pose *)(untyped_member);
  return &member[index];
}

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__fetch_function__IK_Request__pose(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const geometry_msgs__msg__Pose * item =
    ((const geometry_msgs__msg__Pose *)
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__pose(untyped_member, index));
  geometry_msgs__msg__Pose * value =
    (geometry_msgs__msg__Pose *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__assign_function__IK_Request__pose(
  void * untyped_member, size_t index, const void * untyped_value)
{
  geometry_msgs__msg__Pose * item =
    ((geometry_msgs__msg__Pose *)
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__pose(untyped_member, index));
  const geometry_msgs__msg__Pose * value =
    (const geometry_msgs__msg__Pose *)(untyped_value);
  *item = *value;
}

size_t upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__size_function__IK_Request__q_init(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__q_init(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__q_init(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__fetch_function__IK_Request__q_init(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__q_init(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__assign_function__IK_Request__q_init(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__q_init(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__resize_function__IK_Request__q_init(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

size_t upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__size_function__IK_Request__q_ref(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__q_ref(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__q_ref(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__fetch_function__IK_Request__q_ref(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__q_ref(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__assign_function__IK_Request__q_ref(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__q_ref(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__resize_function__IK_Request__q_ref(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_member_array[5] = {
  {
    "pose",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Request, pose),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__size_function__IK_Request__pose,  // size() function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__pose,  // get_const(index) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__pose,  // get(index) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__fetch_function__IK_Request__pose,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__assign_function__IK_Request__pose,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "q7",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Request, q7),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "q_init",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Request, q_init),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__size_function__IK_Request__q_init,  // size() function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__q_init,  // get_const(index) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__q_init,  // get(index) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__fetch_function__IK_Request__q_init,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__assign_function__IK_Request__q_init,  // assign(index, value) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__resize_function__IK_Request__q_init  // resize(index) function pointer
  },
  {
    "q_ref",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Request, q_ref),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__size_function__IK_Request__q_ref,  // size() function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_const_function__IK_Request__q_ref,  // get_const(index) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__get_function__IK_Request__q_ref,  // get(index) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__fetch_function__IK_Request__q_ref,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__assign_function__IK_Request__q_ref,  // assign(index, value) function pointer
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__resize_function__IK_Request__q_ref  // resize(index) function pointer
  },
  {
    "arm_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Request, arm_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "IK_Request",  // message name
  5,  // number of fields
  sizeof(upperlimb_msgs__srv__IK_Request),
  upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_member_array,  // message members
  upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, IK_Request)() {
  upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Pose)();
  if (!upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__IK_Request__rosidl_typesupport_introspection_c__IK_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "upperlimb_msgs/srv/detail/ik__rosidl_typesupport_introspection_c.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "upperlimb_msgs/srv/detail/ik__functions.h"
// already included above
// #include "upperlimb_msgs/srv/detail/ik__struct.h"


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"
// Member `joints`
#include "upperlimb_msgs/msg/joints.h"
// Member `joints`
#include "upperlimb_msgs/msg/detail/joints__rosidl_typesupport_introspection_c.h"
// Member `arm_type`
// Member `phi`
// already included above
// #include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__IK_Response__init(message_memory);
}

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__IK_Response__fini(message_memory);
}

size_t upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__size_function__IK_Response__joints(
  const void * untyped_member)
{
  const upperlimb_msgs__msg__Joints__Sequence * member =
    (const upperlimb_msgs__msg__Joints__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__joints(
  const void * untyped_member, size_t index)
{
  const upperlimb_msgs__msg__Joints__Sequence * member =
    (const upperlimb_msgs__msg__Joints__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__joints(
  void * untyped_member, size_t index)
{
  upperlimb_msgs__msg__Joints__Sequence * member =
    (upperlimb_msgs__msg__Joints__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__fetch_function__IK_Response__joints(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const upperlimb_msgs__msg__Joints * item =
    ((const upperlimb_msgs__msg__Joints *)
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__joints(untyped_member, index));
  upperlimb_msgs__msg__Joints * value =
    (upperlimb_msgs__msg__Joints *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__assign_function__IK_Response__joints(
  void * untyped_member, size_t index, const void * untyped_value)
{
  upperlimb_msgs__msg__Joints * item =
    ((upperlimb_msgs__msg__Joints *)
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__joints(untyped_member, index));
  const upperlimb_msgs__msg__Joints * value =
    (const upperlimb_msgs__msg__Joints *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__resize_function__IK_Response__joints(
  void * untyped_member, size_t size)
{
  upperlimb_msgs__msg__Joints__Sequence * member =
    (upperlimb_msgs__msg__Joints__Sequence *)(untyped_member);
  upperlimb_msgs__msg__Joints__Sequence__fini(member);
  return upperlimb_msgs__msg__Joints__Sequence__init(member, size);
}

size_t upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__size_function__IK_Response__arm_type(
  const void * untyped_member)
{
  const rosidl_runtime_c__int8__Sequence * member =
    (const rosidl_runtime_c__int8__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__arm_type(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int8__Sequence * member =
    (const rosidl_runtime_c__int8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__arm_type(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int8__Sequence * member =
    (rosidl_runtime_c__int8__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__fetch_function__IK_Response__arm_type(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int8_t * item =
    ((const int8_t *)
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__arm_type(untyped_member, index));
  int8_t * value =
    (int8_t *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__assign_function__IK_Response__arm_type(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int8_t * item =
    ((int8_t *)
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__arm_type(untyped_member, index));
  const int8_t * value =
    (const int8_t *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__resize_function__IK_Response__arm_type(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int8__Sequence * member =
    (rosidl_runtime_c__int8__Sequence *)(untyped_member);
  rosidl_runtime_c__int8__Sequence__fini(member);
  return rosidl_runtime_c__int8__Sequence__init(member, size);
}

size_t upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__size_function__IK_Response__phi(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__phi(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__phi(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__fetch_function__IK_Response__phi(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__phi(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__assign_function__IK_Response__phi(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__phi(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__resize_function__IK_Response__phi(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_member_array[6] = {
  {
    "success",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Response, success),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "message",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Response, message),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "nums",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Response, nums),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "joints",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Response, joints),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__size_function__IK_Response__joints,  // size() function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__joints,  // get_const(index) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__joints,  // get(index) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__fetch_function__IK_Response__joints,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__assign_function__IK_Response__joints,  // assign(index, value) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__resize_function__IK_Response__joints  // resize(index) function pointer
  },
  {
    "arm_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Response, arm_type),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__size_function__IK_Response__arm_type,  // size() function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__arm_type,  // get_const(index) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__arm_type,  // get(index) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__fetch_function__IK_Response__arm_type,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__assign_function__IK_Response__arm_type,  // assign(index, value) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__resize_function__IK_Response__arm_type  // resize(index) function pointer
  },
  {
    "phi",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__IK_Response, phi),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__size_function__IK_Response__phi,  // size() function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_const_function__IK_Response__phi,  // get_const(index) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__get_function__IK_Response__phi,  // get(index) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__fetch_function__IK_Response__phi,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__assign_function__IK_Response__phi,  // assign(index, value) function pointer
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__resize_function__IK_Response__phi  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "IK_Response",  // message name
  6,  // number of fields
  sizeof(upperlimb_msgs__srv__IK_Response),
  upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_member_array,  // message members
  upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, IK_Response)() {
  upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, msg, Joints)();
  if (!upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__IK_Response__rosidl_typesupport_introspection_c__IK_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "upperlimb_msgs/srv/detail/ik__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_service_members = {
  "upperlimb_msgs__srv",  // service namespace
  "IK",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_Request_message_type_support_handle,
  NULL  // response message
  // upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_Response_message_type_support_handle
};

static rosidl_service_type_support_t upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_service_type_support_handle = {
  0,
  &upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, IK_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, IK_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, IK)() {
  if (!upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_service_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, IK_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, IK_Response)()->data;
  }

  return &upperlimb_msgs__srv__detail__ik__rosidl_typesupport_introspection_c__IK_service_type_support_handle;
}
