// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__CARTESIAN_PLANNING_PARAMS_SET_HPP_
#define UPPERLIMB_MSGS__SRV__CARTESIAN_PLANNING_PARAMS_SET_HPP_

#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__struct.hpp"
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__builder.hpp"
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__traits.hpp"
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__type_support.hpp"

#endif  // UPPERLIMB_MSGS__SRV__CARTESIAN_PLANNING_PARAMS_SET_HPP_
