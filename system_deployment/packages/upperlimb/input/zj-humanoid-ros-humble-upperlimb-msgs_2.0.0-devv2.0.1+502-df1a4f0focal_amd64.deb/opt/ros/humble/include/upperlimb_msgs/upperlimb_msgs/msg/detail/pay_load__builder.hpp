// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/PayLoad.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/pay_load__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_PayLoad_cog
{
public:
  explicit Init_PayLoad_cog(::upperlimb_msgs::msg::PayLoad & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::PayLoad cog(::upperlimb_msgs::msg::PayLoad::_cog_type arg)
  {
    msg_.cog = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::PayLoad msg_;
};

class Init_PayLoad_mass
{
public:
  Init_PayLoad_mass()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PayLoad_cog mass(::upperlimb_msgs::msg::PayLoad::_mass_type arg)
  {
    msg_.mass = std::move(arg);
    return Init_PayLoad_cog(msg_);
  }

private:
  ::upperlimb_msgs::msg::PayLoad msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::PayLoad>()
{
  return upperlimb_msgs::msg::builder::Init_PayLoad_mass();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__BUILDER_HPP_
