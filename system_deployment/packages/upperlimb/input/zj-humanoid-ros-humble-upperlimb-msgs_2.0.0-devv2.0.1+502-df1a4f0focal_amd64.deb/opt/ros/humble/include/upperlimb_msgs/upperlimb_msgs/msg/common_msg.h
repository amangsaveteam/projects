// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/CommonMsg.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__COMMON_MSG_H_
#define UPPERLIMB_MSGS__MSG__COMMON_MSG_H_

#include "upperlimb_msgs/msg/detail/common_msg__struct.h"
#include "upperlimb_msgs/msg/detail/common_msg__functions.h"
#include "upperlimb_msgs/msg/detail/common_msg__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__COMMON_MSG_H_
