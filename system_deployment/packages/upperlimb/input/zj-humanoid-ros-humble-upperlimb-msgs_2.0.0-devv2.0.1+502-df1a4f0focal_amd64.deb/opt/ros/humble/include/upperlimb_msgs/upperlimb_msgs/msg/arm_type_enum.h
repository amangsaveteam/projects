// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/ArmTypeEnum.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__ARM_TYPE_ENUM_H_
#define UPPERLIMB_MSGS__MSG__ARM_TYPE_ENUM_H_

#include "upperlimb_msgs/msg/detail/arm_type_enum__struct.h"
#include "upperlimb_msgs/msg/detail/arm_type_enum__functions.h"
#include "upperlimb_msgs/msg/detail/arm_type_enum__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__ARM_TYPE_ENUM_H_
