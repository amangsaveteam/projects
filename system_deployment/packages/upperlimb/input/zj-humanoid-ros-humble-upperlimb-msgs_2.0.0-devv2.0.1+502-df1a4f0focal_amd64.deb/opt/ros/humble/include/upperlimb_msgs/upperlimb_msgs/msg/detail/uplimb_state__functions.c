// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from upperlimb_msgs:msg/UplimbState.idl
// generated code does not contain a copyright notice
#include "upperlimb_msgs/msg/detail/uplimb_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `cmd_name`
#include "rosidl_runtime_c/string_functions.h"

bool
upperlimb_msgs__msg__UplimbState__init(upperlimb_msgs__msg__UplimbState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    upperlimb_msgs__msg__UplimbState__fini(msg);
    return false;
  }
  // cmd_num
  // cmd_name
  if (!rosidl_runtime_c__String__init(&msg->cmd_name)) {
    upperlimb_msgs__msg__UplimbState__fini(msg);
    return false;
  }
  // left_arm_is_singular
  // right_arm_is_singular
  // iddp_status
  return true;
}

void
upperlimb_msgs__msg__UplimbState__fini(upperlimb_msgs__msg__UplimbState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // cmd_num
  // cmd_name
  rosidl_runtime_c__String__fini(&msg->cmd_name);
  // left_arm_is_singular
  // right_arm_is_singular
  // iddp_status
}

bool
upperlimb_msgs__msg__UplimbState__are_equal(const upperlimb_msgs__msg__UplimbState * lhs, const upperlimb_msgs__msg__UplimbState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // cmd_num
  if (lhs->cmd_num != rhs->cmd_num) {
    return false;
  }
  // cmd_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->cmd_name), &(rhs->cmd_name)))
  {
    return false;
  }
  // left_arm_is_singular
  if (lhs->left_arm_is_singular != rhs->left_arm_is_singular) {
    return false;
  }
  // right_arm_is_singular
  if (lhs->right_arm_is_singular != rhs->right_arm_is_singular) {
    return false;
  }
  // iddp_status
  if (lhs->iddp_status != rhs->iddp_status) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__msg__UplimbState__copy(
  const upperlimb_msgs__msg__UplimbState * input,
  upperlimb_msgs__msg__UplimbState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // cmd_num
  output->cmd_num = input->cmd_num;
  // cmd_name
  if (!rosidl_runtime_c__String__copy(
      &(input->cmd_name), &(output->cmd_name)))
  {
    return false;
  }
  // left_arm_is_singular
  output->left_arm_is_singular = input->left_arm_is_singular;
  // right_arm_is_singular
  output->right_arm_is_singular = input->right_arm_is_singular;
  // iddp_status
  output->iddp_status = input->iddp_status;
  return true;
}

upperlimb_msgs__msg__UplimbState *
upperlimb_msgs__msg__UplimbState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__UplimbState * msg = (upperlimb_msgs__msg__UplimbState *)allocator.allocate(sizeof(upperlimb_msgs__msg__UplimbState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__msg__UplimbState));
  bool success = upperlimb_msgs__msg__UplimbState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__msg__UplimbState__destroy(upperlimb_msgs__msg__UplimbState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__msg__UplimbState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__msg__UplimbState__Sequence__init(upperlimb_msgs__msg__UplimbState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__UplimbState * data = NULL;

  if (size) {
    data = (upperlimb_msgs__msg__UplimbState *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__msg__UplimbState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__msg__UplimbState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__msg__UplimbState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__msg__UplimbState__Sequence__fini(upperlimb_msgs__msg__UplimbState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__msg__UplimbState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__msg__UplimbState__Sequence *
upperlimb_msgs__msg__UplimbState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__UplimbState__Sequence * array = (upperlimb_msgs__msg__UplimbState__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__msg__UplimbState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__msg__UplimbState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__msg__UplimbState__Sequence__destroy(upperlimb_msgs__msg__UplimbState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__msg__UplimbState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__msg__UplimbState__Sequence__are_equal(const upperlimb_msgs__msg__UplimbState__Sequence * lhs, const upperlimb_msgs__msg__UplimbState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__msg__UplimbState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__msg__UplimbState__Sequence__copy(
  const upperlimb_msgs__msg__UplimbState__Sequence * input,
  upperlimb_msgs__msg__UplimbState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__msg__UplimbState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__msg__UplimbState * data =
      (upperlimb_msgs__msg__UplimbState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__msg__UplimbState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__msg__UplimbState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__msg__UplimbState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
