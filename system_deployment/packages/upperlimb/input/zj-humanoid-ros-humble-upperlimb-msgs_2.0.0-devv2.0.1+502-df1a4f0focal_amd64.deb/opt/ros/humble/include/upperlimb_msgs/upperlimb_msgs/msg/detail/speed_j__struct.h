﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/SpeedJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'joint_speed'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/SpeedJ in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__SpeedJ
{
  /// (Add on 2.0.0+)
  std_msgs__msg__Header header;
  /// 目标关节速度
  rosidl_runtime_c__double__Sequence joint_speed;
  /// 最大加速度
  double acc;
  /// 机器人身体部位
  int8_t arm_type;
} upperlimb_msgs__msg__SpeedJ;

// Struct for a sequence of upperlimb_msgs__msg__SpeedJ.
typedef struct upperlimb_msgs__msg__SpeedJ__Sequence
{
  upperlimb_msgs__msg__SpeedJ * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__SpeedJ__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__STRUCT_H_
