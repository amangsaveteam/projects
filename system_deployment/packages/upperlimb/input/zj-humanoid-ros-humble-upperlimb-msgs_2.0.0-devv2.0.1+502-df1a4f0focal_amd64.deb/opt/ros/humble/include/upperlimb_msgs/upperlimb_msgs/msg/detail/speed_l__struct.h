﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/SpeedL.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__SPEED_L__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__SPEED_L__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'tcp_speed'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/SpeedL in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__SpeedL
{
  /// (Add on 2.0.0+)
  std_msgs__msg__Header header;
  /// 目标末端速度，末端平动速度[m/s]，末端转动角速度[rad/s]
  rosidl_runtime_c__double__Sequence tcp_speed;
  /// 最大加速度
  double acc;
  /// 机器人身体部位 仅当全身控制时有用,用来指定当前要控制的目标部位,可以通过8421码进行叠加。参考 ArmTypeEnum.msg (Add on 1.4.0+)
  int8_t arm_type;
} upperlimb_msgs__msg__SpeedL;

// Struct for a sequence of upperlimb_msgs__msg__SpeedL.
typedef struct upperlimb_msgs__msg__SpeedL__Sequence
{
  upperlimb_msgs__msg__SpeedL * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__SpeedL__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__SPEED_L__STRUCT_H_
