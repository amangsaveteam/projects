﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/DualPose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'left_arm_pose'
// Member 'right_arm_pose'
#include "geometry_msgs/msg/detail/pose__struct.h"

/// Struct defined in msg/DualPose in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__DualPose
{
  /// (Add on 2.0.0+)
  std_msgs__msg__Header header;
  /// 左臂数据      xyz 单位:m
  geometry_msgs__msg__Pose left_arm_pose;
  /// 右臂数据      xyz 单位:m
  geometry_msgs__msg__Pose right_arm_pose;
} upperlimb_msgs__msg__DualPose;

// Struct for a sequence of upperlimb_msgs__msg__DualPose.
typedef struct upperlimb_msgs__msg__DualPose__Sequence
{
  upperlimb_msgs__msg__DualPose * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__DualPose__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__STRUCT_H_
