// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:msg/Pose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__POSE__TRAITS_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__POSE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/msg/detail/pose__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'position'
#include "geometry_msgs/msg/detail/point__traits.hpp"
// Member 'quaternion'
#include "geometry_msgs/msg/detail/quaternion__traits.hpp"

namespace upperlimb_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Pose & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: position
  {
    out << "position: ";
    to_flow_style_yaml(msg.position, out);
    out << ", ";
  }

  // member: quaternion
  {
    out << "quaternion: ";
    to_flow_style_yaml(msg.quaternion, out);
    out << ", ";
  }

  // member: rpy_rad
  {
    if (msg.rpy_rad.size() == 0) {
      out << "rpy_rad: []";
    } else {
      out << "rpy_rad: [";
      size_t pending_items = msg.rpy_rad.size();
      for (auto item : msg.rpy_rad) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: rpy_deg
  {
    if (msg.rpy_deg.size() == 0) {
      out << "rpy_deg: []";
    } else {
      out << "rpy_deg: [";
      size_t pending_items = msg.rpy_deg.size();
      for (auto item : msg.rpy_deg) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Pose & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position:\n";
    to_block_style_yaml(msg.position, out, indentation + 2);
  }

  // member: quaternion
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "quaternion:\n";
    to_block_style_yaml(msg.quaternion, out, indentation + 2);
  }

  // member: rpy_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.rpy_rad.size() == 0) {
      out << "rpy_rad: []\n";
    } else {
      out << "rpy_rad:\n";
      for (auto item : msg.rpy_rad) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: rpy_deg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.rpy_deg.size() == 0) {
      out << "rpy_deg: []\n";
    } else {
      out << "rpy_deg:\n";
      for (auto item : msg.rpy_deg) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Pose & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::msg::Pose & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::msg::Pose & msg)
{
  return upperlimb_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::msg::Pose>()
{
  return "upperlimb_msgs::msg::Pose";
}

template<>
inline const char * name<upperlimb_msgs::msg::Pose>()
{
  return "upperlimb_msgs/msg/Pose";
}

template<>
struct has_fixed_size<upperlimb_msgs::msg::Pose>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Point>::value && has_fixed_size<geometry_msgs::msg::Quaternion>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::msg::Pose>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Point>::value && has_bounded_size<geometry_msgs::msg::Quaternion>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<upperlimb_msgs::msg::Pose>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__POSE__TRAITS_HPP_
