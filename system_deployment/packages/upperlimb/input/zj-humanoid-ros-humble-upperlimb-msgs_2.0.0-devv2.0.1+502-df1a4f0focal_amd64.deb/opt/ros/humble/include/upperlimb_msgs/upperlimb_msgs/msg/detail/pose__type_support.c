// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from upperlimb_msgs:msg/Pose.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "upperlimb_msgs/msg/detail/pose__rosidl_typesupport_introspection_c.h"
#include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "upperlimb_msgs/msg/detail/pose__functions.h"
#include "upperlimb_msgs/msg/detail/pose__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `position`
#include "geometry_msgs/msg/point.h"
// Member `position`
#include "geometry_msgs/msg/detail/point__rosidl_typesupport_introspection_c.h"
// Member `quaternion`
#include "geometry_msgs/msg/quaternion.h"
// Member `quaternion`
#include "geometry_msgs/msg/detail/quaternion__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__msg__Pose__init(message_memory);
}

void upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_fini_function(void * message_memory)
{
  upperlimb_msgs__msg__Pose__fini(message_memory);
}

size_t upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__size_function__Pose__rpy_rad(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_const_function__Pose__rpy_rad(
  const void * untyped_member, size_t index)
{
  const double * member =
    (const double *)(untyped_member);
  return &member[index];
}

void * upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_function__Pose__rpy_rad(
  void * untyped_member, size_t index)
{
  double * member =
    (double *)(untyped_member);
  return &member[index];
}

void upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__fetch_function__Pose__rpy_rad(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_const_function__Pose__rpy_rad(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__assign_function__Pose__rpy_rad(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_function__Pose__rpy_rad(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

size_t upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__size_function__Pose__rpy_deg(
  const void * untyped_member)
{
  (void)untyped_member;
  return 3;
}

const void * upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_const_function__Pose__rpy_deg(
  const void * untyped_member, size_t index)
{
  const double * member =
    (const double *)(untyped_member);
  return &member[index];
}

void * upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_function__Pose__rpy_deg(
  void * untyped_member, size_t index)
{
  double * member =
    (double *)(untyped_member);
  return &member[index];
}

void upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__fetch_function__Pose__rpy_deg(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_const_function__Pose__rpy_deg(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__assign_function__Pose__rpy_deg(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_function__Pose__rpy_deg(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_member_array[5] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__msg__Pose, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "position",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__msg__Pose, position),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "quaternion",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__msg__Pose, quaternion),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "rpy_rad",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__msg__Pose, rpy_rad),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__size_function__Pose__rpy_rad,  // size() function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_const_function__Pose__rpy_rad,  // get_const(index) function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_function__Pose__rpy_rad,  // get(index) function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__fetch_function__Pose__rpy_rad,  // fetch(index, &value) function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__assign_function__Pose__rpy_rad,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "rpy_deg",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    3,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__msg__Pose, rpy_deg),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__size_function__Pose__rpy_deg,  // size() function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_const_function__Pose__rpy_deg,  // get_const(index) function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__get_function__Pose__rpy_deg,  // get(index) function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__fetch_function__Pose__rpy_deg,  // fetch(index, &value) function pointer
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__assign_function__Pose__rpy_deg,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_members = {
  "upperlimb_msgs__msg",  // message namespace
  "Pose",  // message name
  5,  // number of fields
  sizeof(upperlimb_msgs__msg__Pose),
  upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_member_array,  // message members
  upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_type_support_handle = {
  0,
  &upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, msg, Pose)() {
  upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Point)();
  upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Quaternion)();
  if (!upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__msg__Pose__rosidl_typesupport_introspection_c__Pose_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
