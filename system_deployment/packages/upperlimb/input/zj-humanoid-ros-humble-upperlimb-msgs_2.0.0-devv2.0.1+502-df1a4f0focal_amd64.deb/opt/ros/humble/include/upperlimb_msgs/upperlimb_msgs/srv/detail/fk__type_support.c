// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from upperlimb_msgs:srv/FK.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "upperlimb_msgs/srv/detail/fk__rosidl_typesupport_introspection_c.h"
#include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "upperlimb_msgs/srv/detail/fk__functions.h"
#include "upperlimb_msgs/srv/detail/fk__struct.h"


// Include directives for member types
// Member `joints`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__FK_Request__init(message_memory);
}

void upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__FK_Request__fini(message_memory);
}

size_t upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__size_function__FK_Request__joints(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__get_const_function__FK_Request__joints(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__get_function__FK_Request__joints(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__fetch_function__FK_Request__joints(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__get_const_function__FK_Request__joints(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__assign_function__FK_Request__joints(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__get_function__FK_Request__joints(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__resize_function__FK_Request__joints(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_member_array[2] = {
  {
    "joints",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Request, joints),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__size_function__FK_Request__joints,  // size() function pointer
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__get_const_function__FK_Request__joints,  // get_const(index) function pointer
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__get_function__FK_Request__joints,  // get(index) function pointer
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__fetch_function__FK_Request__joints,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__assign_function__FK_Request__joints,  // assign(index, value) function pointer
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__resize_function__FK_Request__joints  // resize(index) function pointer
  },
  {
    "arm_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Request, arm_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "FK_Request",  // message name
  2,  // number of fields
  sizeof(upperlimb_msgs__srv__FK_Request),
  upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_member_array,  // message members
  upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, FK_Request)() {
  if (!upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__FK_Request__rosidl_typesupport_introspection_c__FK_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "upperlimb_msgs/srv/detail/fk__rosidl_typesupport_introspection_c.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "upperlimb_msgs/srv/detail/fk__functions.h"
// already included above
// #include "upperlimb_msgs/srv/detail/fk__struct.h"


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"
// Member `pose`
// Member `pose_array`
#include "geometry_msgs/msg/pose.h"
// Member `pose`
// Member `pose_array`
#include "geometry_msgs/msg/detail/pose__rosidl_typesupport_introspection_c.h"
// Member `arm_type_array`
// already included above
// #include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__FK_Response__init(message_memory);
}

void upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__FK_Response__fini(message_memory);
}

size_t upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__size_function__FK_Response__pose_array(
  const void * untyped_member)
{
  const geometry_msgs__msg__Pose__Sequence * member =
    (const geometry_msgs__msg__Pose__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_const_function__FK_Response__pose_array(
  const void * untyped_member, size_t index)
{
  const geometry_msgs__msg__Pose__Sequence * member =
    (const geometry_msgs__msg__Pose__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_function__FK_Response__pose_array(
  void * untyped_member, size_t index)
{
  geometry_msgs__msg__Pose__Sequence * member =
    (geometry_msgs__msg__Pose__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__fetch_function__FK_Response__pose_array(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const geometry_msgs__msg__Pose * item =
    ((const geometry_msgs__msg__Pose *)
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_const_function__FK_Response__pose_array(untyped_member, index));
  geometry_msgs__msg__Pose * value =
    (geometry_msgs__msg__Pose *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__assign_function__FK_Response__pose_array(
  void * untyped_member, size_t index, const void * untyped_value)
{
  geometry_msgs__msg__Pose * item =
    ((geometry_msgs__msg__Pose *)
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_function__FK_Response__pose_array(untyped_member, index));
  const geometry_msgs__msg__Pose * value =
    (const geometry_msgs__msg__Pose *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__resize_function__FK_Response__pose_array(
  void * untyped_member, size_t size)
{
  geometry_msgs__msg__Pose__Sequence * member =
    (geometry_msgs__msg__Pose__Sequence *)(untyped_member);
  geometry_msgs__msg__Pose__Sequence__fini(member);
  return geometry_msgs__msg__Pose__Sequence__init(member, size);
}

size_t upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__size_function__FK_Response__arm_type_array(
  const void * untyped_member)
{
  const rosidl_runtime_c__int8__Sequence * member =
    (const rosidl_runtime_c__int8__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_const_function__FK_Response__arm_type_array(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int8__Sequence * member =
    (const rosidl_runtime_c__int8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_function__FK_Response__arm_type_array(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int8__Sequence * member =
    (rosidl_runtime_c__int8__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__fetch_function__FK_Response__arm_type_array(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int8_t * item =
    ((const int8_t *)
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_const_function__FK_Response__arm_type_array(untyped_member, index));
  int8_t * value =
    (int8_t *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__assign_function__FK_Response__arm_type_array(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int8_t * item =
    ((int8_t *)
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_function__FK_Response__arm_type_array(untyped_member, index));
  const int8_t * value =
    (const int8_t *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__resize_function__FK_Response__arm_type_array(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int8__Sequence * member =
    (rosidl_runtime_c__int8__Sequence *)(untyped_member);
  rosidl_runtime_c__int8__Sequence__fini(member);
  return rosidl_runtime_c__int8__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_member_array[6] = {
  {
    "success",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Response, success),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "message",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Response, message),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pose",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Response, pose),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arm_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Response, arm_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pose_array",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Response, pose_array),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__size_function__FK_Response__pose_array,  // size() function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_const_function__FK_Response__pose_array,  // get_const(index) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_function__FK_Response__pose_array,  // get(index) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__fetch_function__FK_Response__pose_array,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__assign_function__FK_Response__pose_array,  // assign(index, value) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__resize_function__FK_Response__pose_array  // resize(index) function pointer
  },
  {
    "arm_type_array",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__FK_Response, arm_type_array),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__size_function__FK_Response__arm_type_array,  // size() function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_const_function__FK_Response__arm_type_array,  // get_const(index) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__get_function__FK_Response__arm_type_array,  // get(index) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__fetch_function__FK_Response__arm_type_array,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__assign_function__FK_Response__arm_type_array,  // assign(index, value) function pointer
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__resize_function__FK_Response__arm_type_array  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "FK_Response",  // message name
  6,  // number of fields
  sizeof(upperlimb_msgs__srv__FK_Response),
  upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_member_array,  // message members
  upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, FK_Response)() {
  upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Pose)();
  upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Pose)();
  if (!upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__FK_Response__rosidl_typesupport_introspection_c__FK_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "upperlimb_msgs/srv/detail/fk__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_service_members = {
  "upperlimb_msgs__srv",  // service namespace
  "FK",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_Request_message_type_support_handle,
  NULL  // response message
  // upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_Response_message_type_support_handle
};

static rosidl_service_type_support_t upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_service_type_support_handle = {
  0,
  &upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, FK_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, FK_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, FK)() {
  if (!upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_service_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, FK_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, FK_Response)()->data;
  }

  return &upperlimb_msgs__srv__detail__fk__rosidl_typesupport_introspection_c__FK_service_type_support_handle;
}
