// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/MotionInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__MOTION_INFO__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__MOTION_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/motion_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_MotionInfo_number
{
public:
  explicit Init_MotionInfo_number(::upperlimb_msgs::msg::MotionInfo & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::MotionInfo number(::upperlimb_msgs::msg::MotionInfo::_number_type arg)
  {
    msg_.number = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::MotionInfo msg_;
};

class Init_MotionInfo_joints
{
public:
  explicit Init_MotionInfo_joints(::upperlimb_msgs::msg::MotionInfo & msg)
  : msg_(msg)
  {}
  Init_MotionInfo_number joints(::upperlimb_msgs::msg::MotionInfo::_joints_type arg)
  {
    msg_.joints = std::move(arg);
    return Init_MotionInfo_number(msg_);
  }

private:
  ::upperlimb_msgs::msg::MotionInfo msg_;
};

class Init_MotionInfo_arm_type
{
public:
  explicit Init_MotionInfo_arm_type(::upperlimb_msgs::msg::MotionInfo & msg)
  : msg_(msg)
  {}
  Init_MotionInfo_joints arm_type(::upperlimb_msgs::msg::MotionInfo::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return Init_MotionInfo_joints(msg_);
  }

private:
  ::upperlimb_msgs::msg::MotionInfo msg_;
};

class Init_MotionInfo_alias
{
public:
  explicit Init_MotionInfo_alias(::upperlimb_msgs::msg::MotionInfo & msg)
  : msg_(msg)
  {}
  Init_MotionInfo_arm_type alias(::upperlimb_msgs::msg::MotionInfo::_alias_type arg)
  {
    msg_.alias = std::move(arg);
    return Init_MotionInfo_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::msg::MotionInfo msg_;
};

class Init_MotionInfo_filename
{
public:
  Init_MotionInfo_filename()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionInfo_alias filename(::upperlimb_msgs::msg::MotionInfo::_filename_type arg)
  {
    msg_.filename = std::move(arg);
    return Init_MotionInfo_alias(msg_);
  }

private:
  ::upperlimb_msgs::msg::MotionInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::MotionInfo>()
{
  return upperlimb_msgs::msg::builder::Init_MotionInfo_filename();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__MOTION_INFO__BUILDER_HPP_
