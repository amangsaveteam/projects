// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/PayLoad.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__PAY_LOAD_H_
#define UPPERLIMB_MSGS__MSG__PAY_LOAD_H_

#include "upperlimb_msgs/msg/detail/pay_load__struct.h"
#include "upperlimb_msgs/msg/detail/pay_load__functions.h"
#include "upperlimb_msgs/msg/detail/pay_load__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__PAY_LOAD_H_
