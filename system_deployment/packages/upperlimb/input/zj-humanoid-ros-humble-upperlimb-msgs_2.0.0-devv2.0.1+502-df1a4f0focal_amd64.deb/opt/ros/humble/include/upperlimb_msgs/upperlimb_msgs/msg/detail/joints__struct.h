﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/Joints.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__JOINTS__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__JOINTS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'joint'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/Joints in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__Joints
{
  /// (Add on 2.0.0+)
  std_msgs__msg__Header header;
  /// 关节数据. 不同机型不同type对应的数据长度见下表     单位:
  rosidl_runtime_c__double__Sequence joint;
} upperlimb_msgs__msg__Joints;

// Struct for a sequence of upperlimb_msgs__msg__Joints.
typedef struct upperlimb_msgs__msg__Joints__Sequence
{
  upperlimb_msgs__msg__Joints * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__Joints__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__JOINTS__STRUCT_H_
