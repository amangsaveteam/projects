// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__ARM_TYPE_HPP_
#define UPPERLIMB_MSGS__SRV__ARM_TYPE_HPP_

#include "upperlimb_msgs/srv/detail/arm_type__struct.hpp"
#include "upperlimb_msgs/srv/detail/arm_type__builder.hpp"
#include "upperlimb_msgs/srv/detail/arm_type__traits.hpp"
#include "upperlimb_msgs/srv/detail/arm_type__type_support.hpp"

#endif  // UPPERLIMB_MSGS__SRV__ARM_TYPE_HPP_
