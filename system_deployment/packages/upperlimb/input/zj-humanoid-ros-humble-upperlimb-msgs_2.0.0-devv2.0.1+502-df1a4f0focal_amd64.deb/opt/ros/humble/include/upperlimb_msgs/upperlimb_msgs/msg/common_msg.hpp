// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__COMMON_MSG_HPP_
#define UPPERLIMB_MSGS__MSG__COMMON_MSG_HPP_

#include "upperlimb_msgs/msg/detail/common_msg__struct.hpp"
#include "upperlimb_msgs/msg/detail/common_msg__builder.hpp"
#include "upperlimb_msgs/msg/detail/common_msg__traits.hpp"
#include "upperlimb_msgs/msg/detail/common_msg__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__COMMON_MSG_HPP_
