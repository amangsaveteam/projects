// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/IK.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__IK__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__IK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/ik__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_IK_Request_arm_type
{
public:
  explicit Init_IK_Request_arm_type(::upperlimb_msgs::srv::IK_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::IK_Request arm_type(::upperlimb_msgs::srv::IK_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Request msg_;
};

class Init_IK_Request_q_ref
{
public:
  explicit Init_IK_Request_q_ref(::upperlimb_msgs::srv::IK_Request & msg)
  : msg_(msg)
  {}
  Init_IK_Request_arm_type q_ref(::upperlimb_msgs::srv::IK_Request::_q_ref_type arg)
  {
    msg_.q_ref = std::move(arg);
    return Init_IK_Request_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Request msg_;
};

class Init_IK_Request_q_init
{
public:
  explicit Init_IK_Request_q_init(::upperlimb_msgs::srv::IK_Request & msg)
  : msg_(msg)
  {}
  Init_IK_Request_q_ref q_init(::upperlimb_msgs::srv::IK_Request::_q_init_type arg)
  {
    msg_.q_init = std::move(arg);
    return Init_IK_Request_q_ref(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Request msg_;
};

class Init_IK_Request_q7
{
public:
  explicit Init_IK_Request_q7(::upperlimb_msgs::srv::IK_Request & msg)
  : msg_(msg)
  {}
  Init_IK_Request_q_init q7(::upperlimb_msgs::srv::IK_Request::_q7_type arg)
  {
    msg_.q7 = std::move(arg);
    return Init_IK_Request_q_init(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Request msg_;
};

class Init_IK_Request_pose
{
public:
  Init_IK_Request_pose()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_IK_Request_q7 pose(::upperlimb_msgs::srv::IK_Request::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_IK_Request_q7(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::IK_Request>()
{
  return upperlimb_msgs::srv::builder::Init_IK_Request_pose();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_IK_Response_phi
{
public:
  explicit Init_IK_Response_phi(::upperlimb_msgs::srv::IK_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::IK_Response phi(::upperlimb_msgs::srv::IK_Response::_phi_type arg)
  {
    msg_.phi = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Response msg_;
};

class Init_IK_Response_arm_type
{
public:
  explicit Init_IK_Response_arm_type(::upperlimb_msgs::srv::IK_Response & msg)
  : msg_(msg)
  {}
  Init_IK_Response_phi arm_type(::upperlimb_msgs::srv::IK_Response::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return Init_IK_Response_phi(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Response msg_;
};

class Init_IK_Response_joints
{
public:
  explicit Init_IK_Response_joints(::upperlimb_msgs::srv::IK_Response & msg)
  : msg_(msg)
  {}
  Init_IK_Response_arm_type joints(::upperlimb_msgs::srv::IK_Response::_joints_type arg)
  {
    msg_.joints = std::move(arg);
    return Init_IK_Response_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Response msg_;
};

class Init_IK_Response_nums
{
public:
  explicit Init_IK_Response_nums(::upperlimb_msgs::srv::IK_Response & msg)
  : msg_(msg)
  {}
  Init_IK_Response_joints nums(::upperlimb_msgs::srv::IK_Response::_nums_type arg)
  {
    msg_.nums = std::move(arg);
    return Init_IK_Response_joints(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Response msg_;
};

class Init_IK_Response_message
{
public:
  explicit Init_IK_Response_message(::upperlimb_msgs::srv::IK_Response & msg)
  : msg_(msg)
  {}
  Init_IK_Response_nums message(::upperlimb_msgs::srv::IK_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_IK_Response_nums(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Response msg_;
};

class Init_IK_Response_success
{
public:
  Init_IK_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_IK_Response_message success(::upperlimb_msgs::srv::IK_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_IK_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::IK_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::IK_Response>()
{
  return upperlimb_msgs::srv::builder::Init_IK_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__IK__BUILDER_HPP_
