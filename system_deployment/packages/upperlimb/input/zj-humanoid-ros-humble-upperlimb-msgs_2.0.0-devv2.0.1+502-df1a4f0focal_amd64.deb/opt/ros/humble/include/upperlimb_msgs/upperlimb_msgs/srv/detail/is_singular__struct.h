﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/IsSingular.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__IS_SINGULAR__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__IS_SINGULAR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'joints'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/IsSingular in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__IsSingular_Request
{
  /// 手臂关节数据
  rosidl_runtime_c__double__Sequence joints;
  /// 参与笛卡尔空间规划的机器人身体部位(必须有左臂或右臂或双臂的索引). 仅当全身控制时有用,用来指定当前要控制的目标部位,可以通过8421码进行叠加。参考 ArmTypeEnum.msg (Add on 1.4.0+)
  int8_t arm_type;
} upperlimb_msgs__srv__IsSingular_Request;

// Struct for a sequence of upperlimb_msgs__srv__IsSingular_Request.
typedef struct upperlimb_msgs__srv__IsSingular_Request__Sequence
{
  upperlimb_msgs__srv__IsSingular_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__IsSingular_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/IsSingular in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__IsSingular_Response
{
  bool success;
  rosidl_runtime_c__String message;
  /// 请求的手臂关节是否在奇异位置
  bool is_singular;
} upperlimb_msgs__srv__IsSingular_Response;

// Struct for a sequence of upperlimb_msgs__srv__IsSingular_Response.
typedef struct upperlimb_msgs__srv__IsSingular_Response__Sequence
{
  upperlimb_msgs__srv__IsSingular_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__IsSingular_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__IS_SINGULAR__STRUCT_H_
