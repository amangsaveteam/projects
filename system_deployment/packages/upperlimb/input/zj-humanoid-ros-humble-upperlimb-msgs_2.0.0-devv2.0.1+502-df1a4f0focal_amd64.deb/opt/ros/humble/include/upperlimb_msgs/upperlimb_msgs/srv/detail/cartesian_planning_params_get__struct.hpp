// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:srv/CartesianPlanningParamsGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_GET__STRUCT_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_GET__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Request __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Request __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct CartesianPlanningParamsGet_Request_
{
  using Type = CartesianPlanningParamsGet_Request_<ContainerAllocator>;

  explicit CartesianPlanningParamsGet_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->arm_type = 0;
    }
  }

  explicit CartesianPlanningParamsGet_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->arm_type = 0;
    }
  }

  // field types and members
  using _arm_type_type =
    int8_t;
  _arm_type_type arm_type;

  // setters for named parameter idiom
  Type & set__arm_type(
    const int8_t & _arg)
  {
    this->arm_type = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Request
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Request
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CartesianPlanningParamsGet_Request_ & other) const
  {
    if (this->arm_type != other.arm_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const CartesianPlanningParamsGet_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CartesianPlanningParamsGet_Request_

// alias to use template instance with default allocator
using CartesianPlanningParamsGet_Request =
  upperlimb_msgs::srv::CartesianPlanningParamsGet_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Response __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Response __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct CartesianPlanningParamsGet_Response_
{
  using Type = CartesianPlanningParamsGet_Response_<ContainerAllocator>;

  explicit CartesianPlanningParamsGet_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  explicit CartesianPlanningParamsGet_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _joint_mask_type =
    std::vector<bool, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<bool>>;
  _joint_mask_type joint_mask;
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__joint_mask(
    const std::vector<bool, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<bool>> & _arg)
  {
    this->joint_mask = _arg;
    return *this;
  }
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Response
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__CartesianPlanningParamsGet_Response
    std::shared_ptr<upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CartesianPlanningParamsGet_Response_ & other) const
  {
    if (this->joint_mask != other.joint_mask) {
      return false;
    }
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const CartesianPlanningParamsGet_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CartesianPlanningParamsGet_Response_

// alias to use template instance with default allocator
using CartesianPlanningParamsGet_Response =
  upperlimb_msgs::srv::CartesianPlanningParamsGet_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs

namespace upperlimb_msgs
{

namespace srv
{

struct CartesianPlanningParamsGet
{
  using Request = upperlimb_msgs::srv::CartesianPlanningParamsGet_Request;
  using Response = upperlimb_msgs::srv::CartesianPlanningParamsGet_Response;
};

}  // namespace srv

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_GET__STRUCT_HPP_
