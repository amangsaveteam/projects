// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:msg/UplimbState.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__STRUCT_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__msg__UplimbState __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__msg__UplimbState __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct UplimbState_
{
  using Type = UplimbState_<ContainerAllocator>;

  explicit UplimbState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd_num = 0;
      this->cmd_name = "";
      this->left_arm_is_singular = false;
      this->right_arm_is_singular = false;
      this->iddp_status = false;
    }
  }

  explicit UplimbState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    cmd_name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->cmd_num = 0;
      this->cmd_name = "";
      this->left_arm_is_singular = false;
      this->right_arm_is_singular = false;
      this->iddp_status = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _cmd_num_type =
    int8_t;
  _cmd_num_type cmd_num;
  using _cmd_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _cmd_name_type cmd_name;
  using _left_arm_is_singular_type =
    bool;
  _left_arm_is_singular_type left_arm_is_singular;
  using _right_arm_is_singular_type =
    bool;
  _right_arm_is_singular_type right_arm_is_singular;
  using _iddp_status_type =
    bool;
  _iddp_status_type iddp_status;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__cmd_num(
    const int8_t & _arg)
  {
    this->cmd_num = _arg;
    return *this;
  }
  Type & set__cmd_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->cmd_name = _arg;
    return *this;
  }
  Type & set__left_arm_is_singular(
    const bool & _arg)
  {
    this->left_arm_is_singular = _arg;
    return *this;
  }
  Type & set__right_arm_is_singular(
    const bool & _arg)
  {
    this->right_arm_is_singular = _arg;
    return *this;
  }
  Type & set__iddp_status(
    const bool & _arg)
  {
    this->iddp_status = _arg;
    return *this;
  }

  // constant declarations
  static constexpr unsigned char STOPPED =
    0;
  static constexpr unsigned char MOVEJ =
    1;
  static constexpr unsigned char MOVEJ_PATH =
    2;
  static constexpr unsigned char MOVEL_NULLSPACE =
    3;
  static constexpr unsigned char MOVEL =
    4;
  static constexpr unsigned char MOVEL_PATH =
    5;
  static constexpr unsigned char SPEEDJ =
    6;
  static constexpr unsigned char SPEEDL =
    7;
  static constexpr unsigned char SPEED_STOP =
    8;
  static constexpr unsigned char MOVECSVFILE =
    9;
  static constexpr unsigned char MOVEFOURIER =
    10;
  static constexpr unsigned char MOVEJ_SPLINE =
    11;
  static constexpr unsigned char TEACH =
    12;
  static constexpr unsigned char SERVOJ =
    13;
  static constexpr unsigned char SERVOL =
    14;
  static constexpr unsigned char PROTECTED =
    15;

  // pointer types
  using RawPtr =
    upperlimb_msgs::msg::UplimbState_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::msg::UplimbState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::UplimbState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::UplimbState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__msg__UplimbState
    std::shared_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__msg__UplimbState
    std::shared_ptr<upperlimb_msgs::msg::UplimbState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const UplimbState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->cmd_num != other.cmd_num) {
      return false;
    }
    if (this->cmd_name != other.cmd_name) {
      return false;
    }
    if (this->left_arm_is_singular != other.left_arm_is_singular) {
      return false;
    }
    if (this->right_arm_is_singular != other.right_arm_is_singular) {
      return false;
    }
    if (this->iddp_status != other.iddp_status) {
      return false;
    }
    return true;
  }
  bool operator!=(const UplimbState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct UplimbState_

// alias to use template instance with default allocator
using UplimbState =
  upperlimb_msgs::msg::UplimbState_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::STOPPED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVEJ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVEJ_PATH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVEL_NULLSPACE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVEL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVEL_PATH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::SPEEDJ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::SPEEDL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::SPEED_STOP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVECSVFILE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVEFOURIER;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::MOVEJ_SPLINE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::TEACH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::SERVOJ;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::SERVOL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char UplimbState_<ContainerAllocator>::PROTECTED;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__STRUCT_HPP_
