// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:srv/BasicInfoGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__BASIC_INFO_GET_H_
#define UPPERLIMB_MSGS__SRV__BASIC_INFO_GET_H_

#include "upperlimb_msgs/srv/detail/basic_info_get__struct.h"
#include "upperlimb_msgs/srv/detail/basic_info_get__functions.h"
#include "upperlimb_msgs/srv/detail/basic_info_get__type_support.h"

#endif  // UPPERLIMB_MSGS__SRV__BASIC_INFO_GET_H_
