// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/CartesianPlanningParamsSet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_SET__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_SET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_CartesianPlanningParamsSet_Request_joint_mask
{
public:
  explicit Init_CartesianPlanningParamsSet_Request_joint_mask(::upperlimb_msgs::srv::CartesianPlanningParamsSet_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::CartesianPlanningParamsSet_Request joint_mask(::upperlimb_msgs::srv::CartesianPlanningParamsSet_Request::_joint_mask_type arg)
  {
    msg_.joint_mask = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsSet_Request msg_;
};

class Init_CartesianPlanningParamsSet_Request_arm_type
{
public:
  Init_CartesianPlanningParamsSet_Request_arm_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CartesianPlanningParamsSet_Request_joint_mask arm_type(::upperlimb_msgs::srv::CartesianPlanningParamsSet_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return Init_CartesianPlanningParamsSet_Request_joint_mask(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsSet_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::CartesianPlanningParamsSet_Request>()
{
  return upperlimb_msgs::srv::builder::Init_CartesianPlanningParamsSet_Request_arm_type();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_CartesianPlanningParamsSet_Response_message
{
public:
  explicit Init_CartesianPlanningParamsSet_Response_message(::upperlimb_msgs::srv::CartesianPlanningParamsSet_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::CartesianPlanningParamsSet_Response message(::upperlimb_msgs::srv::CartesianPlanningParamsSet_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsSet_Response msg_;
};

class Init_CartesianPlanningParamsSet_Response_success
{
public:
  Init_CartesianPlanningParamsSet_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CartesianPlanningParamsSet_Response_message success(::upperlimb_msgs::srv::CartesianPlanningParamsSet_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_CartesianPlanningParamsSet_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsSet_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::CartesianPlanningParamsSet_Response>()
{
  return upperlimb_msgs::srv::builder::Init_CartesianPlanningParamsSet_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_SET__BUILDER_HPP_
