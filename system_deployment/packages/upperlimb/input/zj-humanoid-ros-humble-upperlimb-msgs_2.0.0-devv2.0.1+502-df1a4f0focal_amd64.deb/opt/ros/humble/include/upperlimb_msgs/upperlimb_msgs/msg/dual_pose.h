// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/DualPose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DUAL_POSE_H_
#define UPPERLIMB_MSGS__MSG__DUAL_POSE_H_

#include "upperlimb_msgs/msg/detail/dual_pose__struct.h"
#include "upperlimb_msgs/msg/detail/dual_pose__functions.h"
#include "upperlimb_msgs/msg/detail/dual_pose__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__DUAL_POSE_H_
