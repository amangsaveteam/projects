// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:msg/TcpSpeed.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__TRAITS_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/msg/detail/tcp_speed__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace upperlimb_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const TcpSpeed & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: left_arm
  {
    if (msg.left_arm.size() == 0) {
      out << "left_arm: []";
    } else {
      out << "left_arm: [";
      size_t pending_items = msg.left_arm.size();
      for (auto item : msg.left_arm) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: right_arm
  {
    if (msg.right_arm.size() == 0) {
      out << "right_arm: []";
    } else {
      out << "right_arm: [";
      size_t pending_items = msg.right_arm.size();
      for (auto item : msg.right_arm) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const TcpSpeed & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: left_arm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.left_arm.size() == 0) {
      out << "left_arm: []\n";
    } else {
      out << "left_arm:\n";
      for (auto item : msg.left_arm) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: right_arm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.right_arm.size() == 0) {
      out << "right_arm: []\n";
    } else {
      out << "right_arm:\n";
      for (auto item : msg.right_arm) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const TcpSpeed & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::msg::TcpSpeed & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::msg::TcpSpeed & msg)
{
  return upperlimb_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::msg::TcpSpeed>()
{
  return "upperlimb_msgs::msg::TcpSpeed";
}

template<>
inline const char * name<upperlimb_msgs::msg::TcpSpeed>()
{
  return "upperlimb_msgs/msg/TcpSpeed";
}

template<>
struct has_fixed_size<upperlimb_msgs::msg::TcpSpeed>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::msg::TcpSpeed>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<upperlimb_msgs::msg::TcpSpeed>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__TRAITS_HPP_
