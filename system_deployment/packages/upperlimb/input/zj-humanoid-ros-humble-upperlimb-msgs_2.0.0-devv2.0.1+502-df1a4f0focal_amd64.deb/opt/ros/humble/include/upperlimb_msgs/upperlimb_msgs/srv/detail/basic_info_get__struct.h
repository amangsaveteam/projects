﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/BasicInfoGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/BasicInfoGet in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__BasicInfoGet_Request
{
  uint8_t structure_needs_at_least_one_member;
} upperlimb_msgs__srv__BasicInfoGet_Request;

// Struct for a sequence of upperlimb_msgs__srv__BasicInfoGet_Request.
typedef struct upperlimb_msgs__srv__BasicInfoGet_Request__Sequence
{
  upperlimb_msgs__srv__BasicInfoGet_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__BasicInfoGet_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"
// Member 'parts'
#include "upperlimb_msgs/msg/detail/arm_part_info__struct.h"

/// Struct defined in srv/BasicInfoGet in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__BasicInfoGet_Response
{
  bool success;
  rosidl_runtime_c__String message;
  /// 当前机型可用的掩码和
  uint8_t available_mask;
  /// 当前机型的总关节数量
  uint8_t total_joint_num;
  /// 当前机型对应的各部位信息
  upperlimb_msgs__msg__ArmPartInfo__Sequence parts;
} upperlimb_msgs__srv__BasicInfoGet_Response;

// Struct for a sequence of upperlimb_msgs__srv__BasicInfoGet_Response.
typedef struct upperlimb_msgs__srv__BasicInfoGet_Response__Sequence
{
  upperlimb_msgs__srv__BasicInfoGet_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__BasicInfoGet_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__STRUCT_H_
