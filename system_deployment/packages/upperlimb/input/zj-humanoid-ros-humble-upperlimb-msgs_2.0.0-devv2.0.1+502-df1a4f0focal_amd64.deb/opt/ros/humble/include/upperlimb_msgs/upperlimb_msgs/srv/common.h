// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:srv/Common.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__COMMON_H_
#define UPPERLIMB_MSGS__SRV__COMMON_H_

#include "upperlimb_msgs/srv/detail/common__struct.h"
#include "upperlimb_msgs/srv/detail/common__functions.h"
#include "upperlimb_msgs/srv/detail/common__type_support.h"

#endif  // UPPERLIMB_MSGS__SRV__COMMON_H_
