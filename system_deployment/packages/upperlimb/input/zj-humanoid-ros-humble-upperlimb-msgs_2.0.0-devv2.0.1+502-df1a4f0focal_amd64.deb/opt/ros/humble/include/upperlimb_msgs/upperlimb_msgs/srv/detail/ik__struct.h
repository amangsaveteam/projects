﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/IK.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__IK__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__IK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'q_init'
// Member 'q_ref'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/IK in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__IK_Request
{
  /// tcp的位姿       xyz:[m]     单臂求解使用pose[0], 双臂求解时pose[0]为左臂, pose[1]为右臂
  geometry_msgs__msg__Pose pose[2];
  /// 第七关节角       (Deprecated on 1.4.0), 该参数传入不影响实际使用
  double q7;
  /// 起始关节角                   (Add on 1.4.0), 该参数不传入默认使用当前关节位置,建议根据实际情况传入
  rosidl_runtime_c__double__Sequence q_init;
  /// 参考关节角                   (Add on 1.4.0), 该参数不传入默认使用当前关节位置,建议根据实际情况传入
  rosidl_runtime_c__double__Sequence q_ref;
  /// 参与逆解的机器人身体部位(必须有左臂或右臂或双臂的索引). 仅当全身控制时有用,用来指定当前要控制的目标部位,可以通过8421码进行叠加。参考 ArmTypeEnum.msg (Add on 1.4.0+)
  int8_t arm_type;
} upperlimb_msgs__srv__IK_Request;

// Struct for a sequence of upperlimb_msgs__srv__IK_Request.
typedef struct upperlimb_msgs__srv__IK_Request__Sequence
{
  upperlimb_msgs__srv__IK_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__IK_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"
// Member 'joints'
#include "upperlimb_msgs/msg/detail/joints__struct.h"
// Member 'arm_type'
// Member 'phi'
// already included above
// #include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/IK in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__IK_Response
{
  /// 是否有解
  bool success;
  /// 提示信息
  rosidl_runtime_c__String message;
  /// 解的数量
  int32_t nums;
  /// 关节角
  upperlimb_msgs__msg__Joints__Sequence joints;
  /// 对应关节角对应的arm_type编码  (Add on 1.4.0)
  rosidl_runtime_c__int8__Sequence arm_type;
  /// 臂角,索引与逆解后的关节角对应   (Deprecated on 1.4.0)
  rosidl_runtime_c__double__Sequence phi;
} upperlimb_msgs__srv__IK_Response;

// Struct for a sequence of upperlimb_msgs__srv__IK_Response.
typedef struct upperlimb_msgs__srv__IK_Response__Sequence
{
  upperlimb_msgs__srv__IK_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__IK_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__IK__STRUCT_H_
