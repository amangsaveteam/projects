// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:srv/ArmType.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__ARM_TYPE_H_
#define UPPERLIMB_MSGS__SRV__ARM_TYPE_H_

#include "upperlimb_msgs/srv/detail/arm_type__struct.h"
#include "upperlimb_msgs/srv/detail/arm_type__functions.h"
#include "upperlimb_msgs/srv/detail/arm_type__type_support.h"

#endif  // UPPERLIMB_MSGS__SRV__ARM_TYPE_H_
