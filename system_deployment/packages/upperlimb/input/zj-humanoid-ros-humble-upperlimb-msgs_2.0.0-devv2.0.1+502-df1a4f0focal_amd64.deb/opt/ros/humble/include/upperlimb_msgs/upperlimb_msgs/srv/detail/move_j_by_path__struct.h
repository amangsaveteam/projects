﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/MoveJByPath.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_PATH__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_PATH__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'path'
#include "upperlimb_msgs/msg/detail/joints__struct.h"
// Member 'timestamp'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/MoveJByPath in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MoveJByPath_Request
{
  /// 关节角路径,
  upperlimb_msgs__msg__Joints__Sequence path;
  /// 运行总时间。    到达最后一个路径点所需的时间. 当指定总时间时 忽略时间戳参数
  double time;
  /// 时间戳。    每一个关节角路径对应的时间戳
  rosidl_runtime_c__double__Sequence timestamp;
  /// 是否同步运行
  bool is_async;
  /// 机器人身体部位。 仅当使用全身控制时有用,用来指定当前要控制的目标部位,可以通过8421码进行叠加。参考 ArmTypeEnum.msg
  int8_t arm_type;
} upperlimb_msgs__srv__MoveJByPath_Request;

// Struct for a sequence of upperlimb_msgs__srv__MoveJByPath_Request.
typedef struct upperlimb_msgs__srv__MoveJByPath_Request__Sequence
{
  upperlimb_msgs__srv__MoveJByPath_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MoveJByPath_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/MoveJByPath in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MoveJByPath_Response
{
  /// 执行结果,该结果只反映命令的调用结果,并不能代表动作是否执行到位
  bool success;
  /// 提示信息
  rosidl_runtime_c__String message;
} upperlimb_msgs__srv__MoveJByPath_Response;

// Struct for a sequence of upperlimb_msgs__srv__MoveJByPath_Response.
typedef struct upperlimb_msgs__srv__MoveJByPath_Response__Sequence
{
  upperlimb_msgs__srv__MoveJByPath_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MoveJByPath_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_PATH__STRUCT_H_
