// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/CommonSrv.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__COMMON_SRV__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__COMMON_SRV__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/common_srv__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_CommonSrv_Request_request
{
public:
  Init_CommonSrv_Request_request()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::srv::CommonSrv_Request request(::upperlimb_msgs::srv::CommonSrv_Request::_request_type arg)
  {
    msg_.request = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::CommonSrv_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::CommonSrv_Request>()
{
  return upperlimb_msgs::srv::builder::Init_CommonSrv_Request_request();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_CommonSrv_Response_response
{
public:
  Init_CommonSrv_Response_response()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::srv::CommonSrv_Response response(::upperlimb_msgs::srv::CommonSrv_Response::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::CommonSrv_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::CommonSrv_Response>()
{
  return upperlimb_msgs::srv::builder::Init_CommonSrv_Response_response();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__COMMON_SRV__BUILDER_HPP_
