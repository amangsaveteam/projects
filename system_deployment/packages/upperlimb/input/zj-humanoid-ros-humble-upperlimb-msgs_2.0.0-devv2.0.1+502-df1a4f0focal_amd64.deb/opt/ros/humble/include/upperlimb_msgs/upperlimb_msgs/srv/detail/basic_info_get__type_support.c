// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from upperlimb_msgs:srv/BasicInfoGet.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "upperlimb_msgs/srv/detail/basic_info_get__rosidl_typesupport_introspection_c.h"
#include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "upperlimb_msgs/srv/detail/basic_info_get__functions.h"
#include "upperlimb_msgs/srv/detail/basic_info_get__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__BasicInfoGet_Request__init(message_memory);
}

void upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__BasicInfoGet_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_member_array[1] = {
  {
    "structure_needs_at_least_one_member",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__BasicInfoGet_Request, structure_needs_at_least_one_member),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "BasicInfoGet_Request",  // message name
  1,  // number of fields
  sizeof(upperlimb_msgs__srv__BasicInfoGet_Request),
  upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_member_array,  // message members
  upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, BasicInfoGet_Request)() {
  if (!upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__BasicInfoGet_Request__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "upperlimb_msgs/srv/detail/basic_info_get__rosidl_typesupport_introspection_c.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "upperlimb_msgs/srv/detail/basic_info_get__functions.h"
// already included above
// #include "upperlimb_msgs/srv/detail/basic_info_get__struct.h"


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"
// Member `parts`
#include "upperlimb_msgs/msg/arm_part_info.h"
// Member `parts`
#include "upperlimb_msgs/msg/detail/arm_part_info__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__BasicInfoGet_Response__init(message_memory);
}

void upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__BasicInfoGet_Response__fini(message_memory);
}

size_t upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__size_function__BasicInfoGet_Response__parts(
  const void * untyped_member)
{
  const upperlimb_msgs__msg__ArmPartInfo__Sequence * member =
    (const upperlimb_msgs__msg__ArmPartInfo__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__get_const_function__BasicInfoGet_Response__parts(
  const void * untyped_member, size_t index)
{
  const upperlimb_msgs__msg__ArmPartInfo__Sequence * member =
    (const upperlimb_msgs__msg__ArmPartInfo__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__get_function__BasicInfoGet_Response__parts(
  void * untyped_member, size_t index)
{
  upperlimb_msgs__msg__ArmPartInfo__Sequence * member =
    (upperlimb_msgs__msg__ArmPartInfo__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__fetch_function__BasicInfoGet_Response__parts(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const upperlimb_msgs__msg__ArmPartInfo * item =
    ((const upperlimb_msgs__msg__ArmPartInfo *)
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__get_const_function__BasicInfoGet_Response__parts(untyped_member, index));
  upperlimb_msgs__msg__ArmPartInfo * value =
    (upperlimb_msgs__msg__ArmPartInfo *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__assign_function__BasicInfoGet_Response__parts(
  void * untyped_member, size_t index, const void * untyped_value)
{
  upperlimb_msgs__msg__ArmPartInfo * item =
    ((upperlimb_msgs__msg__ArmPartInfo *)
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__get_function__BasicInfoGet_Response__parts(untyped_member, index));
  const upperlimb_msgs__msg__ArmPartInfo * value =
    (const upperlimb_msgs__msg__ArmPartInfo *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__resize_function__BasicInfoGet_Response__parts(
  void * untyped_member, size_t size)
{
  upperlimb_msgs__msg__ArmPartInfo__Sequence * member =
    (upperlimb_msgs__msg__ArmPartInfo__Sequence *)(untyped_member);
  upperlimb_msgs__msg__ArmPartInfo__Sequence__fini(member);
  return upperlimb_msgs__msg__ArmPartInfo__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_member_array[5] = {
  {
    "success",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__BasicInfoGet_Response, success),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "message",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__BasicInfoGet_Response, message),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "available_mask",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__BasicInfoGet_Response, available_mask),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "total_joint_num",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__BasicInfoGet_Response, total_joint_num),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "parts",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__BasicInfoGet_Response, parts),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__size_function__BasicInfoGet_Response__parts,  // size() function pointer
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__get_const_function__BasicInfoGet_Response__parts,  // get_const(index) function pointer
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__get_function__BasicInfoGet_Response__parts,  // get(index) function pointer
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__fetch_function__BasicInfoGet_Response__parts,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__assign_function__BasicInfoGet_Response__parts,  // assign(index, value) function pointer
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__resize_function__BasicInfoGet_Response__parts  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "BasicInfoGet_Response",  // message name
  5,  // number of fields
  sizeof(upperlimb_msgs__srv__BasicInfoGet_Response),
  upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_member_array,  // message members
  upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, BasicInfoGet_Response)() {
  upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, msg, ArmPartInfo)();
  if (!upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__BasicInfoGet_Response__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "upperlimb_msgs/srv/detail/basic_info_get__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_service_members = {
  "upperlimb_msgs__srv",  // service namespace
  "BasicInfoGet",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_Request_message_type_support_handle,
  NULL  // response message
  // upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_Response_message_type_support_handle
};

static rosidl_service_type_support_t upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_service_type_support_handle = {
  0,
  &upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, BasicInfoGet_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, BasicInfoGet_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, BasicInfoGet)() {
  if (!upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_service_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, BasicInfoGet_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, BasicInfoGet_Response)()->data;
  }

  return &upperlimb_msgs__srv__detail__basic_info_get__rosidl_typesupport_introspection_c__BasicInfoGet_service_type_support_handle;
}
