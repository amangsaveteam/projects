// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:msg/PayLoad.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__TRAITS_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/msg/detail/pay_load__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'cog'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace upperlimb_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const PayLoad & msg,
  std::ostream & out)
{
  out << "{";
  // member: mass
  {
    out << "mass: ";
    rosidl_generator_traits::value_to_yaml(msg.mass, out);
    out << ", ";
  }

  // member: cog
  {
    out << "cog: ";
    to_flow_style_yaml(msg.cog, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const PayLoad & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: mass
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mass: ";
    rosidl_generator_traits::value_to_yaml(msg.mass, out);
    out << "\n";
  }

  // member: cog
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cog:\n";
    to_block_style_yaml(msg.cog, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const PayLoad & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::msg::PayLoad & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::msg::PayLoad & msg)
{
  return upperlimb_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::msg::PayLoad>()
{
  return "upperlimb_msgs::msg::PayLoad";
}

template<>
inline const char * name<upperlimb_msgs::msg::PayLoad>()
{
  return "upperlimb_msgs/msg/PayLoad";
}

template<>
struct has_fixed_size<upperlimb_msgs::msg::PayLoad>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Point>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::msg::PayLoad>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Point>::value> {};

template<>
struct is_message<upperlimb_msgs::msg::PayLoad>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__TRAITS_HPP_
