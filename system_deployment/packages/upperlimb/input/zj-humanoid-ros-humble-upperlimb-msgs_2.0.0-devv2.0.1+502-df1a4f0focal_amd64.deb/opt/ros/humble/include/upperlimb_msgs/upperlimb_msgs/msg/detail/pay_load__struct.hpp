// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:msg/PayLoad.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__STRUCT_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'cog'
#include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__msg__PayLoad __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__msg__PayLoad __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PayLoad_
{
  using Type = PayLoad_<ContainerAllocator>;

  explicit PayLoad_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : cog(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mass = 0.0;
    }
  }

  explicit PayLoad_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : cog(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mass = 0.0;
    }
  }

  // field types and members
  using _mass_type =
    double;
  _mass_type mass;
  using _cog_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _cog_type cog;

  // setters for named parameter idiom
  Type & set__mass(
    const double & _arg)
  {
    this->mass = _arg;
    return *this;
  }
  Type & set__cog(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->cog = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::msg::PayLoad_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::msg::PayLoad_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::PayLoad_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::PayLoad_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__msg__PayLoad
    std::shared_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__msg__PayLoad
    std::shared_ptr<upperlimb_msgs::msg::PayLoad_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PayLoad_ & other) const
  {
    if (this->mass != other.mass) {
      return false;
    }
    if (this->cog != other.cog) {
      return false;
    }
    return true;
  }
  bool operator!=(const PayLoad_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PayLoad_

// alias to use template instance with default allocator
using PayLoad =
  upperlimb_msgs::msg::PayLoad_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__PAY_LOAD__STRUCT_HPP_
