﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/MoveJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'joints'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/MoveJ in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MoveJ_Request
{
  /// 关节数据,对应的关节数据维度,详情参考下方
  rosidl_runtime_c__double__Sequence joints;
  /// 最大速度
  double v;
  /// 最大加速度
  double acc;
  /// 从当前位置到目标位置的总时长;当给定该参数的时候,忽略v和acc参数.
  double t;
  /// 执行方式 true:立即返回,并且可以被打断;false:阻塞执行,等待执行完成后返回.
  bool is_async;
  /// 机器人身体部位。 仅当全身控制时有用,用来指定当前要控制的目标部位,可以通过8421码进行叠加。参考 ArmTypeEnum.msg
  int8_t arm_type;
} upperlimb_msgs__srv__MoveJ_Request;

// Struct for a sequence of upperlimb_msgs__srv__MoveJ_Request.
typedef struct upperlimb_msgs__srv__MoveJ_Request__Sequence
{
  upperlimb_msgs__srv__MoveJ_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MoveJ_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/MoveJ in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MoveJ_Response
{
  /// 执行结果,该结果只反映命令的调用结果,并不能代表动作是否执行到位
  bool success;
  /// 提示信息
  rosidl_runtime_c__String message;
} upperlimb_msgs__srv__MoveJ_Response;

// Struct for a sequence of upperlimb_msgs__srv__MoveJ_Response.
typedef struct upperlimb_msgs__srv__MoveJ_Response__Sequence
{
  upperlimb_msgs__srv__MoveJ_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MoveJ_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__STRUCT_H_
