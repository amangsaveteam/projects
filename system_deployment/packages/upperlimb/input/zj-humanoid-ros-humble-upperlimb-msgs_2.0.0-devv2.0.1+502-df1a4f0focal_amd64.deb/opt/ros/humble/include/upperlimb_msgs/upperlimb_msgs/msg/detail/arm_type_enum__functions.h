// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from upperlimb_msgs:msg/ArmTypeEnum.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__FUNCTIONS_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "upperlimb_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "upperlimb_msgs/msg/detail/arm_type_enum__struct.h"

/// Initialize msg/ArmTypeEnum message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__msg__ArmTypeEnum
 * )) before or use
 * upperlimb_msgs__msg__ArmTypeEnum__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmTypeEnum__init(upperlimb_msgs__msg__ArmTypeEnum * msg);

/// Finalize msg/ArmTypeEnum message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmTypeEnum__fini(upperlimb_msgs__msg__ArmTypeEnum * msg);

/// Create msg/ArmTypeEnum message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__msg__ArmTypeEnum__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__msg__ArmTypeEnum *
upperlimb_msgs__msg__ArmTypeEnum__create();

/// Destroy msg/ArmTypeEnum message.
/**
 * It calls
 * upperlimb_msgs__msg__ArmTypeEnum__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmTypeEnum__destroy(upperlimb_msgs__msg__ArmTypeEnum * msg);

/// Check for msg/ArmTypeEnum message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmTypeEnum__are_equal(const upperlimb_msgs__msg__ArmTypeEnum * lhs, const upperlimb_msgs__msg__ArmTypeEnum * rhs);

/// Copy a msg/ArmTypeEnum message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmTypeEnum__copy(
  const upperlimb_msgs__msg__ArmTypeEnum * input,
  upperlimb_msgs__msg__ArmTypeEnum * output);

/// Initialize array of msg/ArmTypeEnum messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__msg__ArmTypeEnum__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmTypeEnum__Sequence__init(upperlimb_msgs__msg__ArmTypeEnum__Sequence * array, size_t size);

/// Finalize array of msg/ArmTypeEnum messages.
/**
 * It calls
 * upperlimb_msgs__msg__ArmTypeEnum__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmTypeEnum__Sequence__fini(upperlimb_msgs__msg__ArmTypeEnum__Sequence * array);

/// Create array of msg/ArmTypeEnum messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__msg__ArmTypeEnum__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__msg__ArmTypeEnum__Sequence *
upperlimb_msgs__msg__ArmTypeEnum__Sequence__create(size_t size);

/// Destroy array of msg/ArmTypeEnum messages.
/**
 * It calls
 * upperlimb_msgs__msg__ArmTypeEnum__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__msg__ArmTypeEnum__Sequence__destroy(upperlimb_msgs__msg__ArmTypeEnum__Sequence * array);

/// Check for msg/ArmTypeEnum message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmTypeEnum__Sequence__are_equal(const upperlimb_msgs__msg__ArmTypeEnum__Sequence * lhs, const upperlimb_msgs__msg__ArmTypeEnum__Sequence * rhs);

/// Copy an array of msg/ArmTypeEnum messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__msg__ArmTypeEnum__Sequence__copy(
  const upperlimb_msgs__msg__ArmTypeEnum__Sequence * input,
  upperlimb_msgs__msg__ArmTypeEnum__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__FUNCTIONS_H_
