// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:srv/CartesianPlanningParamsSet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__CARTESIAN_PLANNING_PARAMS_SET_H_
#define UPPERLIMB_MSGS__SRV__CARTESIAN_PLANNING_PARAMS_SET_H_

#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__struct.h"
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__functions.h"
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_set__type_support.h"

#endif  // UPPERLIMB_MSGS__SRV__CARTESIAN_PLANNING_PARAMS_SET_H_
