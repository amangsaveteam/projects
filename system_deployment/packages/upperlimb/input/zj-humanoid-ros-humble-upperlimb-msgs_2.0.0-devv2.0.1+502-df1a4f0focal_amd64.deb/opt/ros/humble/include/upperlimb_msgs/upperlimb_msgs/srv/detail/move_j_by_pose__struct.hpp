// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:srv/MoveJByPose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_POSE__STRUCT_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_POSE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Request __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Request __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MoveJByPose_Request_
{
  using Type = MoveJByPose_Request_<ContainerAllocator>;

  explicit MoveJByPose_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pose.fill(geometry_msgs::msg::Pose_<ContainerAllocator>{_init});
      std::fill<typename std::array<double, 2>::iterator, double>(this->q7.begin(), this->q7.end(), 0.0);
      this->v = 0.0;
      this->acc = 0.0;
      this->is_async = false;
      this->arm_type = 0;
    }
  }

  explicit MoveJByPose_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pose(_alloc),
    q7(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pose.fill(geometry_msgs::msg::Pose_<ContainerAllocator>{_alloc, _init});
      std::fill<typename std::array<double, 2>::iterator, double>(this->q7.begin(), this->q7.end(), 0.0);
      this->v = 0.0;
      this->acc = 0.0;
      this->is_async = false;
      this->arm_type = 0;
    }
  }

  // field types and members
  using _pose_type =
    std::array<geometry_msgs::msg::Pose_<ContainerAllocator>, 2>;
  _pose_type pose;
  using _q7_type =
    std::array<double, 2>;
  _q7_type q7;
  using _v_type =
    double;
  _v_type v;
  using _acc_type =
    double;
  _acc_type acc;
  using _is_async_type =
    bool;
  _is_async_type is_async;
  using _arm_type_type =
    int8_t;
  _arm_type_type arm_type;

  // setters for named parameter idiom
  Type & set__pose(
    const std::array<geometry_msgs::msg::Pose_<ContainerAllocator>, 2> & _arg)
  {
    this->pose = _arg;
    return *this;
  }
  Type & set__q7(
    const std::array<double, 2> & _arg)
  {
    this->q7 = _arg;
    return *this;
  }
  Type & set__v(
    const double & _arg)
  {
    this->v = _arg;
    return *this;
  }
  Type & set__acc(
    const double & _arg)
  {
    this->acc = _arg;
    return *this;
  }
  Type & set__is_async(
    const bool & _arg)
  {
    this->is_async = _arg;
    return *this;
  }
  Type & set__arm_type(
    const int8_t & _arg)
  {
    this->arm_type = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Request
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Request
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MoveJByPose_Request_ & other) const
  {
    if (this->pose != other.pose) {
      return false;
    }
    if (this->q7 != other.q7) {
      return false;
    }
    if (this->v != other.v) {
      return false;
    }
    if (this->acc != other.acc) {
      return false;
    }
    if (this->is_async != other.is_async) {
      return false;
    }
    if (this->arm_type != other.arm_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const MoveJByPose_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MoveJByPose_Request_

// alias to use template instance with default allocator
using MoveJByPose_Request =
  upperlimb_msgs::srv::MoveJByPose_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Response __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Response __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MoveJByPose_Response_
{
  using Type = MoveJByPose_Response_<ContainerAllocator>;

  explicit MoveJByPose_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  explicit MoveJByPose_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Response
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPose_Response
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPose_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MoveJByPose_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const MoveJByPose_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MoveJByPose_Response_

// alias to use template instance with default allocator
using MoveJByPose_Response =
  upperlimb_msgs::srv::MoveJByPose_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs

namespace upperlimb_msgs
{

namespace srv
{

struct MoveJByPose
{
  using Request = upperlimb_msgs::srv::MoveJByPose_Request;
  using Response = upperlimb_msgs::srv::MoveJByPose_Response;
};

}  // namespace srv

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_POSE__STRUCT_HPP_
