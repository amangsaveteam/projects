// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from upperlimb_msgs:srv/CartesianPlanningParamsGet.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__rosidl_typesupport_introspection_c.h"
#include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__functions.h"
#include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__init(message_memory);
}

void upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_member_array[1] = {
  {
    "arm_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__CartesianPlanningParamsGet_Request, arm_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "CartesianPlanningParamsGet_Request",  // message name
  1,  // number of fields
  sizeof(upperlimb_msgs__srv__CartesianPlanningParamsGet_Request),
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_member_array,  // message members
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, CartesianPlanningParamsGet_Request)() {
  if (!upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__CartesianPlanningParamsGet_Request__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__rosidl_typesupport_introspection_c.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__functions.h"
// already included above
// #include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__struct.h"


// Include directives for member types
// Member `joint_mask`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `message`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__init(message_memory);
}

void upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__fini(message_memory);
}

size_t upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__size_function__CartesianPlanningParamsGet_Response__joint_mask(
  const void * untyped_member)
{
  const rosidl_runtime_c__boolean__Sequence * member =
    (const rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  return member->size;
}

const void * upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__get_const_function__CartesianPlanningParamsGet_Response__joint_mask(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__boolean__Sequence * member =
    (const rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  return &member->data[index];
}

void * upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__get_function__CartesianPlanningParamsGet_Response__joint_mask(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__boolean__Sequence * member =
    (rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  return &member->data[index];
}

void upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__fetch_function__CartesianPlanningParamsGet_Response__joint_mask(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const bool * item =
    ((const bool *)
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__get_const_function__CartesianPlanningParamsGet_Response__joint_mask(untyped_member, index));
  bool * value =
    (bool *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__assign_function__CartesianPlanningParamsGet_Response__joint_mask(
  void * untyped_member, size_t index, const void * untyped_value)
{
  bool * item =
    ((bool *)
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__get_function__CartesianPlanningParamsGet_Response__joint_mask(untyped_member, index));
  const bool * value =
    (const bool *)(untyped_value);
  *item = *value;
}

bool upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__resize_function__CartesianPlanningParamsGet_Response__joint_mask(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__boolean__Sequence * member =
    (rosidl_runtime_c__boolean__Sequence *)(untyped_member);
  rosidl_runtime_c__boolean__Sequence__fini(member);
  return rosidl_runtime_c__boolean__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_member_array[3] = {
  {
    "joint_mask",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__CartesianPlanningParamsGet_Response, joint_mask),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__size_function__CartesianPlanningParamsGet_Response__joint_mask,  // size() function pointer
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__get_const_function__CartesianPlanningParamsGet_Response__joint_mask,  // get_const(index) function pointer
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__get_function__CartesianPlanningParamsGet_Response__joint_mask,  // get(index) function pointer
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__fetch_function__CartesianPlanningParamsGet_Response__joint_mask,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__assign_function__CartesianPlanningParamsGet_Response__joint_mask,  // assign(index, value) function pointer
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__resize_function__CartesianPlanningParamsGet_Response__joint_mask  // resize(index) function pointer
  },
  {
    "success",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__CartesianPlanningParamsGet_Response, success),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "message",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__CartesianPlanningParamsGet_Response, message),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "CartesianPlanningParamsGet_Response",  // message name
  3,  // number of fields
  sizeof(upperlimb_msgs__srv__CartesianPlanningParamsGet_Response),
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_member_array,  // message members
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, CartesianPlanningParamsGet_Response)() {
  if (!upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__CartesianPlanningParamsGet_Response__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_service_members = {
  "upperlimb_msgs__srv",  // service namespace
  "CartesianPlanningParamsGet",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Request_message_type_support_handle,
  NULL  // response message
  // upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_Response_message_type_support_handle
};

static rosidl_service_type_support_t upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_service_type_support_handle = {
  0,
  &upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, CartesianPlanningParamsGet_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, CartesianPlanningParamsGet_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, CartesianPlanningParamsGet)() {
  if (!upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_service_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, CartesianPlanningParamsGet_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, CartesianPlanningParamsGet_Response)()->data;
  }

  return &upperlimb_msgs__srv__detail__cartesian_planning_params_get__rosidl_typesupport_introspection_c__CartesianPlanningParamsGet_service_type_support_handle;
}
