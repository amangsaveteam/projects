// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from upperlimb_msgs:msg/ArmTypeEnum.idl
// generated code does not contain a copyright notice
#include "upperlimb_msgs/msg/detail/arm_type_enum__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
upperlimb_msgs__msg__ArmTypeEnum__init(upperlimb_msgs__msg__ArmTypeEnum * msg)
{
  if (!msg) {
    return false;
  }
  // structure_needs_at_least_one_member
  return true;
}

void
upperlimb_msgs__msg__ArmTypeEnum__fini(upperlimb_msgs__msg__ArmTypeEnum * msg)
{
  if (!msg) {
    return;
  }
  // structure_needs_at_least_one_member
}

bool
upperlimb_msgs__msg__ArmTypeEnum__are_equal(const upperlimb_msgs__msg__ArmTypeEnum * lhs, const upperlimb_msgs__msg__ArmTypeEnum * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // structure_needs_at_least_one_member
  if (lhs->structure_needs_at_least_one_member != rhs->structure_needs_at_least_one_member) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__msg__ArmTypeEnum__copy(
  const upperlimb_msgs__msg__ArmTypeEnum * input,
  upperlimb_msgs__msg__ArmTypeEnum * output)
{
  if (!input || !output) {
    return false;
  }
  // structure_needs_at_least_one_member
  output->structure_needs_at_least_one_member = input->structure_needs_at_least_one_member;
  return true;
}

upperlimb_msgs__msg__ArmTypeEnum *
upperlimb_msgs__msg__ArmTypeEnum__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__ArmTypeEnum * msg = (upperlimb_msgs__msg__ArmTypeEnum *)allocator.allocate(sizeof(upperlimb_msgs__msg__ArmTypeEnum), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__msg__ArmTypeEnum));
  bool success = upperlimb_msgs__msg__ArmTypeEnum__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__msg__ArmTypeEnum__destroy(upperlimb_msgs__msg__ArmTypeEnum * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__msg__ArmTypeEnum__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__msg__ArmTypeEnum__Sequence__init(upperlimb_msgs__msg__ArmTypeEnum__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__ArmTypeEnum * data = NULL;

  if (size) {
    data = (upperlimb_msgs__msg__ArmTypeEnum *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__msg__ArmTypeEnum), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__msg__ArmTypeEnum__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__msg__ArmTypeEnum__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__msg__ArmTypeEnum__Sequence__fini(upperlimb_msgs__msg__ArmTypeEnum__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__msg__ArmTypeEnum__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__msg__ArmTypeEnum__Sequence *
upperlimb_msgs__msg__ArmTypeEnum__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__ArmTypeEnum__Sequence * array = (upperlimb_msgs__msg__ArmTypeEnum__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__msg__ArmTypeEnum__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__msg__ArmTypeEnum__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__msg__ArmTypeEnum__Sequence__destroy(upperlimb_msgs__msg__ArmTypeEnum__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__msg__ArmTypeEnum__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__msg__ArmTypeEnum__Sequence__are_equal(const upperlimb_msgs__msg__ArmTypeEnum__Sequence * lhs, const upperlimb_msgs__msg__ArmTypeEnum__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__msg__ArmTypeEnum__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__msg__ArmTypeEnum__Sequence__copy(
  const upperlimb_msgs__msg__ArmTypeEnum__Sequence * input,
  upperlimb_msgs__msg__ArmTypeEnum__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__msg__ArmTypeEnum);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__msg__ArmTypeEnum * data =
      (upperlimb_msgs__msg__ArmTypeEnum *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__msg__ArmTypeEnum__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__msg__ArmTypeEnum__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__msg__ArmTypeEnum__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
