﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:action/MotionExecute.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DETAIL__MOTION_EXECUTE__STRUCT_H_
#define UPPERLIMB_MSGS__ACTION__DETAIL__MOTION_EXECUTE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_Goal
{
  /// 动作名称(如加载时指定别名,则为别名;如加载时未指定别名则为动作文件名称)
  rosidl_runtime_c__String name;
  /// 运行到上述指定动作第一个点的最大速度
  double v;
  /// 运行到上述指定动作第一个点的最大加速度
  double acc;
  /// 从当前位置运行到上述指定动作第一个点的总时长;当给定该参数的时候,忽略v和acc参数.
  double t;
} upperlimb_msgs__action__MotionExecute_Goal;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_Goal.
typedef struct upperlimb_msgs__action__MotionExecute_Goal__Sequence
{
  upperlimb_msgs__action__MotionExecute_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_Goal__Sequence;


// Constants defined in the message

/// Constant 'SUCCESS'.
/**
  * 状态码定义
  * 执行成功
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__SUCCESS = 0
};

/// Constant 'MOTION_CANT_EXECUTE'.
/**
  * 当前无法控制(机器人状态不允许执行动作)
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOTION_CANT_EXECUTE = 1
};

/// Constant 'MOTION_NOT_FOUND'.
/**
  * 动作未找到(算法层或ROS层未加载该动作)
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOTION_NOT_FOUND = 2
};

/// Constant 'MOTION_ALREADY_RUNNING'.
/**
  * 已在执行其他动作(需要先停止当前动作)
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOTION_ALREADY_RUNNING = 3
};

/// Constant 'MOVE_TO_FIRST_POINT_FAILED'.
/**
  * 移动到第一个点失败
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOVE_TO_FIRST_POINT_FAILED = 4
};

/// Constant 'MOTION_START_FAILED'.
/**
  * 动作启动失败(preloadedTrajMove调用失败)
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOTION_START_FAILED = 5
};

/// Constant 'MOVE_TO_FIRST_POINT_PREEMPTED'.
/**
  * 移动到第一个点时被抢占
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOVE_TO_FIRST_POINT_PREEMPTED = 6
};

/// Constant 'MOTION_RUNNING_PREEMPTED'.
/**
  * 动作运行中被抢占
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOTION_RUNNING_PREEMPTED = 7
};

/// Constant 'MOTION_EXECUTION_EXCEPTION'.
/**
  * 动作执行失败(执行过程中轨迹状态异常)
 */
enum
{
  upperlimb_msgs__action__MotionExecute_Result__MOTION_EXECUTION_EXCEPTION = 8
};

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_Result
{
  /// 执行结果
  bool success;
  /// 执行结果信息
  rosidl_runtime_c__String message;
  /// 状态码
  int32_t state_code;
} upperlimb_msgs__action__MotionExecute_Result;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_Result.
typedef struct upperlimb_msgs__action__MotionExecute_Result__Sequence
{
  upperlimb_msgs__action__MotionExecute_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_Result__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'name'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_Feedback
{
  rosidl_runtime_c__String name;
  /// 执行进度百分比
  int32_t progress;
} upperlimb_msgs__action__MotionExecute_Feedback;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_Feedback.
typedef struct upperlimb_msgs__action__MotionExecute_Feedback__Sequence
{
  upperlimb_msgs__action__MotionExecute_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "upperlimb_msgs/action/detail/motion_execute__struct.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  upperlimb_msgs__action__MotionExecute_Goal goal;
} upperlimb_msgs__action__MotionExecute_SendGoal_Request;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_SendGoal_Request.
typedef struct upperlimb_msgs__action__MotionExecute_SendGoal_Request__Sequence
{
  upperlimb_msgs__action__MotionExecute_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} upperlimb_msgs__action__MotionExecute_SendGoal_Response;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_SendGoal_Response.
typedef struct upperlimb_msgs__action__MotionExecute_SendGoal_Response__Sequence
{
  upperlimb_msgs__action__MotionExecute_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} upperlimb_msgs__action__MotionExecute_GetResult_Request;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_GetResult_Request.
typedef struct upperlimb_msgs__action__MotionExecute_GetResult_Request__Sequence
{
  upperlimb_msgs__action__MotionExecute_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "upperlimb_msgs/action/detail/motion_execute__struct.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_GetResult_Response
{
  int8_t status;
  upperlimb_msgs__action__MotionExecute_Result result;
} upperlimb_msgs__action__MotionExecute_GetResult_Response;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_GetResult_Response.
typedef struct upperlimb_msgs__action__MotionExecute_GetResult_Response__Sequence
{
  upperlimb_msgs__action__MotionExecute_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "upperlimb_msgs/action/detail/motion_execute__struct.h"

/// Struct defined in action/MotionExecute in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__MotionExecute_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  upperlimb_msgs__action__MotionExecute_Feedback feedback;
} upperlimb_msgs__action__MotionExecute_FeedbackMessage;

// Struct for a sequence of upperlimb_msgs__action__MotionExecute_FeedbackMessage.
typedef struct upperlimb_msgs__action__MotionExecute_FeedbackMessage__Sequence
{
  upperlimb_msgs__action__MotionExecute_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__MotionExecute_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__ACTION__DETAIL__MOTION_EXECUTE__STRUCT_H_
