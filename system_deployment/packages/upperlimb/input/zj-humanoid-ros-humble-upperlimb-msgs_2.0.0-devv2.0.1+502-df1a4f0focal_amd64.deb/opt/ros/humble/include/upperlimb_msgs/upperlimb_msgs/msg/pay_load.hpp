// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__PAY_LOAD_HPP_
#define UPPERLIMB_MSGS__MSG__PAY_LOAD_HPP_

#include "upperlimb_msgs/msg/detail/pay_load__struct.hpp"
#include "upperlimb_msgs/msg/detail/pay_load__builder.hpp"
#include "upperlimb_msgs/msg/detail/pay_load__traits.hpp"
#include "upperlimb_msgs/msg/detail/pay_load__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__PAY_LOAD_HPP_
