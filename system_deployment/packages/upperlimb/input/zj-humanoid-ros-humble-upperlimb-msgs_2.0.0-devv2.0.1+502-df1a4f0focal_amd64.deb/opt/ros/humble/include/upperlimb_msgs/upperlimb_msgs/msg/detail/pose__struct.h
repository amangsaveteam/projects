﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/Pose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__POSE__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__POSE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'position'
#include "geometry_msgs/msg/detail/point__struct.h"
// Member 'quaternion'
#include "geometry_msgs/msg/detail/quaternion__struct.h"

/// Struct defined in msg/Pose in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__Pose
{
  /// 当前时间戳
  std_msgs__msg__Header header;
  /// [x, y, z]     单位:m
  geometry_msgs__msg__Point position;
  /// 四元素
  geometry_msgs__msg__Quaternion quaternion;
  /// [r, p, y]     弧度
  double rpy_rad[3];
  /// [r, p, y]     角度
  double rpy_deg[3];
} upperlimb_msgs__msg__Pose;

// Struct for a sequence of upperlimb_msgs__msg__Pose.
typedef struct upperlimb_msgs__msg__Pose__Sequence
{
  upperlimb_msgs__msg__Pose * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__Pose__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__POSE__STRUCT_H_
