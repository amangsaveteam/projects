﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/MotionsLoadedList.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/MotionsLoadedList in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MotionsLoadedList_Request
{
  uint8_t structure_needs_at_least_one_member;
} upperlimb_msgs__srv__MotionsLoadedList_Request;

// Struct for a sequence of upperlimb_msgs__srv__MotionsLoadedList_Request.
typedef struct upperlimb_msgs__srv__MotionsLoadedList_Request__Sequence
{
  upperlimb_msgs__srv__MotionsLoadedList_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MotionsLoadedList_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"
// Member 'motions'
#include "upperlimb_msgs/msg/detail/motion_info__struct.h"

/// Struct defined in srv/MotionsLoadedList in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MotionsLoadedList_Response
{
  bool success;
  rosidl_runtime_c__String message;
  /// 返回当前已经加载的所有动作信息
  upperlimb_msgs__msg__MotionInfo__Sequence motions;
} upperlimb_msgs__srv__MotionsLoadedList_Response;

// Struct for a sequence of upperlimb_msgs__srv__MotionsLoadedList_Response.
typedef struct upperlimb_msgs__srv__MotionsLoadedList_Response__Sequence
{
  upperlimb_msgs__srv__MotionsLoadedList_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MotionsLoadedList_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__STRUCT_H_
