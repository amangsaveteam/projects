// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:msg/ArmPartInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__STRUCT_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__msg__ArmPartInfo __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__msg__ArmPartInfo __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ArmPartInfo_
{
  using Type = ArmPartInfo_<ContainerAllocator>;

  explicit ArmPartInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mask = 0;
      this->enabled = false;
      this->joint_num = 0;
    }
  }

  explicit ArmPartInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mask = 0;
      this->enabled = false;
      this->joint_num = 0;
    }
  }

  // field types and members
  using _mask_type =
    uint8_t;
  _mask_type mask;
  using _enabled_type =
    bool;
  _enabled_type enabled;
  using _joint_num_type =
    uint8_t;
  _joint_num_type joint_num;

  // setters for named parameter idiom
  Type & set__mask(
    const uint8_t & _arg)
  {
    this->mask = _arg;
    return *this;
  }
  Type & set__enabled(
    const bool & _arg)
  {
    this->enabled = _arg;
    return *this;
  }
  Type & set__joint_num(
    const uint8_t & _arg)
  {
    this->joint_num = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__msg__ArmPartInfo
    std::shared_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__msg__ArmPartInfo
    std::shared_ptr<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ArmPartInfo_ & other) const
  {
    if (this->mask != other.mask) {
      return false;
    }
    if (this->enabled != other.enabled) {
      return false;
    }
    if (this->joint_num != other.joint_num) {
      return false;
    }
    return true;
  }
  bool operator!=(const ArmPartInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ArmPartInfo_

// alias to use template instance with default allocator
using ArmPartInfo =
  upperlimb_msgs::msg::ArmPartInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__STRUCT_HPP_
