// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/UplimbState.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__UPLIMB_STATE_H_
#define UPPERLIMB_MSGS__MSG__UPLIMB_STATE_H_

#include "upperlimb_msgs/msg/detail/uplimb_state__struct.h"
#include "upperlimb_msgs/msg/detail/uplimb_state__functions.h"
#include "upperlimb_msgs/msg/detail/uplimb_state__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__UPLIMB_STATE_H_
