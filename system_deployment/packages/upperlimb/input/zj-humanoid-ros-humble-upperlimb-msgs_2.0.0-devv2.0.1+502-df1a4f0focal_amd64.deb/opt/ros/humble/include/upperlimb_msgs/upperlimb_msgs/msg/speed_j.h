// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/SpeedJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__SPEED_J_H_
#define UPPERLIMB_MSGS__MSG__SPEED_J_H_

#include "upperlimb_msgs/msg/detail/speed_j__struct.h"
#include "upperlimb_msgs/msg/detail/speed_j__functions.h"
#include "upperlimb_msgs/msg/detail/speed_j__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__SPEED_J_H_
