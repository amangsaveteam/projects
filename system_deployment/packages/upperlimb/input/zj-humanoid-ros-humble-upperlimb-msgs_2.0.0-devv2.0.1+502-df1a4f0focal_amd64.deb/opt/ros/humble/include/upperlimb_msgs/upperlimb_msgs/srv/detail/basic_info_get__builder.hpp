// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/BasicInfoGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/basic_info_get__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::BasicInfoGet_Request>()
{
  return ::upperlimb_msgs::srv::BasicInfoGet_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_BasicInfoGet_Response_parts
{
public:
  explicit Init_BasicInfoGet_Response_parts(::upperlimb_msgs::srv::BasicInfoGet_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::BasicInfoGet_Response parts(::upperlimb_msgs::srv::BasicInfoGet_Response::_parts_type arg)
  {
    msg_.parts = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::BasicInfoGet_Response msg_;
};

class Init_BasicInfoGet_Response_total_joint_num
{
public:
  explicit Init_BasicInfoGet_Response_total_joint_num(::upperlimb_msgs::srv::BasicInfoGet_Response & msg)
  : msg_(msg)
  {}
  Init_BasicInfoGet_Response_parts total_joint_num(::upperlimb_msgs::srv::BasicInfoGet_Response::_total_joint_num_type arg)
  {
    msg_.total_joint_num = std::move(arg);
    return Init_BasicInfoGet_Response_parts(msg_);
  }

private:
  ::upperlimb_msgs::srv::BasicInfoGet_Response msg_;
};

class Init_BasicInfoGet_Response_available_mask
{
public:
  explicit Init_BasicInfoGet_Response_available_mask(::upperlimb_msgs::srv::BasicInfoGet_Response & msg)
  : msg_(msg)
  {}
  Init_BasicInfoGet_Response_total_joint_num available_mask(::upperlimb_msgs::srv::BasicInfoGet_Response::_available_mask_type arg)
  {
    msg_.available_mask = std::move(arg);
    return Init_BasicInfoGet_Response_total_joint_num(msg_);
  }

private:
  ::upperlimb_msgs::srv::BasicInfoGet_Response msg_;
};

class Init_BasicInfoGet_Response_message
{
public:
  explicit Init_BasicInfoGet_Response_message(::upperlimb_msgs::srv::BasicInfoGet_Response & msg)
  : msg_(msg)
  {}
  Init_BasicInfoGet_Response_available_mask message(::upperlimb_msgs::srv::BasicInfoGet_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_BasicInfoGet_Response_available_mask(msg_);
  }

private:
  ::upperlimb_msgs::srv::BasicInfoGet_Response msg_;
};

class Init_BasicInfoGet_Response_success
{
public:
  Init_BasicInfoGet_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BasicInfoGet_Response_message success(::upperlimb_msgs::srv::BasicInfoGet_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_BasicInfoGet_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::BasicInfoGet_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::BasicInfoGet_Response>()
{
  return upperlimb_msgs::srv::builder::Init_BasicInfoGet_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__BUILDER_HPP_
