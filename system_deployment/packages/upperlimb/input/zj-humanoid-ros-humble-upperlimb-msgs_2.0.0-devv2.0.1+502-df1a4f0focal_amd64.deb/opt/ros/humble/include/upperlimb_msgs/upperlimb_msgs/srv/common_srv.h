// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:srv/CommonSrv.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__COMMON_SRV_H_
#define UPPERLIMB_MSGS__SRV__COMMON_SRV_H_

#include "upperlimb_msgs/srv/detail/common_srv__struct.h"
#include "upperlimb_msgs/srv/detail/common_srv__functions.h"
#include "upperlimb_msgs/srv/detail/common_srv__type_support.h"

#endif  // UPPERLIMB_MSGS__SRV__COMMON_SRV_H_
