﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/FilesLists.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__FILES_LISTS__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__FILES_LISTS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/FilesLists in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__FilesLists_Request
{
  uint8_t structure_needs_at_least_one_member;
} upperlimb_msgs__srv__FilesLists_Request;

// Struct for a sequence of upperlimb_msgs__srv__FilesLists_Request.
typedef struct upperlimb_msgs__srv__FilesLists_Request__Sequence
{
  upperlimb_msgs__srv__FilesLists_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__FilesLists_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
// Member 'files'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/FilesLists in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__FilesLists_Response
{
  bool success;
  rosidl_runtime_c__String message;
  /// 返回符合要求的文件名称
  rosidl_runtime_c__String__Sequence files;
} upperlimb_msgs__srv__FilesLists_Response;

// Struct for a sequence of upperlimb_msgs__srv__FilesLists_Response.
typedef struct upperlimb_msgs__srv__FilesLists_Response__Sequence
{
  upperlimb_msgs__srv__FilesLists_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__FilesLists_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__FILES_LISTS__STRUCT_H_
