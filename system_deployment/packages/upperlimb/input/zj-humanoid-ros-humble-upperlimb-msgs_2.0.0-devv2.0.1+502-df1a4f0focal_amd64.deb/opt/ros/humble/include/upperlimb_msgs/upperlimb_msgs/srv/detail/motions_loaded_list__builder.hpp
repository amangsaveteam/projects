// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/MotionsLoadedList.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/motions_loaded_list__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MotionsLoadedList_Request>()
{
  return ::upperlimb_msgs::srv::MotionsLoadedList_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MotionsLoadedList_Response_motions
{
public:
  explicit Init_MotionsLoadedList_Response_motions(::upperlimb_msgs::srv::MotionsLoadedList_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MotionsLoadedList_Response motions(::upperlimb_msgs::srv::MotionsLoadedList_Response::_motions_type arg)
  {
    msg_.motions = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsLoadedList_Response msg_;
};

class Init_MotionsLoadedList_Response_message
{
public:
  explicit Init_MotionsLoadedList_Response_message(::upperlimb_msgs::srv::MotionsLoadedList_Response & msg)
  : msg_(msg)
  {}
  Init_MotionsLoadedList_Response_motions message(::upperlimb_msgs::srv::MotionsLoadedList_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_MotionsLoadedList_Response_motions(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsLoadedList_Response msg_;
};

class Init_MotionsLoadedList_Response_success
{
public:
  Init_MotionsLoadedList_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionsLoadedList_Response_message success(::upperlimb_msgs::srv::MotionsLoadedList_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_MotionsLoadedList_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsLoadedList_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MotionsLoadedList_Response>()
{
  return upperlimb_msgs::srv::builder::Init_MotionsLoadedList_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__BUILDER_HPP_
