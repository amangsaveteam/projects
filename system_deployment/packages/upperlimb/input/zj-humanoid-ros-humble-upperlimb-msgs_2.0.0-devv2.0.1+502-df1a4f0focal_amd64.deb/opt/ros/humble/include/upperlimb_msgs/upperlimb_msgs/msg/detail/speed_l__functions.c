// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from upperlimb_msgs:msg/SpeedL.idl
// generated code does not contain a copyright notice
#include "upperlimb_msgs/msg/detail/speed_l__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `tcp_speed`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
upperlimb_msgs__msg__SpeedL__init(upperlimb_msgs__msg__SpeedL * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    upperlimb_msgs__msg__SpeedL__fini(msg);
    return false;
  }
  // tcp_speed
  if (!rosidl_runtime_c__double__Sequence__init(&msg->tcp_speed, 0)) {
    upperlimb_msgs__msg__SpeedL__fini(msg);
    return false;
  }
  // acc
  // arm_type
  return true;
}

void
upperlimb_msgs__msg__SpeedL__fini(upperlimb_msgs__msg__SpeedL * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // tcp_speed
  rosidl_runtime_c__double__Sequence__fini(&msg->tcp_speed);
  // acc
  // arm_type
}

bool
upperlimb_msgs__msg__SpeedL__are_equal(const upperlimb_msgs__msg__SpeedL * lhs, const upperlimb_msgs__msg__SpeedL * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // tcp_speed
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->tcp_speed), &(rhs->tcp_speed)))
  {
    return false;
  }
  // acc
  if (lhs->acc != rhs->acc) {
    return false;
  }
  // arm_type
  if (lhs->arm_type != rhs->arm_type) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__msg__SpeedL__copy(
  const upperlimb_msgs__msg__SpeedL * input,
  upperlimb_msgs__msg__SpeedL * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // tcp_speed
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->tcp_speed), &(output->tcp_speed)))
  {
    return false;
  }
  // acc
  output->acc = input->acc;
  // arm_type
  output->arm_type = input->arm_type;
  return true;
}

upperlimb_msgs__msg__SpeedL *
upperlimb_msgs__msg__SpeedL__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__SpeedL * msg = (upperlimb_msgs__msg__SpeedL *)allocator.allocate(sizeof(upperlimb_msgs__msg__SpeedL), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__msg__SpeedL));
  bool success = upperlimb_msgs__msg__SpeedL__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__msg__SpeedL__destroy(upperlimb_msgs__msg__SpeedL * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__msg__SpeedL__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__msg__SpeedL__Sequence__init(upperlimb_msgs__msg__SpeedL__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__SpeedL * data = NULL;

  if (size) {
    data = (upperlimb_msgs__msg__SpeedL *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__msg__SpeedL), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__msg__SpeedL__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__msg__SpeedL__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__msg__SpeedL__Sequence__fini(upperlimb_msgs__msg__SpeedL__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__msg__SpeedL__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__msg__SpeedL__Sequence *
upperlimb_msgs__msg__SpeedL__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__SpeedL__Sequence * array = (upperlimb_msgs__msg__SpeedL__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__msg__SpeedL__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__msg__SpeedL__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__msg__SpeedL__Sequence__destroy(upperlimb_msgs__msg__SpeedL__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__msg__SpeedL__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__msg__SpeedL__Sequence__are_equal(const upperlimb_msgs__msg__SpeedL__Sequence * lhs, const upperlimb_msgs__msg__SpeedL__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__msg__SpeedL__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__msg__SpeedL__Sequence__copy(
  const upperlimb_msgs__msg__SpeedL__Sequence * input,
  upperlimb_msgs__msg__SpeedL__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__msg__SpeedL);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__msg__SpeedL * data =
      (upperlimb_msgs__msg__SpeedL *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__msg__SpeedL__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__msg__SpeedL__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__msg__SpeedL__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
