﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/ArmType.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__ARM_TYPE__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__ARM_TYPE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LEFT_ARM'.
/**
  * 左臂ID
 */
enum
{
  upperlimb_msgs__srv__ArmType_Request__LEFT_ARM = 1
};

/// Constant 'RIGHT_ARM'.
/**
  * 右臂ID
 */
enum
{
  upperlimb_msgs__srv__ArmType_Request__RIGHT_ARM = 2
};

/// Constant 'NECK'.
/**
  * 颈部ID
 */
enum
{
  upperlimb_msgs__srv__ArmType_Request__NECK = 4
};

/// Constant 'WAIST'.
/**
  * 腰部ID
 */
enum
{
  upperlimb_msgs__srv__ArmType_Request__WAIST = 8
};

/// Constant 'LIFT'.
/**
  * 升降ID
 */
enum
{
  upperlimb_msgs__srv__ArmType_Request__LIFT = 16
};

/// Struct defined in srv/ArmType in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__ArmType_Request
{
  /// 机器人类型,使用8421叠加使用。参考 ArmTypeEnum.msg
  int8_t arm_type;
} upperlimb_msgs__srv__ArmType_Request;

// Struct for a sequence of upperlimb_msgs__srv__ArmType_Request.
typedef struct upperlimb_msgs__srv__ArmType_Request__Sequence
{
  upperlimb_msgs__srv__ArmType_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__ArmType_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/ArmType in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__ArmType_Response
{
  bool success;
  rosidl_runtime_c__String message;
} upperlimb_msgs__srv__ArmType_Response;

// Struct for a sequence of upperlimb_msgs__srv__ArmType_Response.
typedef struct upperlimb_msgs__srv__ArmType_Response__Sequence
{
  upperlimb_msgs__srv__ArmType_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__ArmType_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__ARM_TYPE__STRUCT_H_
