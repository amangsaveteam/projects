// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from upperlimb_msgs:srv/FK.idl
// generated code does not contain a copyright notice
#include "upperlimb_msgs/srv/detail/fk__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `joints`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
upperlimb_msgs__srv__FK_Request__init(upperlimb_msgs__srv__FK_Request * msg)
{
  if (!msg) {
    return false;
  }
  // joints
  if (!rosidl_runtime_c__double__Sequence__init(&msg->joints, 0)) {
    upperlimb_msgs__srv__FK_Request__fini(msg);
    return false;
  }
  // arm_type
  return true;
}

void
upperlimb_msgs__srv__FK_Request__fini(upperlimb_msgs__srv__FK_Request * msg)
{
  if (!msg) {
    return;
  }
  // joints
  rosidl_runtime_c__double__Sequence__fini(&msg->joints);
  // arm_type
}

bool
upperlimb_msgs__srv__FK_Request__are_equal(const upperlimb_msgs__srv__FK_Request * lhs, const upperlimb_msgs__srv__FK_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // joints
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->joints), &(rhs->joints)))
  {
    return false;
  }
  // arm_type
  if (lhs->arm_type != rhs->arm_type) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__srv__FK_Request__copy(
  const upperlimb_msgs__srv__FK_Request * input,
  upperlimb_msgs__srv__FK_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // joints
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->joints), &(output->joints)))
  {
    return false;
  }
  // arm_type
  output->arm_type = input->arm_type;
  return true;
}

upperlimb_msgs__srv__FK_Request *
upperlimb_msgs__srv__FK_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__srv__FK_Request * msg = (upperlimb_msgs__srv__FK_Request *)allocator.allocate(sizeof(upperlimb_msgs__srv__FK_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__srv__FK_Request));
  bool success = upperlimb_msgs__srv__FK_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__srv__FK_Request__destroy(upperlimb_msgs__srv__FK_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__srv__FK_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__srv__FK_Request__Sequence__init(upperlimb_msgs__srv__FK_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__srv__FK_Request * data = NULL;

  if (size) {
    data = (upperlimb_msgs__srv__FK_Request *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__srv__FK_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__srv__FK_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__srv__FK_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__srv__FK_Request__Sequence__fini(upperlimb_msgs__srv__FK_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__srv__FK_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__srv__FK_Request__Sequence *
upperlimb_msgs__srv__FK_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__srv__FK_Request__Sequence * array = (upperlimb_msgs__srv__FK_Request__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__srv__FK_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__srv__FK_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__srv__FK_Request__Sequence__destroy(upperlimb_msgs__srv__FK_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__srv__FK_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__srv__FK_Request__Sequence__are_equal(const upperlimb_msgs__srv__FK_Request__Sequence * lhs, const upperlimb_msgs__srv__FK_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__srv__FK_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__srv__FK_Request__Sequence__copy(
  const upperlimb_msgs__srv__FK_Request__Sequence * input,
  upperlimb_msgs__srv__FK_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__srv__FK_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__srv__FK_Request * data =
      (upperlimb_msgs__srv__FK_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__srv__FK_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__srv__FK_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__srv__FK_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"
// Member `pose`
// Member `pose_array`
#include "geometry_msgs/msg/detail/pose__functions.h"
// Member `arm_type_array`
// already included above
// #include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
upperlimb_msgs__srv__FK_Response__init(upperlimb_msgs__srv__FK_Response * msg)
{
  if (!msg) {
    return false;
  }
  // success
  // message
  if (!rosidl_runtime_c__String__init(&msg->message)) {
    upperlimb_msgs__srv__FK_Response__fini(msg);
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__init(&msg->pose)) {
    upperlimb_msgs__srv__FK_Response__fini(msg);
    return false;
  }
  // arm_type
  // pose_array
  if (!geometry_msgs__msg__Pose__Sequence__init(&msg->pose_array, 0)) {
    upperlimb_msgs__srv__FK_Response__fini(msg);
    return false;
  }
  // arm_type_array
  if (!rosidl_runtime_c__int8__Sequence__init(&msg->arm_type_array, 0)) {
    upperlimb_msgs__srv__FK_Response__fini(msg);
    return false;
  }
  return true;
}

void
upperlimb_msgs__srv__FK_Response__fini(upperlimb_msgs__srv__FK_Response * msg)
{
  if (!msg) {
    return;
  }
  // success
  // message
  rosidl_runtime_c__String__fini(&msg->message);
  // pose
  geometry_msgs__msg__Pose__fini(&msg->pose);
  // arm_type
  // pose_array
  geometry_msgs__msg__Pose__Sequence__fini(&msg->pose_array);
  // arm_type_array
  rosidl_runtime_c__int8__Sequence__fini(&msg->arm_type_array);
}

bool
upperlimb_msgs__srv__FK_Response__are_equal(const upperlimb_msgs__srv__FK_Response * lhs, const upperlimb_msgs__srv__FK_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // success
  if (lhs->success != rhs->success) {
    return false;
  }
  // message
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->message), &(rhs->message)))
  {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__are_equal(
      &(lhs->pose), &(rhs->pose)))
  {
    return false;
  }
  // arm_type
  if (lhs->arm_type != rhs->arm_type) {
    return false;
  }
  // pose_array
  if (!geometry_msgs__msg__Pose__Sequence__are_equal(
      &(lhs->pose_array), &(rhs->pose_array)))
  {
    return false;
  }
  // arm_type_array
  if (!rosidl_runtime_c__int8__Sequence__are_equal(
      &(lhs->arm_type_array), &(rhs->arm_type_array)))
  {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__srv__FK_Response__copy(
  const upperlimb_msgs__srv__FK_Response * input,
  upperlimb_msgs__srv__FK_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // success
  output->success = input->success;
  // message
  if (!rosidl_runtime_c__String__copy(
      &(input->message), &(output->message)))
  {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__copy(
      &(input->pose), &(output->pose)))
  {
    return false;
  }
  // arm_type
  output->arm_type = input->arm_type;
  // pose_array
  if (!geometry_msgs__msg__Pose__Sequence__copy(
      &(input->pose_array), &(output->pose_array)))
  {
    return false;
  }
  // arm_type_array
  if (!rosidl_runtime_c__int8__Sequence__copy(
      &(input->arm_type_array), &(output->arm_type_array)))
  {
    return false;
  }
  return true;
}

upperlimb_msgs__srv__FK_Response *
upperlimb_msgs__srv__FK_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__srv__FK_Response * msg = (upperlimb_msgs__srv__FK_Response *)allocator.allocate(sizeof(upperlimb_msgs__srv__FK_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__srv__FK_Response));
  bool success = upperlimb_msgs__srv__FK_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__srv__FK_Response__destroy(upperlimb_msgs__srv__FK_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__srv__FK_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__srv__FK_Response__Sequence__init(upperlimb_msgs__srv__FK_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__srv__FK_Response * data = NULL;

  if (size) {
    data = (upperlimb_msgs__srv__FK_Response *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__srv__FK_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__srv__FK_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__srv__FK_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__srv__FK_Response__Sequence__fini(upperlimb_msgs__srv__FK_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__srv__FK_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__srv__FK_Response__Sequence *
upperlimb_msgs__srv__FK_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__srv__FK_Response__Sequence * array = (upperlimb_msgs__srv__FK_Response__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__srv__FK_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__srv__FK_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__srv__FK_Response__Sequence__destroy(upperlimb_msgs__srv__FK_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__srv__FK_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__srv__FK_Response__Sequence__are_equal(const upperlimb_msgs__srv__FK_Response__Sequence * lhs, const upperlimb_msgs__srv__FK_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__srv__FK_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__srv__FK_Response__Sequence__copy(
  const upperlimb_msgs__srv__FK_Response__Sequence * input,
  upperlimb_msgs__srv__FK_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__srv__FK_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__srv__FK_Response * data =
      (upperlimb_msgs__srv__FK_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__srv__FK_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__srv__FK_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__srv__FK_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
