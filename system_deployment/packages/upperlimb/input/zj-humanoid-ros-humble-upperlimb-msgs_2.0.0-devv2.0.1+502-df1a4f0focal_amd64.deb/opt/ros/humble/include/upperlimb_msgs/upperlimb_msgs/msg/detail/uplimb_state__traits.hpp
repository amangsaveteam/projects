// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:msg/UplimbState.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__TRAITS_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/msg/detail/uplimb_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace upperlimb_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const UplimbState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: cmd_num
  {
    out << "cmd_num: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_num, out);
    out << ", ";
  }

  // member: cmd_name
  {
    out << "cmd_name: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_name, out);
    out << ", ";
  }

  // member: left_arm_is_singular
  {
    out << "left_arm_is_singular: ";
    rosidl_generator_traits::value_to_yaml(msg.left_arm_is_singular, out);
    out << ", ";
  }

  // member: right_arm_is_singular
  {
    out << "right_arm_is_singular: ";
    rosidl_generator_traits::value_to_yaml(msg.right_arm_is_singular, out);
    out << ", ";
  }

  // member: iddp_status
  {
    out << "iddp_status: ";
    rosidl_generator_traits::value_to_yaml(msg.iddp_status, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const UplimbState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: cmd_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_num: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_num, out);
    out << "\n";
  }

  // member: cmd_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_name: ";
    rosidl_generator_traits::value_to_yaml(msg.cmd_name, out);
    out << "\n";
  }

  // member: left_arm_is_singular
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_arm_is_singular: ";
    rosidl_generator_traits::value_to_yaml(msg.left_arm_is_singular, out);
    out << "\n";
  }

  // member: right_arm_is_singular
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_arm_is_singular: ";
    rosidl_generator_traits::value_to_yaml(msg.right_arm_is_singular, out);
    out << "\n";
  }

  // member: iddp_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "iddp_status: ";
    rosidl_generator_traits::value_to_yaml(msg.iddp_status, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const UplimbState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::msg::UplimbState & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::msg::UplimbState & msg)
{
  return upperlimb_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::msg::UplimbState>()
{
  return "upperlimb_msgs::msg::UplimbState";
}

template<>
inline const char * name<upperlimb_msgs::msg::UplimbState>()
{
  return "upperlimb_msgs/msg/UplimbState";
}

template<>
struct has_fixed_size<upperlimb_msgs::msg::UplimbState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::msg::UplimbState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::msg::UplimbState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__TRAITS_HPP_
