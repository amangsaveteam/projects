// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/Pose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__POSE_H_
#define UPPERLIMB_MSGS__MSG__POSE_H_

#include "upperlimb_msgs/msg/detail/pose__struct.h"
#include "upperlimb_msgs/msg/detail/pose__functions.h"
#include "upperlimb_msgs/msg/detail/pose__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__POSE_H_
