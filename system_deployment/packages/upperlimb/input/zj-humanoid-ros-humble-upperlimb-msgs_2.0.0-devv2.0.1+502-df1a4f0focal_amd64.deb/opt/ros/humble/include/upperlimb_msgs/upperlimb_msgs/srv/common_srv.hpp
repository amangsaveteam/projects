// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__COMMON_SRV_HPP_
#define UPPERLIMB_MSGS__SRV__COMMON_SRV_HPP_

#include "upperlimb_msgs/srv/detail/common_srv__struct.hpp"
#include "upperlimb_msgs/srv/detail/common_srv__builder.hpp"
#include "upperlimb_msgs/srv/detail/common_srv__traits.hpp"
#include "upperlimb_msgs/srv/detail/common_srv__type_support.hpp"

#endif  // UPPERLIMB_MSGS__SRV__COMMON_SRV_HPP_
