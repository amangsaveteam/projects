// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/CommonMsg.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__COMMON_MSG__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__COMMON_MSG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/common_msg__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_CommonMsg_schema
{
public:
  Init_CommonMsg_schema()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::msg::CommonMsg schema(::upperlimb_msgs::msg::CommonMsg::_schema_type arg)
  {
    msg_.schema = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::CommonMsg msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::CommonMsg>()
{
  return upperlimb_msgs::msg::builder::Init_CommonMsg_schema();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__COMMON_MSG__BUILDER_HPP_
