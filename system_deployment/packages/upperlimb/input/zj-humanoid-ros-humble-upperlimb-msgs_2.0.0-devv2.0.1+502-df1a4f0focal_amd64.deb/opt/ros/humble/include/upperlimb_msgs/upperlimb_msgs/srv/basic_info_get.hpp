// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__BASIC_INFO_GET_HPP_
#define UPPERLIMB_MSGS__SRV__BASIC_INFO_GET_HPP_

#include "upperlimb_msgs/srv/detail/basic_info_get__struct.hpp"
#include "upperlimb_msgs/srv/detail/basic_info_get__builder.hpp"
#include "upperlimb_msgs/srv/detail/basic_info_get__traits.hpp"
#include "upperlimb_msgs/srv/detail/basic_info_get__type_support.hpp"

#endif  // UPPERLIMB_MSGS__SRV__BASIC_INFO_GET_HPP_
