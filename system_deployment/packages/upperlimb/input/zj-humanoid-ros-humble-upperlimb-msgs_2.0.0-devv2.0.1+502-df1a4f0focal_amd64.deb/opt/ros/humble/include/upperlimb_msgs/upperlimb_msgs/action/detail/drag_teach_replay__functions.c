// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from upperlimb_msgs:action/DragTeachReplay.idl
// generated code does not contain a copyright notice
#include "upperlimb_msgs/action/detail/drag_teach_replay__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `name`
#include "rosidl_runtime_c/string_functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_Goal__init(upperlimb_msgs__action__DragTeachReplay_Goal * msg)
{
  if (!msg) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    upperlimb_msgs__action__DragTeachReplay_Goal__fini(msg);
    return false;
  }
  // v
  // acc
  // t
  // start_time
  // end_time
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_Goal__fini(upperlimb_msgs__action__DragTeachReplay_Goal * msg)
{
  if (!msg) {
    return;
  }
  // name
  rosidl_runtime_c__String__fini(&msg->name);
  // v
  // acc
  // t
  // start_time
  // end_time
}

bool
upperlimb_msgs__action__DragTeachReplay_Goal__are_equal(const upperlimb_msgs__action__DragTeachReplay_Goal * lhs, const upperlimb_msgs__action__DragTeachReplay_Goal * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // v
  if (lhs->v != rhs->v) {
    return false;
  }
  // acc
  if (lhs->acc != rhs->acc) {
    return false;
  }
  // t
  if (lhs->t != rhs->t) {
    return false;
  }
  // start_time
  if (lhs->start_time != rhs->start_time) {
    return false;
  }
  // end_time
  if (lhs->end_time != rhs->end_time) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_Goal__copy(
  const upperlimb_msgs__action__DragTeachReplay_Goal * input,
  upperlimb_msgs__action__DragTeachReplay_Goal * output)
{
  if (!input || !output) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // v
  output->v = input->v;
  // acc
  output->acc = input->acc;
  // t
  output->t = input->t;
  // start_time
  output->start_time = input->start_time;
  // end_time
  output->end_time = input->end_time;
  return true;
}

upperlimb_msgs__action__DragTeachReplay_Goal *
upperlimb_msgs__action__DragTeachReplay_Goal__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Goal * msg = (upperlimb_msgs__action__DragTeachReplay_Goal *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_Goal), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_Goal));
  bool success = upperlimb_msgs__action__DragTeachReplay_Goal__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_Goal__destroy(upperlimb_msgs__action__DragTeachReplay_Goal * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_Goal__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__init(upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Goal * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_Goal *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_Goal), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_Goal__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_Goal__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_Goal__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_Goal__Sequence *
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_Goal__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_Goal__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_Goal__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_Goal);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_Goal * data =
      (upperlimb_msgs__action__DragTeachReplay_Goal *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_Goal__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_Goal__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_Goal__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `message`
// already included above
// #include "rosidl_runtime_c/string_functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_Result__init(upperlimb_msgs__action__DragTeachReplay_Result * msg)
{
  if (!msg) {
    return false;
  }
  // success
  // message
  if (!rosidl_runtime_c__String__init(&msg->message)) {
    upperlimb_msgs__action__DragTeachReplay_Result__fini(msg);
    return false;
  }
  // state_code
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_Result__fini(upperlimb_msgs__action__DragTeachReplay_Result * msg)
{
  if (!msg) {
    return;
  }
  // success
  // message
  rosidl_runtime_c__String__fini(&msg->message);
  // state_code
}

bool
upperlimb_msgs__action__DragTeachReplay_Result__are_equal(const upperlimb_msgs__action__DragTeachReplay_Result * lhs, const upperlimb_msgs__action__DragTeachReplay_Result * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // success
  if (lhs->success != rhs->success) {
    return false;
  }
  // message
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->message), &(rhs->message)))
  {
    return false;
  }
  // state_code
  if (lhs->state_code != rhs->state_code) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_Result__copy(
  const upperlimb_msgs__action__DragTeachReplay_Result * input,
  upperlimb_msgs__action__DragTeachReplay_Result * output)
{
  if (!input || !output) {
    return false;
  }
  // success
  output->success = input->success;
  // message
  if (!rosidl_runtime_c__String__copy(
      &(input->message), &(output->message)))
  {
    return false;
  }
  // state_code
  output->state_code = input->state_code;
  return true;
}

upperlimb_msgs__action__DragTeachReplay_Result *
upperlimb_msgs__action__DragTeachReplay_Result__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Result * msg = (upperlimb_msgs__action__DragTeachReplay_Result *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_Result), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_Result));
  bool success = upperlimb_msgs__action__DragTeachReplay_Result__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_Result__destroy(upperlimb_msgs__action__DragTeachReplay_Result * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_Result__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__init(upperlimb_msgs__action__DragTeachReplay_Result__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Result * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_Result *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_Result), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_Result__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_Result__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_Result__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_Result__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_Result__Sequence *
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Result__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_Result__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_Result__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_Result__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_Result__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_Result__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_Result__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_Result__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_Result__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_Result__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_Result__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_Result);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_Result * data =
      (upperlimb_msgs__action__DragTeachReplay_Result *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_Result__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_Result__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_Result__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `name`
// already included above
// #include "rosidl_runtime_c/string_functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_Feedback__init(upperlimb_msgs__action__DragTeachReplay_Feedback * msg)
{
  if (!msg) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    upperlimb_msgs__action__DragTeachReplay_Feedback__fini(msg);
    return false;
  }
  // progress
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_Feedback__fini(upperlimb_msgs__action__DragTeachReplay_Feedback * msg)
{
  if (!msg) {
    return;
  }
  // name
  rosidl_runtime_c__String__fini(&msg->name);
  // progress
}

bool
upperlimb_msgs__action__DragTeachReplay_Feedback__are_equal(const upperlimb_msgs__action__DragTeachReplay_Feedback * lhs, const upperlimb_msgs__action__DragTeachReplay_Feedback * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // progress
  if (lhs->progress != rhs->progress) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_Feedback__copy(
  const upperlimb_msgs__action__DragTeachReplay_Feedback * input,
  upperlimb_msgs__action__DragTeachReplay_Feedback * output)
{
  if (!input || !output) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // progress
  output->progress = input->progress;
  return true;
}

upperlimb_msgs__action__DragTeachReplay_Feedback *
upperlimb_msgs__action__DragTeachReplay_Feedback__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Feedback * msg = (upperlimb_msgs__action__DragTeachReplay_Feedback *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_Feedback), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_Feedback));
  bool success = upperlimb_msgs__action__DragTeachReplay_Feedback__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_Feedback__destroy(upperlimb_msgs__action__DragTeachReplay_Feedback * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_Feedback__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__init(upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Feedback * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_Feedback *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_Feedback), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_Feedback__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_Feedback__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_Feedback__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence *
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_Feedback__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_Feedback);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_Feedback * data =
      (upperlimb_msgs__action__DragTeachReplay_Feedback *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_Feedback__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_Feedback__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_Feedback__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `goal_id`
#include "unique_identifier_msgs/msg/detail/uuid__functions.h"
// Member `goal`
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_replay__functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * msg)
{
  if (!msg) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__init(&msg->goal_id)) {
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(msg);
    return false;
  }
  // goal
  if (!upperlimb_msgs__action__DragTeachReplay_Goal__init(&msg->goal)) {
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(msg);
    return false;
  }
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * msg)
{
  if (!msg) {
    return;
  }
  // goal_id
  unique_identifier_msgs__msg__UUID__fini(&msg->goal_id);
  // goal
  upperlimb_msgs__action__DragTeachReplay_Goal__fini(&msg->goal);
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__are_equal(
      &(lhs->goal_id), &(rhs->goal_id)))
  {
    return false;
  }
  // goal
  if (!upperlimb_msgs__action__DragTeachReplay_Goal__are_equal(
      &(lhs->goal), &(rhs->goal)))
  {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__copy(
      &(input->goal_id), &(output->goal_id)))
  {
    return false;
  }
  // goal
  if (!upperlimb_msgs__action__DragTeachReplay_Goal__copy(
      &(input->goal), &(output->goal)))
  {
    return false;
  }
  return true;
}

upperlimb_msgs__action__DragTeachReplay_SendGoal_Request *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * msg = (upperlimb_msgs__action__DragTeachReplay_SendGoal_Request *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request));
  bool success = upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_SendGoal_Request *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * data =
      (upperlimb_msgs__action__DragTeachReplay_SendGoal_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `stamp`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * msg)
{
  if (!msg) {
    return false;
  }
  // accepted
  // stamp
  if (!builtin_interfaces__msg__Time__init(&msg->stamp)) {
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini(msg);
    return false;
  }
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * msg)
{
  if (!msg) {
    return;
  }
  // accepted
  // stamp
  builtin_interfaces__msg__Time__fini(&msg->stamp);
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // accepted
  if (lhs->accepted != rhs->accepted) {
    return false;
  }
  // stamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->stamp), &(rhs->stamp)))
  {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // accepted
  output->accepted = input->accepted;
  // stamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->stamp), &(output->stamp)))
  {
    return false;
  }
  return true;
}

upperlimb_msgs__action__DragTeachReplay_SendGoal_Response *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * msg = (upperlimb_msgs__action__DragTeachReplay_SendGoal_Response *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response));
  bool success = upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_SendGoal_Response *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * data =
      (upperlimb_msgs__action__DragTeachReplay_SendGoal_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Request * msg)
{
  if (!msg) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__init(&msg->goal_id)) {
    upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini(msg);
    return false;
  }
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Request * msg)
{
  if (!msg) {
    return;
  }
  // goal_id
  unique_identifier_msgs__msg__UUID__fini(&msg->goal_id);
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Request * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__are_equal(
      &(lhs->goal_id), &(rhs->goal_id)))
  {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Request * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__copy(
      &(input->goal_id), &(output->goal_id)))
  {
    return false;
  }
  return true;
}

upperlimb_msgs__action__DragTeachReplay_GetResult_Request *
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request * msg = (upperlimb_msgs__action__DragTeachReplay_GetResult_Request *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Request));
  bool success = upperlimb_msgs__action__DragTeachReplay_GetResult_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_GetResult_Request *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_GetResult_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence *
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_GetResult_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_GetResult_Request * data =
      (upperlimb_msgs__action__DragTeachReplay_GetResult_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_GetResult_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_GetResult_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `result`
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_replay__functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Response * msg)
{
  if (!msg) {
    return false;
  }
  // status
  // result
  if (!upperlimb_msgs__action__DragTeachReplay_Result__init(&msg->result)) {
    upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini(msg);
    return false;
  }
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Response * msg)
{
  if (!msg) {
    return;
  }
  // status
  // result
  upperlimb_msgs__action__DragTeachReplay_Result__fini(&msg->result);
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Response * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // status
  if (lhs->status != rhs->status) {
    return false;
  }
  // result
  if (!upperlimb_msgs__action__DragTeachReplay_Result__are_equal(
      &(lhs->result), &(rhs->result)))
  {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Response * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // status
  output->status = input->status;
  // result
  if (!upperlimb_msgs__action__DragTeachReplay_Result__copy(
      &(input->result), &(output->result)))
  {
    return false;
  }
  return true;
}

upperlimb_msgs__action__DragTeachReplay_GetResult_Response *
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response * msg = (upperlimb_msgs__action__DragTeachReplay_GetResult_Response *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Response));
  bool success = upperlimb_msgs__action__DragTeachReplay_GetResult_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_GetResult_Response *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_GetResult_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence *
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_GetResult_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_GetResult_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_GetResult_Response * data =
      (upperlimb_msgs__action__DragTeachReplay_GetResult_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_GetResult_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_GetResult_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `goal_id`
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__functions.h"
// Member `feedback`
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_replay__functions.h"

bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__init(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * msg)
{
  if (!msg) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__init(&msg->goal_id)) {
    upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(msg);
    return false;
  }
  // feedback
  if (!upperlimb_msgs__action__DragTeachReplay_Feedback__init(&msg->feedback)) {
    upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(msg);
    return false;
  }
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * msg)
{
  if (!msg) {
    return;
  }
  // goal_id
  unique_identifier_msgs__msg__UUID__fini(&msg->goal_id);
  // feedback
  upperlimb_msgs__action__DragTeachReplay_Feedback__fini(&msg->feedback);
}

bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__are_equal(const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * lhs, const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__are_equal(
      &(lhs->goal_id), &(rhs->goal_id)))
  {
    return false;
  }
  // feedback
  if (!upperlimb_msgs__action__DragTeachReplay_Feedback__are_equal(
      &(lhs->feedback), &(rhs->feedback)))
  {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__copy(
  const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * input,
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * output)
{
  if (!input || !output) {
    return false;
  }
  // goal_id
  if (!unique_identifier_msgs__msg__UUID__copy(
      &(input->goal_id), &(output->goal_id)))
  {
    return false;
  }
  // feedback
  if (!upperlimb_msgs__action__DragTeachReplay_Feedback__copy(
      &(input->feedback), &(output->feedback)))
  {
    return false;
  }
  return true;
}

upperlimb_msgs__action__DragTeachReplay_FeedbackMessage *
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * msg = (upperlimb_msgs__action__DragTeachReplay_FeedbackMessage *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage));
  bool success = upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__destroy(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__init(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * data = NULL;

  if (size) {
    data = (upperlimb_msgs__action__DragTeachReplay_FeedbackMessage *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence *
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * array = (upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * data =
      (upperlimb_msgs__action__DragTeachReplay_FeedbackMessage *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
