// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__MOTION_INFO_HPP_
#define UPPERLIMB_MSGS__MSG__MOTION_INFO_HPP_

#include "upperlimb_msgs/msg/detail/motion_info__struct.hpp"
#include "upperlimb_msgs/msg/detail/motion_info__builder.hpp"
#include "upperlimb_msgs/msg/detail/motion_info__traits.hpp"
#include "upperlimb_msgs/msg/detail/motion_info__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__MOTION_INFO_HPP_
