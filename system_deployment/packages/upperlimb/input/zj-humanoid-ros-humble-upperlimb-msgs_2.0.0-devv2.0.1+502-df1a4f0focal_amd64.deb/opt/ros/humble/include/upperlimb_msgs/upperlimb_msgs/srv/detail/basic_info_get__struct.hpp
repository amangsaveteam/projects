// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:srv/BasicInfoGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__STRUCT_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Request __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Request __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct BasicInfoGet_Request_
{
  using Type = BasicInfoGet_Request_<ContainerAllocator>;

  explicit BasicInfoGet_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->structure_needs_at_least_one_member = 0;
    }
  }

  explicit BasicInfoGet_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->structure_needs_at_least_one_member = 0;
    }
  }

  // field types and members
  using _structure_needs_at_least_one_member_type =
    uint8_t;
  _structure_needs_at_least_one_member_type structure_needs_at_least_one_member;


  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Request
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Request
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BasicInfoGet_Request_ & other) const
  {
    if (this->structure_needs_at_least_one_member != other.structure_needs_at_least_one_member) {
      return false;
    }
    return true;
  }
  bool operator!=(const BasicInfoGet_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BasicInfoGet_Request_

// alias to use template instance with default allocator
using BasicInfoGet_Request =
  upperlimb_msgs::srv::BasicInfoGet_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs


// Include directives for member types
// Member 'parts'
#include "upperlimb_msgs/msg/detail/arm_part_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Response __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Response __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct BasicInfoGet_Response_
{
  using Type = BasicInfoGet_Response_<ContainerAllocator>;

  explicit BasicInfoGet_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->available_mask = 0;
      this->total_joint_num = 0;
    }
  }

  explicit BasicInfoGet_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->available_mask = 0;
      this->total_joint_num = 0;
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;
  using _available_mask_type =
    uint8_t;
  _available_mask_type available_mask;
  using _total_joint_num_type =
    uint8_t;
  _total_joint_num_type total_joint_num;
  using _parts_type =
    std::vector<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>>>;
  _parts_type parts;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }
  Type & set__available_mask(
    const uint8_t & _arg)
  {
    this->available_mask = _arg;
    return *this;
  }
  Type & set__total_joint_num(
    const uint8_t & _arg)
  {
    this->total_joint_num = _arg;
    return *this;
  }
  Type & set__parts(
    const std::vector<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<upperlimb_msgs::msg::ArmPartInfo_<ContainerAllocator>>> & _arg)
  {
    this->parts = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Response
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__BasicInfoGet_Response
    std::shared_ptr<upperlimb_msgs::srv::BasicInfoGet_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BasicInfoGet_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    if (this->available_mask != other.available_mask) {
      return false;
    }
    if (this->total_joint_num != other.total_joint_num) {
      return false;
    }
    if (this->parts != other.parts) {
      return false;
    }
    return true;
  }
  bool operator!=(const BasicInfoGet_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BasicInfoGet_Response_

// alias to use template instance with default allocator
using BasicInfoGet_Response =
  upperlimb_msgs::srv::BasicInfoGet_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs

namespace upperlimb_msgs
{

namespace srv
{

struct BasicInfoGet
{
  using Request = upperlimb_msgs::srv::BasicInfoGet_Request;
  using Response = upperlimb_msgs::srv::BasicInfoGet_Response;
};

}  // namespace srv

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__BASIC_INFO_GET__STRUCT_HPP_
