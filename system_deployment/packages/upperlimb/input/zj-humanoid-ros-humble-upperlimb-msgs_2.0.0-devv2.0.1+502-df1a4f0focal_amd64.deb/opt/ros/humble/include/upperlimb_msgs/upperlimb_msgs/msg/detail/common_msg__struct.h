// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/CommonMsg.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__COMMON_MSG__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__COMMON_MSG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'schema'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/CommonMsg in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__CommonMsg
{
  rosidl_runtime_c__String schema;
} upperlimb_msgs__msg__CommonMsg;

// Struct for a sequence of upperlimb_msgs__msg__CommonMsg.
typedef struct upperlimb_msgs__msg__CommonMsg__Sequence
{
  upperlimb_msgs__msg__CommonMsg * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__CommonMsg__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__COMMON_MSG__STRUCT_H_
