﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/UplimbState.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'STOPPED'.
enum
{
  upperlimb_msgs__msg__UplimbState__STOPPED = 0
};

/// Constant 'MOVEJ'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVEJ = 1
};

/// Constant 'MOVEJ_PATH'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVEJ_PATH = 2
};

/// Constant 'MOVEL_NULLSPACE'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVEL_NULLSPACE = 3
};

/// Constant 'MOVEL'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVEL = 4
};

/// Constant 'MOVEL_PATH'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVEL_PATH = 5
};

/// Constant 'SPEEDJ'.
enum
{
  upperlimb_msgs__msg__UplimbState__SPEEDJ = 6
};

/// Constant 'SPEEDL'.
enum
{
  upperlimb_msgs__msg__UplimbState__SPEEDL = 7
};

/// Constant 'SPEED_STOP'.
enum
{
  upperlimb_msgs__msg__UplimbState__SPEED_STOP = 8
};

/// Constant 'MOVECSVFILE'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVECSVFILE = 9
};

/// Constant 'MOVEFOURIER'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVEFOURIER = 10
};

/// Constant 'MOVEJ_SPLINE'.
enum
{
  upperlimb_msgs__msg__UplimbState__MOVEJ_SPLINE = 11
};

/// Constant 'TEACH'.
enum
{
  upperlimb_msgs__msg__UplimbState__TEACH = 12
};

/// Constant 'SERVOJ'.
enum
{
  upperlimb_msgs__msg__UplimbState__SERVOJ = 13
};

/// Constant 'SERVOL'.
enum
{
  upperlimb_msgs__msg__UplimbState__SERVOL = 14
};

/// Constant 'PROTECTED'.
enum
{
  upperlimb_msgs__msg__UplimbState__PROTECTED = 15
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'cmd_name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/UplimbState in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__UplimbState
{
  /// 当前时间戳
  std_msgs__msg__Header header;
  /// 当前运行状态码
  int8_t cmd_num;
  /// 当前运行状态名称
  rosidl_runtime_c__String cmd_name;
  /// 当前左臂是否奇异
  bool left_arm_is_singular;
  /// 当前右臂是否奇异
  bool right_arm_is_singular;
  /// iddp链接状态
  bool iddp_status;
} upperlimb_msgs__msg__UplimbState;

// Struct for a sequence of upperlimb_msgs__msg__UplimbState.
typedef struct upperlimb_msgs__msg__UplimbState__Sequence
{
  upperlimb_msgs__msg__UplimbState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__UplimbState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__STRUCT_H_
