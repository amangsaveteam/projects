// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/TcpSpeed.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__TCP_SPEED_H_
#define UPPERLIMB_MSGS__MSG__TCP_SPEED_H_

#include "upperlimb_msgs/msg/detail/tcp_speed__struct.h"
#include "upperlimb_msgs/msg/detail/tcp_speed__functions.h"
#include "upperlimb_msgs/msg/detail/tcp_speed__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__TCP_SPEED_H_
