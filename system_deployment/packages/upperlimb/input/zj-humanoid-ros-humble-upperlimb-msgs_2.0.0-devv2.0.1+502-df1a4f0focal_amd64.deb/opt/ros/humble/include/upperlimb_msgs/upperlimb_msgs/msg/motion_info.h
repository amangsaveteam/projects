// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/MotionInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__MOTION_INFO_H_
#define UPPERLIMB_MSGS__MSG__MOTION_INFO_H_

#include "upperlimb_msgs/msg/detail/motion_info__struct.h"
#include "upperlimb_msgs/msg/detail/motion_info__functions.h"
#include "upperlimb_msgs/msg/detail/motion_info__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__MOTION_INFO_H_
