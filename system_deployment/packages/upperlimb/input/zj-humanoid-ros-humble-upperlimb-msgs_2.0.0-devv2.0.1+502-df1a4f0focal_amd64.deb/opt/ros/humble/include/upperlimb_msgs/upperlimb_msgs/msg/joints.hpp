// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__JOINTS_HPP_
#define UPPERLIMB_MSGS__MSG__JOINTS_HPP_

#include "upperlimb_msgs/msg/detail/joints__struct.hpp"
#include "upperlimb_msgs/msg/detail/joints__builder.hpp"
#include "upperlimb_msgs/msg/detail/joints__traits.hpp"
#include "upperlimb_msgs/msg/detail/joints__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__JOINTS_HPP_
