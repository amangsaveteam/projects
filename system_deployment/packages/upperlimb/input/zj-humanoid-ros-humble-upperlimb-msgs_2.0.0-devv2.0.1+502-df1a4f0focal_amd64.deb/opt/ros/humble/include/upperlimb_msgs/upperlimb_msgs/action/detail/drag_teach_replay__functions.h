// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from upperlimb_msgs:action/DragTeachReplay.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__FUNCTIONS_H_
#define UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "upperlimb_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "upperlimb_msgs/action/detail/drag_teach_replay__struct.h"

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_Goal
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_Goal__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Goal__init(upperlimb_msgs__action__DragTeachReplay_Goal * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Goal__fini(upperlimb_msgs__action__DragTeachReplay_Goal * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_Goal__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_Goal *
upperlimb_msgs__action__DragTeachReplay_Goal__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Goal__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Goal__destroy(upperlimb_msgs__action__DragTeachReplay_Goal * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Goal__are_equal(const upperlimb_msgs__action__DragTeachReplay_Goal * lhs, const upperlimb_msgs__action__DragTeachReplay_Goal * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Goal__copy(
  const upperlimb_msgs__action__DragTeachReplay_Goal * input,
  upperlimb_msgs__action__DragTeachReplay_Goal * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_Goal__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__init(upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Goal__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence *
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Goal__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_Goal__Sequence * output);

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_Result
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_Result__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Result__init(upperlimb_msgs__action__DragTeachReplay_Result * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Result__fini(upperlimb_msgs__action__DragTeachReplay_Result * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_Result__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_Result *
upperlimb_msgs__action__DragTeachReplay_Result__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Result__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Result__destroy(upperlimb_msgs__action__DragTeachReplay_Result * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Result__are_equal(const upperlimb_msgs__action__DragTeachReplay_Result * lhs, const upperlimb_msgs__action__DragTeachReplay_Result * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Result__copy(
  const upperlimb_msgs__action__DragTeachReplay_Result * input,
  upperlimb_msgs__action__DragTeachReplay_Result * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_Result__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__init(upperlimb_msgs__action__DragTeachReplay_Result__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Result__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_Result__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_Result__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_Result__Sequence *
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Result__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_Result__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_Result__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_Result__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Result__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_Result__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_Result__Sequence * output);

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_Feedback
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_Feedback__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Feedback__init(upperlimb_msgs__action__DragTeachReplay_Feedback * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Feedback__fini(upperlimb_msgs__action__DragTeachReplay_Feedback * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_Feedback__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_Feedback *
upperlimb_msgs__action__DragTeachReplay_Feedback__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Feedback__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Feedback__destroy(upperlimb_msgs__action__DragTeachReplay_Feedback * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Feedback__are_equal(const upperlimb_msgs__action__DragTeachReplay_Feedback * lhs, const upperlimb_msgs__action__DragTeachReplay_Feedback * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Feedback__copy(
  const upperlimb_msgs__action__DragTeachReplay_Feedback * input,
  upperlimb_msgs__action__DragTeachReplay_Feedback * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_Feedback__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__init(upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Feedback__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence *
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence * output);

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence * output);

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__init(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence *
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence * output);

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Request * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Request * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_GetResult_Request *
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Request * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Request * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Request * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Request * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence *
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence * output);

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Response * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Response * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_GetResult_Response *
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Response * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Response * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Response * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Response * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__init(upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence *
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence * output);

/// Initialize action/DragTeachReplay message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage
 * )) before or use
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__init(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * msg);

/// Finalize action/DragTeachReplay message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * msg);

/// Create action/DragTeachReplay message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage *
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__create();

/// Destroy action/DragTeachReplay message.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__destroy(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * msg);

/// Check for action/DragTeachReplay message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__are_equal(const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * lhs, const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * rhs);

/// Copy a action/DragTeachReplay message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__copy(
  const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * input,
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * output);

/// Initialize array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the number of elements and calls
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__init(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * array, size_t size);

/// Finalize array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__fini(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * array);

/// Create array of action/DragTeachReplay messages.
/**
 * It allocates the memory for the array and calls
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence *
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__create(size_t size);

/// Destroy array of action/DragTeachReplay messages.
/**
 * It calls
 * upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
void
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__destroy(upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * array);

/// Check for action/DragTeachReplay message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__are_equal(const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * lhs, const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * rhs);

/// Copy an array of action/DragTeachReplay messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_upperlimb_msgs
bool
upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence__copy(
  const upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * input,
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__FUNCTIONS_H_
