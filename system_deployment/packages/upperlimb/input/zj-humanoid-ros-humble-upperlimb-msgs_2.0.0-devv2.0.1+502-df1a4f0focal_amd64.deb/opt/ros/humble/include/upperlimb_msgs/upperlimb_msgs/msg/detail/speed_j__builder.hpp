// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/SpeedJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/speed_j__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_SpeedJ_arm_type
{
public:
  explicit Init_SpeedJ_arm_type(::upperlimb_msgs::msg::SpeedJ & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::SpeedJ arm_type(::upperlimb_msgs::msg::SpeedJ::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedJ msg_;
};

class Init_SpeedJ_acc
{
public:
  explicit Init_SpeedJ_acc(::upperlimb_msgs::msg::SpeedJ & msg)
  : msg_(msg)
  {}
  Init_SpeedJ_arm_type acc(::upperlimb_msgs::msg::SpeedJ::_acc_type arg)
  {
    msg_.acc = std::move(arg);
    return Init_SpeedJ_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedJ msg_;
};

class Init_SpeedJ_joint_speed
{
public:
  explicit Init_SpeedJ_joint_speed(::upperlimb_msgs::msg::SpeedJ & msg)
  : msg_(msg)
  {}
  Init_SpeedJ_acc joint_speed(::upperlimb_msgs::msg::SpeedJ::_joint_speed_type arg)
  {
    msg_.joint_speed = std::move(arg);
    return Init_SpeedJ_acc(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedJ msg_;
};

class Init_SpeedJ_header
{
public:
  Init_SpeedJ_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SpeedJ_joint_speed header(::upperlimb_msgs::msg::SpeedJ::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SpeedJ_joint_speed(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedJ msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::SpeedJ>()
{
  return upperlimb_msgs::msg::builder::Init_SpeedJ_header();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__BUILDER_HPP_
