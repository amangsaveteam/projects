// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from upperlimb_msgs:msg/MotionInfo.idl
// generated code does not contain a copyright notice
#include "upperlimb_msgs/msg/detail/motion_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `filename`
// Member `alias`
#include "rosidl_runtime_c/string_functions.h"
// Member `joints`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
upperlimb_msgs__msg__MotionInfo__init(upperlimb_msgs__msg__MotionInfo * msg)
{
  if (!msg) {
    return false;
  }
  // filename
  if (!rosidl_runtime_c__String__init(&msg->filename)) {
    upperlimb_msgs__msg__MotionInfo__fini(msg);
    return false;
  }
  // alias
  if (!rosidl_runtime_c__String__init(&msg->alias)) {
    upperlimb_msgs__msg__MotionInfo__fini(msg);
    return false;
  }
  // arm_type
  // joints
  if (!rosidl_runtime_c__double__Sequence__init(&msg->joints, 0)) {
    upperlimb_msgs__msg__MotionInfo__fini(msg);
    return false;
  }
  // number
  return true;
}

void
upperlimb_msgs__msg__MotionInfo__fini(upperlimb_msgs__msg__MotionInfo * msg)
{
  if (!msg) {
    return;
  }
  // filename
  rosidl_runtime_c__String__fini(&msg->filename);
  // alias
  rosidl_runtime_c__String__fini(&msg->alias);
  // arm_type
  // joints
  rosidl_runtime_c__double__Sequence__fini(&msg->joints);
  // number
}

bool
upperlimb_msgs__msg__MotionInfo__are_equal(const upperlimb_msgs__msg__MotionInfo * lhs, const upperlimb_msgs__msg__MotionInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // filename
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->filename), &(rhs->filename)))
  {
    return false;
  }
  // alias
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->alias), &(rhs->alias)))
  {
    return false;
  }
  // arm_type
  if (lhs->arm_type != rhs->arm_type) {
    return false;
  }
  // joints
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->joints), &(rhs->joints)))
  {
    return false;
  }
  // number
  if (lhs->number != rhs->number) {
    return false;
  }
  return true;
}

bool
upperlimb_msgs__msg__MotionInfo__copy(
  const upperlimb_msgs__msg__MotionInfo * input,
  upperlimb_msgs__msg__MotionInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // filename
  if (!rosidl_runtime_c__String__copy(
      &(input->filename), &(output->filename)))
  {
    return false;
  }
  // alias
  if (!rosidl_runtime_c__String__copy(
      &(input->alias), &(output->alias)))
  {
    return false;
  }
  // arm_type
  output->arm_type = input->arm_type;
  // joints
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->joints), &(output->joints)))
  {
    return false;
  }
  // number
  output->number = input->number;
  return true;
}

upperlimb_msgs__msg__MotionInfo *
upperlimb_msgs__msg__MotionInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__MotionInfo * msg = (upperlimb_msgs__msg__MotionInfo *)allocator.allocate(sizeof(upperlimb_msgs__msg__MotionInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(upperlimb_msgs__msg__MotionInfo));
  bool success = upperlimb_msgs__msg__MotionInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
upperlimb_msgs__msg__MotionInfo__destroy(upperlimb_msgs__msg__MotionInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    upperlimb_msgs__msg__MotionInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
upperlimb_msgs__msg__MotionInfo__Sequence__init(upperlimb_msgs__msg__MotionInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__MotionInfo * data = NULL;

  if (size) {
    data = (upperlimb_msgs__msg__MotionInfo *)allocator.zero_allocate(size, sizeof(upperlimb_msgs__msg__MotionInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = upperlimb_msgs__msg__MotionInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        upperlimb_msgs__msg__MotionInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
upperlimb_msgs__msg__MotionInfo__Sequence__fini(upperlimb_msgs__msg__MotionInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      upperlimb_msgs__msg__MotionInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

upperlimb_msgs__msg__MotionInfo__Sequence *
upperlimb_msgs__msg__MotionInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  upperlimb_msgs__msg__MotionInfo__Sequence * array = (upperlimb_msgs__msg__MotionInfo__Sequence *)allocator.allocate(sizeof(upperlimb_msgs__msg__MotionInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = upperlimb_msgs__msg__MotionInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
upperlimb_msgs__msg__MotionInfo__Sequence__destroy(upperlimb_msgs__msg__MotionInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    upperlimb_msgs__msg__MotionInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
upperlimb_msgs__msg__MotionInfo__Sequence__are_equal(const upperlimb_msgs__msg__MotionInfo__Sequence * lhs, const upperlimb_msgs__msg__MotionInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!upperlimb_msgs__msg__MotionInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
upperlimb_msgs__msg__MotionInfo__Sequence__copy(
  const upperlimb_msgs__msg__MotionInfo__Sequence * input,
  upperlimb_msgs__msg__MotionInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(upperlimb_msgs__msg__MotionInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    upperlimb_msgs__msg__MotionInfo * data =
      (upperlimb_msgs__msg__MotionInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!upperlimb_msgs__msg__MotionInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          upperlimb_msgs__msg__MotionInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!upperlimb_msgs__msg__MotionInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
