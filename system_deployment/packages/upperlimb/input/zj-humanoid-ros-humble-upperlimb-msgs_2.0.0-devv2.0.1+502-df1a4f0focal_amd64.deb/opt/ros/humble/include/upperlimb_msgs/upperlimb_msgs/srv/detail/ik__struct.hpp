// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:srv/IK.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__IK__STRUCT_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__IK__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__IK_Request __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__IK_Request __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct IK_Request_
{
  using Type = IK_Request_<ContainerAllocator>;

  explicit IK_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pose.fill(geometry_msgs::msg::Pose_<ContainerAllocator>{_init});
      this->q7 = 0.0;
      this->arm_type = 0;
    }
  }

  explicit IK_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pose(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->pose.fill(geometry_msgs::msg::Pose_<ContainerAllocator>{_alloc, _init});
      this->q7 = 0.0;
      this->arm_type = 0;
    }
  }

  // field types and members
  using _pose_type =
    std::array<geometry_msgs::msg::Pose_<ContainerAllocator>, 2>;
  _pose_type pose;
  using _q7_type =
    double;
  _q7_type q7;
  using _q_init_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _q_init_type q_init;
  using _q_ref_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _q_ref_type q_ref;
  using _arm_type_type =
    int8_t;
  _arm_type_type arm_type;

  // setters for named parameter idiom
  Type & set__pose(
    const std::array<geometry_msgs::msg::Pose_<ContainerAllocator>, 2> & _arg)
  {
    this->pose = _arg;
    return *this;
  }
  Type & set__q7(
    const double & _arg)
  {
    this->q7 = _arg;
    return *this;
  }
  Type & set__q_init(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->q_init = _arg;
    return *this;
  }
  Type & set__q_ref(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->q_ref = _arg;
    return *this;
  }
  Type & set__arm_type(
    const int8_t & _arg)
  {
    this->arm_type = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::IK_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::IK_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::IK_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::IK_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__IK_Request
    std::shared_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__IK_Request
    std::shared_ptr<upperlimb_msgs::srv::IK_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const IK_Request_ & other) const
  {
    if (this->pose != other.pose) {
      return false;
    }
    if (this->q7 != other.q7) {
      return false;
    }
    if (this->q_init != other.q_init) {
      return false;
    }
    if (this->q_ref != other.q_ref) {
      return false;
    }
    if (this->arm_type != other.arm_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const IK_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct IK_Request_

// alias to use template instance with default allocator
using IK_Request =
  upperlimb_msgs::srv::IK_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs


// Include directives for member types
// Member 'joints'
#include "upperlimb_msgs/msg/detail/joints__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__IK_Response __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__IK_Response __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct IK_Response_
{
  using Type = IK_Response_<ContainerAllocator>;

  explicit IK_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->nums = 0l;
    }
  }

  explicit IK_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->nums = 0l;
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;
  using _nums_type =
    int32_t;
  _nums_type nums;
  using _joints_type =
    std::vector<upperlimb_msgs::msg::Joints_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<upperlimb_msgs::msg::Joints_<ContainerAllocator>>>;
  _joints_type joints;
  using _arm_type_type =
    std::vector<int8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int8_t>>;
  _arm_type_type arm_type;
  using _phi_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _phi_type phi;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }
  Type & set__nums(
    const int32_t & _arg)
  {
    this->nums = _arg;
    return *this;
  }
  Type & set__joints(
    const std::vector<upperlimb_msgs::msg::Joints_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<upperlimb_msgs::msg::Joints_<ContainerAllocator>>> & _arg)
  {
    this->joints = _arg;
    return *this;
  }
  Type & set__arm_type(
    const std::vector<int8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int8_t>> & _arg)
  {
    this->arm_type = _arg;
    return *this;
  }
  Type & set__phi(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->phi = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::IK_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::IK_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::IK_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::IK_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__IK_Response
    std::shared_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__IK_Response
    std::shared_ptr<upperlimb_msgs::srv::IK_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const IK_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    if (this->nums != other.nums) {
      return false;
    }
    if (this->joints != other.joints) {
      return false;
    }
    if (this->arm_type != other.arm_type) {
      return false;
    }
    if (this->phi != other.phi) {
      return false;
    }
    return true;
  }
  bool operator!=(const IK_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct IK_Response_

// alias to use template instance with default allocator
using IK_Response =
  upperlimb_msgs::srv::IK_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs

namespace upperlimb_msgs
{

namespace srv
{

struct IK
{
  using Request = upperlimb_msgs::srv::IK_Request;
  using Response = upperlimb_msgs::srv::IK_Response;
};

}  // namespace srv

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__IK__STRUCT_HPP_
