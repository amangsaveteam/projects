// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DRAG_TEACH_RECORD_HPP_
#define UPPERLIMB_MSGS__ACTION__DRAG_TEACH_RECORD_HPP_

#include "upperlimb_msgs/action/detail/drag_teach_record__struct.hpp"
#include "upperlimb_msgs/action/detail/drag_teach_record__builder.hpp"
#include "upperlimb_msgs/action/detail/drag_teach_record__traits.hpp"
#include "upperlimb_msgs/action/detail/drag_teach_record__type_support.hpp"

#endif  // UPPERLIMB_MSGS__ACTION__DRAG_TEACH_RECORD_HPP_
