// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:msg/ArmTypeEnum.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__STRUCT_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__msg__ArmTypeEnum __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__msg__ArmTypeEnum __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ArmTypeEnum_
{
  using Type = ArmTypeEnum_<ContainerAllocator>;

  explicit ArmTypeEnum_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->structure_needs_at_least_one_member = 0;
    }
  }

  explicit ArmTypeEnum_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->structure_needs_at_least_one_member = 0;
    }
  }

  // field types and members
  using _structure_needs_at_least_one_member_type =
    uint8_t;
  _structure_needs_at_least_one_member_type structure_needs_at_least_one_member;


  // constant declarations
  static constexpr unsigned char LEFT_ARM =
    1;
  static constexpr unsigned char RIGHT_ARM =
    2;
  static constexpr unsigned char NECK =
    4;
  static constexpr unsigned char WAIST =
    8;
  static constexpr unsigned char LIFT =
    16;

  // pointer types
  using RawPtr =
    upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__msg__ArmTypeEnum
    std::shared_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__msg__ArmTypeEnum
    std::shared_ptr<upperlimb_msgs::msg::ArmTypeEnum_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ArmTypeEnum_ & other) const
  {
    if (this->structure_needs_at_least_one_member != other.structure_needs_at_least_one_member) {
      return false;
    }
    return true;
  }
  bool operator!=(const ArmTypeEnum_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ArmTypeEnum_

// alias to use template instance with default allocator
using ArmTypeEnum =
  upperlimb_msgs::msg::ArmTypeEnum_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char ArmTypeEnum_<ContainerAllocator>::LEFT_ARM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char ArmTypeEnum_<ContainerAllocator>::RIGHT_ARM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char ArmTypeEnum_<ContainerAllocator>::NECK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char ArmTypeEnum_<ContainerAllocator>::WAIST;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char ArmTypeEnum_<ContainerAllocator>::LIFT;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__STRUCT_HPP_
