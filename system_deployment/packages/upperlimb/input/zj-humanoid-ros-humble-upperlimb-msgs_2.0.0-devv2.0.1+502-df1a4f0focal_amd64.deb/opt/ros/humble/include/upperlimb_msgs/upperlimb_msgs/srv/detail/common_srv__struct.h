// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/CommonSrv.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__COMMON_SRV__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__COMMON_SRV__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'request'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/CommonSrv in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__CommonSrv_Request
{
  rosidl_runtime_c__String request;
} upperlimb_msgs__srv__CommonSrv_Request;

// Struct for a sequence of upperlimb_msgs__srv__CommonSrv_Request.
typedef struct upperlimb_msgs__srv__CommonSrv_Request__Sequence
{
  upperlimb_msgs__srv__CommonSrv_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__CommonSrv_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'response'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/CommonSrv in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__CommonSrv_Response
{
  rosidl_runtime_c__String response;
} upperlimb_msgs__srv__CommonSrv_Response;

// Struct for a sequence of upperlimb_msgs__srv__CommonSrv_Response.
typedef struct upperlimb_msgs__srv__CommonSrv_Response__Sequence
{
  upperlimb_msgs__srv__CommonSrv_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__CommonSrv_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__COMMON_SRV__STRUCT_H_
