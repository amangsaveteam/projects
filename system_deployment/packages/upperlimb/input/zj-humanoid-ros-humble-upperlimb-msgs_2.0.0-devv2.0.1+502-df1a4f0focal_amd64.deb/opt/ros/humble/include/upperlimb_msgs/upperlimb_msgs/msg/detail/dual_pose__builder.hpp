// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/DualPose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/dual_pose__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_DualPose_right_arm_pose
{
public:
  explicit Init_DualPose_right_arm_pose(::upperlimb_msgs::msg::DualPose & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::DualPose right_arm_pose(::upperlimb_msgs::msg::DualPose::_right_arm_pose_type arg)
  {
    msg_.right_arm_pose = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::DualPose msg_;
};

class Init_DualPose_left_arm_pose
{
public:
  explicit Init_DualPose_left_arm_pose(::upperlimb_msgs::msg::DualPose & msg)
  : msg_(msg)
  {}
  Init_DualPose_right_arm_pose left_arm_pose(::upperlimb_msgs::msg::DualPose::_left_arm_pose_type arg)
  {
    msg_.left_arm_pose = std::move(arg);
    return Init_DualPose_right_arm_pose(msg_);
  }

private:
  ::upperlimb_msgs::msg::DualPose msg_;
};

class Init_DualPose_header
{
public:
  Init_DualPose_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DualPose_left_arm_pose header(::upperlimb_msgs::msg::DualPose::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_DualPose_left_arm_pose(msg_);
  }

private:
  ::upperlimb_msgs::msg::DualPose msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::DualPose>()
{
  return upperlimb_msgs::msg::builder::Init_DualPose_header();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__BUILDER_HPP_
