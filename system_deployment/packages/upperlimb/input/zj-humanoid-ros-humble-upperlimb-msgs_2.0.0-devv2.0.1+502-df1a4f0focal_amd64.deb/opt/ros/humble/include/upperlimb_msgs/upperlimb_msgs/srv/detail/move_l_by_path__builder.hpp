// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/MoveLByPath.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_L_BY_PATH__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_L_BY_PATH__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/move_l_by_path__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MoveLByPath_Request_arm_type
{
public:
  explicit Init_MoveLByPath_Request_arm_type(::upperlimb_msgs::srv::MoveLByPath_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MoveLByPath_Request arm_type(::upperlimb_msgs::srv::MoveLByPath_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Request msg_;
};

class Init_MoveLByPath_Request_is_async
{
public:
  explicit Init_MoveLByPath_Request_is_async(::upperlimb_msgs::srv::MoveLByPath_Request & msg)
  : msg_(msg)
  {}
  Init_MoveLByPath_Request_arm_type is_async(::upperlimb_msgs::srv::MoveLByPath_Request::_is_async_type arg)
  {
    msg_.is_async = std::move(arg);
    return Init_MoveLByPath_Request_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Request msg_;
};

class Init_MoveLByPath_Request_timestamp
{
public:
  explicit Init_MoveLByPath_Request_timestamp(::upperlimb_msgs::srv::MoveLByPath_Request & msg)
  : msg_(msg)
  {}
  Init_MoveLByPath_Request_is_async timestamp(::upperlimb_msgs::srv::MoveLByPath_Request::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_MoveLByPath_Request_is_async(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Request msg_;
};

class Init_MoveLByPath_Request_time
{
public:
  explicit Init_MoveLByPath_Request_time(::upperlimb_msgs::srv::MoveLByPath_Request & msg)
  : msg_(msg)
  {}
  Init_MoveLByPath_Request_timestamp time(::upperlimb_msgs::srv::MoveLByPath_Request::_time_type arg)
  {
    msg_.time = std::move(arg);
    return Init_MoveLByPath_Request_timestamp(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Request msg_;
};

class Init_MoveLByPath_Request_right_arm_path
{
public:
  explicit Init_MoveLByPath_Request_right_arm_path(::upperlimb_msgs::srv::MoveLByPath_Request & msg)
  : msg_(msg)
  {}
  Init_MoveLByPath_Request_time right_arm_path(::upperlimb_msgs::srv::MoveLByPath_Request::_right_arm_path_type arg)
  {
    msg_.right_arm_path = std::move(arg);
    return Init_MoveLByPath_Request_time(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Request msg_;
};

class Init_MoveLByPath_Request_left_arm_path
{
public:
  Init_MoveLByPath_Request_left_arm_path()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveLByPath_Request_right_arm_path left_arm_path(::upperlimb_msgs::srv::MoveLByPath_Request::_left_arm_path_type arg)
  {
    msg_.left_arm_path = std::move(arg);
    return Init_MoveLByPath_Request_right_arm_path(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MoveLByPath_Request>()
{
  return upperlimb_msgs::srv::builder::Init_MoveLByPath_Request_left_arm_path();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MoveLByPath_Response_message
{
public:
  explicit Init_MoveLByPath_Response_message(::upperlimb_msgs::srv::MoveLByPath_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MoveLByPath_Response message(::upperlimb_msgs::srv::MoveLByPath_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Response msg_;
};

class Init_MoveLByPath_Response_success
{
public:
  Init_MoveLByPath_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveLByPath_Response_message success(::upperlimb_msgs::srv::MoveLByPath_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_MoveLByPath_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveLByPath_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MoveLByPath_Response>()
{
  return upperlimb_msgs::srv::builder::Init_MoveLByPath_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_L_BY_PATH__BUILDER_HPP_
