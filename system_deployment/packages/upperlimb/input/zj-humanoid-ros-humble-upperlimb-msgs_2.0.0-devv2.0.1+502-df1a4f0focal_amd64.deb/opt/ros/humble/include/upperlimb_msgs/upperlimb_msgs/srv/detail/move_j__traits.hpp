// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:srv/MoveJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__TRAITS_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/srv/detail/move_j__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const MoveJ_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: joints
  {
    if (msg.joints.size() == 0) {
      out << "joints: []";
    } else {
      out << "joints: [";
      size_t pending_items = msg.joints.size();
      for (auto item : msg.joints) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: v
  {
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << ", ";
  }

  // member: acc
  {
    out << "acc: ";
    rosidl_generator_traits::value_to_yaml(msg.acc, out);
    out << ", ";
  }

  // member: t
  {
    out << "t: ";
    rosidl_generator_traits::value_to_yaml(msg.t, out);
    out << ", ";
  }

  // member: is_async
  {
    out << "is_async: ";
    rosidl_generator_traits::value_to_yaml(msg.is_async, out);
    out << ", ";
  }

  // member: arm_type
  {
    out << "arm_type: ";
    rosidl_generator_traits::value_to_yaml(msg.arm_type, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MoveJ_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: joints
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joints.size() == 0) {
      out << "joints: []\n";
    } else {
      out << "joints:\n";
      for (auto item : msg.joints) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: v
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << "\n";
  }

  // member: acc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc: ";
    rosidl_generator_traits::value_to_yaml(msg.acc, out);
    out << "\n";
  }

  // member: t
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "t: ";
    rosidl_generator_traits::value_to_yaml(msg.t, out);
    out << "\n";
  }

  // member: is_async
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_async: ";
    rosidl_generator_traits::value_to_yaml(msg.is_async, out);
    out << "\n";
  }

  // member: arm_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "arm_type: ";
    rosidl_generator_traits::value_to_yaml(msg.arm_type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MoveJ_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::MoveJ_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::MoveJ_Request & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::MoveJ_Request>()
{
  return "upperlimb_msgs::srv::MoveJ_Request";
}

template<>
inline const char * name<upperlimb_msgs::srv::MoveJ_Request>()
{
  return "upperlimb_msgs/srv/MoveJ_Request";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MoveJ_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MoveJ_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::MoveJ_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const MoveJ_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MoveJ_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MoveJ_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::MoveJ_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::MoveJ_Response & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::MoveJ_Response>()
{
  return "upperlimb_msgs::srv::MoveJ_Response";
}

template<>
inline const char * name<upperlimb_msgs::srv::MoveJ_Response>()
{
  return "upperlimb_msgs/srv/MoveJ_Response";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MoveJ_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MoveJ_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::MoveJ_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<upperlimb_msgs::srv::MoveJ>()
{
  return "upperlimb_msgs::srv::MoveJ";
}

template<>
inline const char * name<upperlimb_msgs::srv::MoveJ>()
{
  return "upperlimb_msgs/srv/MoveJ";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MoveJ>
  : std::integral_constant<
    bool,
    has_fixed_size<upperlimb_msgs::srv::MoveJ_Request>::value &&
    has_fixed_size<upperlimb_msgs::srv::MoveJ_Response>::value
  >
{
};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MoveJ>
  : std::integral_constant<
    bool,
    has_bounded_size<upperlimb_msgs::srv::MoveJ_Request>::value &&
    has_bounded_size<upperlimb_msgs::srv::MoveJ_Response>::value
  >
{
};

template<>
struct is_service<upperlimb_msgs::srv::MoveJ>
  : std::true_type
{
};

template<>
struct is_service_request<upperlimb_msgs::srv::MoveJ_Request>
  : std::true_type
{
};

template<>
struct is_service_response<upperlimb_msgs::srv::MoveJ_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__TRAITS_HPP_
