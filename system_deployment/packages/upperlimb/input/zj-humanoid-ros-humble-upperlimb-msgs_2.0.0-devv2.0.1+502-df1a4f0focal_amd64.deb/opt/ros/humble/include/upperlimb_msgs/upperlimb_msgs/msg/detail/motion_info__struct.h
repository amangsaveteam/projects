﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/MotionInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__MOTION_INFO__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__MOTION_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'filename'
// Member 'alias'
#include "rosidl_runtime_c/string.h"
// Member 'joints'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/MotionInfo in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__MotionInfo
{
  /// 动作文件名称
  rosidl_runtime_c__String filename;
  /// 别名
  rosidl_runtime_c__String alias;
  /// 关节类型
  int8_t arm_type;
  /// 第一个点数据
  rosidl_runtime_c__double__Sequence joints;
  /// 点位数量
  int64_t number;
} upperlimb_msgs__msg__MotionInfo;

// Struct for a sequence of upperlimb_msgs__msg__MotionInfo.
typedef struct upperlimb_msgs__msg__MotionInfo__Sequence
{
  upperlimb_msgs__msg__MotionInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__MotionInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__MOTION_INFO__STRUCT_H_
