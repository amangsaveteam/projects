// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/MoveJByPose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_POSE__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_POSE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/move_j_by_pose__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MoveJByPose_Request_arm_type
{
public:
  explicit Init_MoveJByPose_Request_arm_type(::upperlimb_msgs::srv::MoveJByPose_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MoveJByPose_Request arm_type(::upperlimb_msgs::srv::MoveJByPose_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Request msg_;
};

class Init_MoveJByPose_Request_is_async
{
public:
  explicit Init_MoveJByPose_Request_is_async(::upperlimb_msgs::srv::MoveJByPose_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJByPose_Request_arm_type is_async(::upperlimb_msgs::srv::MoveJByPose_Request::_is_async_type arg)
  {
    msg_.is_async = std::move(arg);
    return Init_MoveJByPose_Request_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Request msg_;
};

class Init_MoveJByPose_Request_acc
{
public:
  explicit Init_MoveJByPose_Request_acc(::upperlimb_msgs::srv::MoveJByPose_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJByPose_Request_is_async acc(::upperlimb_msgs::srv::MoveJByPose_Request::_acc_type arg)
  {
    msg_.acc = std::move(arg);
    return Init_MoveJByPose_Request_is_async(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Request msg_;
};

class Init_MoveJByPose_Request_v
{
public:
  explicit Init_MoveJByPose_Request_v(::upperlimb_msgs::srv::MoveJByPose_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJByPose_Request_acc v(::upperlimb_msgs::srv::MoveJByPose_Request::_v_type arg)
  {
    msg_.v = std::move(arg);
    return Init_MoveJByPose_Request_acc(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Request msg_;
};

class Init_MoveJByPose_Request_q7
{
public:
  explicit Init_MoveJByPose_Request_q7(::upperlimb_msgs::srv::MoveJByPose_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJByPose_Request_v q7(::upperlimb_msgs::srv::MoveJByPose_Request::_q7_type arg)
  {
    msg_.q7 = std::move(arg);
    return Init_MoveJByPose_Request_v(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Request msg_;
};

class Init_MoveJByPose_Request_pose
{
public:
  Init_MoveJByPose_Request_pose()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJByPose_Request_q7 pose(::upperlimb_msgs::srv::MoveJByPose_Request::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_MoveJByPose_Request_q7(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MoveJByPose_Request>()
{
  return upperlimb_msgs::srv::builder::Init_MoveJByPose_Request_pose();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MoveJByPose_Response_message
{
public:
  explicit Init_MoveJByPose_Response_message(::upperlimb_msgs::srv::MoveJByPose_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MoveJByPose_Response message(::upperlimb_msgs::srv::MoveJByPose_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Response msg_;
};

class Init_MoveJByPose_Response_success
{
public:
  Init_MoveJByPose_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJByPose_Response_message success(::upperlimb_msgs::srv::MoveJByPose_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_MoveJByPose_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJByPose_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MoveJByPose_Response>()
{
  return upperlimb_msgs::srv::builder::Init_MoveJByPose_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_POSE__BUILDER_HPP_
