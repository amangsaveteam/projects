// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:action/DragTeachReplay.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__TRAITS_HPP_
#define UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/action/detail/drag_teach_replay__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_Goal & msg,
  std::ostream & out)
{
  out << "{";
  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << ", ";
  }

  // member: v
  {
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << ", ";
  }

  // member: acc
  {
    out << "acc: ";
    rosidl_generator_traits::value_to_yaml(msg.acc, out);
    out << ", ";
  }

  // member: t
  {
    out << "t: ";
    rosidl_generator_traits::value_to_yaml(msg.t, out);
    out << ", ";
  }

  // member: start_time
  {
    out << "start_time: ";
    rosidl_generator_traits::value_to_yaml(msg.start_time, out);
    out << ", ";
  }

  // member: end_time
  {
    out << "end_time: ";
    rosidl_generator_traits::value_to_yaml(msg.end_time, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_Goal & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: v
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "v: ";
    rosidl_generator_traits::value_to_yaml(msg.v, out);
    out << "\n";
  }

  // member: acc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc: ";
    rosidl_generator_traits::value_to_yaml(msg.acc, out);
    out << "\n";
  }

  // member: t
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "t: ";
    rosidl_generator_traits::value_to_yaml(msg.t, out);
    out << "\n";
  }

  // member: start_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "start_time: ";
    rosidl_generator_traits::value_to_yaml(msg.start_time, out);
    out << "\n";
  }

  // member: end_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "end_time: ";
    rosidl_generator_traits::value_to_yaml(msg.end_time, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_Goal & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_Goal & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_Goal & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_Goal>()
{
  return "upperlimb_msgs::action::DragTeachReplay_Goal";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_Goal>()
{
  return "upperlimb_msgs/action/DragTeachReplay_Goal";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_Goal>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_Goal>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_Goal>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_Result & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << ", ";
  }

  // member: state_code
  {
    out << "state_code: ";
    rosidl_generator_traits::value_to_yaml(msg.state_code, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_Result & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }

  // member: state_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state_code: ";
    rosidl_generator_traits::value_to_yaml(msg.state_code, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_Result & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_Result & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_Result & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_Result>()
{
  return "upperlimb_msgs::action::DragTeachReplay_Result";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_Result>()
{
  return "upperlimb_msgs/action/DragTeachReplay_Result";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_Result>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_Result>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_Result>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_Feedback & msg,
  std::ostream & out)
{
  out << "{";
  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << ", ";
  }

  // member: progress
  {
    out << "progress: ";
    rosidl_generator_traits::value_to_yaml(msg.progress, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_Feedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: progress
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "progress: ";
    rosidl_generator_traits::value_to_yaml(msg.progress, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_Feedback & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_Feedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_Feedback & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_Feedback>()
{
  return "upperlimb_msgs::action::DragTeachReplay_Feedback";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_Feedback>()
{
  return "upperlimb_msgs/action/DragTeachReplay_Feedback";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_Feedback>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_Feedback>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_Feedback>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'goal'
#include "upperlimb_msgs/action/detail/drag_teach_replay__traits.hpp"

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_SendGoal_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: goal_id
  {
    out << "goal_id: ";
    to_flow_style_yaml(msg.goal_id, out);
    out << ", ";
  }

  // member: goal
  {
    out << "goal: ";
    to_flow_style_yaml(msg.goal, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_SendGoal_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: goal_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal_id:\n";
    to_block_style_yaml(msg.goal_id, out, indentation + 2);
  }

  // member: goal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal:\n";
    to_block_style_yaml(msg.goal, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_SendGoal_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_SendGoal_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_SendGoal_Request & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>()
{
  return "upperlimb_msgs::action::DragTeachReplay_SendGoal_Request";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>()
{
  return "upperlimb_msgs/action/DragTeachReplay_SendGoal_Request";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>
  : std::integral_constant<bool, has_fixed_size<unique_identifier_msgs::msg::UUID>::value && has_fixed_size<upperlimb_msgs::action::DragTeachReplay_Goal>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>
  : std::integral_constant<bool, has_bounded_size<unique_identifier_msgs::msg::UUID>::value && has_bounded_size<upperlimb_msgs::action::DragTeachReplay_Goal>::value> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_SendGoal_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: accepted
  {
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
    out << ", ";
  }

  // member: stamp
  {
    out << "stamp: ";
    to_flow_style_yaml(msg.stamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_SendGoal_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: accepted
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
    out << "\n";
  }

  // member: stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stamp:\n";
    to_block_style_yaml(msg.stamp, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_SendGoal_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_SendGoal_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_SendGoal_Response & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>()
{
  return "upperlimb_msgs::action::DragTeachReplay_SendGoal_Response";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>()
{
  return "upperlimb_msgs/action/DragTeachReplay_SendGoal_Response";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_SendGoal>()
{
  return "upperlimb_msgs::action::DragTeachReplay_SendGoal";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_SendGoal>()
{
  return "upperlimb_msgs/action/DragTeachReplay_SendGoal";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_SendGoal>
  : std::integral_constant<
    bool,
    has_fixed_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>::value &&
    has_fixed_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>::value
  >
{
};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_SendGoal>
  : std::integral_constant<
    bool,
    has_bounded_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>::value &&
    has_bounded_size<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>::value
  >
{
};

template<>
struct is_service<upperlimb_msgs::action::DragTeachReplay_SendGoal>
  : std::true_type
{
};

template<>
struct is_service_request<upperlimb_msgs::action::DragTeachReplay_SendGoal_Request>
  : std::true_type
{
};

template<>
struct is_service_response<upperlimb_msgs::action::DragTeachReplay_SendGoal_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_GetResult_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: goal_id
  {
    out << "goal_id: ";
    to_flow_style_yaml(msg.goal_id, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_GetResult_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: goal_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal_id:\n";
    to_block_style_yaml(msg.goal_id, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_GetResult_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_GetResult_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_GetResult_Request & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>()
{
  return "upperlimb_msgs::action::DragTeachReplay_GetResult_Request";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>()
{
  return "upperlimb_msgs/action/DragTeachReplay_GetResult_Request";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>
  : std::integral_constant<bool, has_fixed_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>
  : std::integral_constant<bool, has_bounded_size<unique_identifier_msgs::msg::UUID>::value> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'result'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_replay__traits.hpp"

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_GetResult_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: status
  {
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << ", ";
  }

  // member: result
  {
    out << "result: ";
    to_flow_style_yaml(msg.result, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_GetResult_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << "\n";
  }

  // member: result
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "result:\n";
    to_block_style_yaml(msg.result, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_GetResult_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_GetResult_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_GetResult_Response & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>()
{
  return "upperlimb_msgs::action::DragTeachReplay_GetResult_Response";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>()
{
  return "upperlimb_msgs/action/DragTeachReplay_GetResult_Response";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>
  : std::integral_constant<bool, has_fixed_size<upperlimb_msgs::action::DragTeachReplay_Result>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>
  : std::integral_constant<bool, has_bounded_size<upperlimb_msgs::action::DragTeachReplay_Result>::value> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_GetResult>()
{
  return "upperlimb_msgs::action::DragTeachReplay_GetResult";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_GetResult>()
{
  return "upperlimb_msgs/action/DragTeachReplay_GetResult";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_GetResult>
  : std::integral_constant<
    bool,
    has_fixed_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>::value &&
    has_fixed_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>::value
  >
{
};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_GetResult>
  : std::integral_constant<
    bool,
    has_bounded_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>::value &&
    has_bounded_size<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>::value
  >
{
};

template<>
struct is_service<upperlimb_msgs::action::DragTeachReplay_GetResult>
  : std::true_type
{
};

template<>
struct is_service_request<upperlimb_msgs::action::DragTeachReplay_GetResult_Request>
  : std::true_type
{
};

template<>
struct is_service_response<upperlimb_msgs::action::DragTeachReplay_GetResult_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__traits.hpp"
// Member 'feedback'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_replay__traits.hpp"

namespace upperlimb_msgs
{

namespace action
{

inline void to_flow_style_yaml(
  const DragTeachReplay_FeedbackMessage & msg,
  std::ostream & out)
{
  out << "{";
  // member: goal_id
  {
    out << "goal_id: ";
    to_flow_style_yaml(msg.goal_id, out);
    out << ", ";
  }

  // member: feedback
  {
    out << "feedback: ";
    to_flow_style_yaml(msg.feedback, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DragTeachReplay_FeedbackMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: goal_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal_id:\n";
    to_block_style_yaml(msg.goal_id, out, indentation + 2);
  }

  // member: feedback
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "feedback:\n";
    to_block_style_yaml(msg.feedback, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DragTeachReplay_FeedbackMessage & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace action

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::action::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::action::DragTeachReplay_FeedbackMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::action::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::action::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::action::DragTeachReplay_FeedbackMessage & msg)
{
  return upperlimb_msgs::action::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::action::DragTeachReplay_FeedbackMessage>()
{
  return "upperlimb_msgs::action::DragTeachReplay_FeedbackMessage";
}

template<>
inline const char * name<upperlimb_msgs::action::DragTeachReplay_FeedbackMessage>()
{
  return "upperlimb_msgs/action/DragTeachReplay_FeedbackMessage";
}

template<>
struct has_fixed_size<upperlimb_msgs::action::DragTeachReplay_FeedbackMessage>
  : std::integral_constant<bool, has_fixed_size<unique_identifier_msgs::msg::UUID>::value && has_fixed_size<upperlimb_msgs::action::DragTeachReplay_Feedback>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::action::DragTeachReplay_FeedbackMessage>
  : std::integral_constant<bool, has_bounded_size<unique_identifier_msgs::msg::UUID>::value && has_bounded_size<upperlimb_msgs::action::DragTeachReplay_Feedback>::value> {};

template<>
struct is_message<upperlimb_msgs::action::DragTeachReplay_FeedbackMessage>
  : std::true_type {};

}  // namespace rosidl_generator_traits


namespace rosidl_generator_traits
{

template<>
struct is_action<upperlimb_msgs::action::DragTeachReplay>
  : std::true_type
{
};

template<>
struct is_action_goal<upperlimb_msgs::action::DragTeachReplay_Goal>
  : std::true_type
{
};

template<>
struct is_action_result<upperlimb_msgs::action::DragTeachReplay_Result>
  : std::true_type
{
};

template<>
struct is_action_feedback<upperlimb_msgs::action::DragTeachReplay_Feedback>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits


#endif  // UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__TRAITS_HPP_
