// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:srv/MotionsLoadedList.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__TRAITS_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/srv/detail/motions_loaded_list__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const MotionsLoadedList_Request & msg,
  std::ostream & out)
{
  (void)msg;
  out << "null";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MotionsLoadedList_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  (void)msg;
  (void)indentation;
  out << "null\n";
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MotionsLoadedList_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::MotionsLoadedList_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::MotionsLoadedList_Request & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::MotionsLoadedList_Request>()
{
  return "upperlimb_msgs::srv::MotionsLoadedList_Request";
}

template<>
inline const char * name<upperlimb_msgs::srv::MotionsLoadedList_Request>()
{
  return "upperlimb_msgs/srv/MotionsLoadedList_Request";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MotionsLoadedList_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MotionsLoadedList_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<upperlimb_msgs::srv::MotionsLoadedList_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'motions'
#include "upperlimb_msgs/msg/detail/motion_info__traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const MotionsLoadedList_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << ", ";
  }

  // member: motions
  {
    if (msg.motions.size() == 0) {
      out << "motions: []";
    } else {
      out << "motions: [";
      size_t pending_items = msg.motions.size();
      for (auto item : msg.motions) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MotionsLoadedList_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }

  // member: motions
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motions.size() == 0) {
      out << "motions: []\n";
    } else {
      out << "motions:\n";
      for (auto item : msg.motions) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MotionsLoadedList_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::MotionsLoadedList_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::MotionsLoadedList_Response & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::MotionsLoadedList_Response>()
{
  return "upperlimb_msgs::srv::MotionsLoadedList_Response";
}

template<>
inline const char * name<upperlimb_msgs::srv::MotionsLoadedList_Response>()
{
  return "upperlimb_msgs/srv/MotionsLoadedList_Response";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MotionsLoadedList_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MotionsLoadedList_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::MotionsLoadedList_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<upperlimb_msgs::srv::MotionsLoadedList>()
{
  return "upperlimb_msgs::srv::MotionsLoadedList";
}

template<>
inline const char * name<upperlimb_msgs::srv::MotionsLoadedList>()
{
  return "upperlimb_msgs/srv/MotionsLoadedList";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MotionsLoadedList>
  : std::integral_constant<
    bool,
    has_fixed_size<upperlimb_msgs::srv::MotionsLoadedList_Request>::value &&
    has_fixed_size<upperlimb_msgs::srv::MotionsLoadedList_Response>::value
  >
{
};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MotionsLoadedList>
  : std::integral_constant<
    bool,
    has_bounded_size<upperlimb_msgs::srv::MotionsLoadedList_Request>::value &&
    has_bounded_size<upperlimb_msgs::srv::MotionsLoadedList_Response>::value
  >
{
};

template<>
struct is_service<upperlimb_msgs::srv::MotionsLoadedList>
  : std::true_type
{
};

template<>
struct is_service_request<upperlimb_msgs::srv::MotionsLoadedList_Request>
  : std::true_type
{
};

template<>
struct is_service_response<upperlimb_msgs::srv::MotionsLoadedList_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_LOADED_LIST__TRAITS_HPP_
