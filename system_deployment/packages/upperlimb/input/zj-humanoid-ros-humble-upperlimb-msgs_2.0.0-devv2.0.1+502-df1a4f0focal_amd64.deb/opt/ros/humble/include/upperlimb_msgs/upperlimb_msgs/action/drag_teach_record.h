// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:action/DragTeachRecord.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DRAG_TEACH_RECORD_H_
#define UPPERLIMB_MSGS__ACTION__DRAG_TEACH_RECORD_H_

#include "upperlimb_msgs/action/detail/drag_teach_record__struct.h"
#include "upperlimb_msgs/action/detail/drag_teach_record__functions.h"
#include "upperlimb_msgs/action/detail/drag_teach_record__type_support.h"

#endif  // UPPERLIMB_MSGS__ACTION__DRAG_TEACH_RECORD_H_
