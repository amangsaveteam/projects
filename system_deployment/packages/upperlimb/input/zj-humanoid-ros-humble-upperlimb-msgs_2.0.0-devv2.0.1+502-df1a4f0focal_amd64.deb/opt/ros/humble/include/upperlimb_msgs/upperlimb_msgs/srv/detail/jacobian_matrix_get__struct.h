﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/JacobianMatrixGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__JACOBIAN_MATRIX_GET__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__JACOBIAN_MATRIX_GET__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/JacobianMatrixGet in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__JacobianMatrixGet_Request
{
  /// 需要获取雅可比矩阵的机器人身体部位。参考 ArmTypeEnum.msg，通常为左臂或右臂 (Add on 1.4.0+)
  int8_t arm_type;
} upperlimb_msgs__srv__JacobianMatrixGet_Request;

// Struct for a sequence of upperlimb_msgs__srv__JacobianMatrixGet_Request.
typedef struct upperlimb_msgs__srv__JacobianMatrixGet_Request__Sequence
{
  upperlimb_msgs__srv__JacobianMatrixGet_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__JacobianMatrixGet_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"
// Member 'jacobian_matrix'
#include "std_msgs/msg/detail/float64_multi_array__struct.h"

/// Struct defined in srv/JacobianMatrixGet in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__JacobianMatrixGet_Response
{
  bool success;
  rosidl_runtime_c__String message;
  /// 指定身体部位对应的雅可比矩阵数据,0对应左臂, 1对应右臂 (Add on 1.4.0+)
  std_msgs__msg__Float64MultiArray jacobian_matrix[2];
} upperlimb_msgs__srv__JacobianMatrixGet_Response;

// Struct for a sequence of upperlimb_msgs__srv__JacobianMatrixGet_Response.
typedef struct upperlimb_msgs__srv__JacobianMatrixGet_Response__Sequence
{
  upperlimb_msgs__srv__JacobianMatrixGet_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__JacobianMatrixGet_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__JACOBIAN_MATRIX_GET__STRUCT_H_
