// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/UplimbState.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/uplimb_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_UplimbState_iddp_status
{
public:
  explicit Init_UplimbState_iddp_status(::upperlimb_msgs::msg::UplimbState & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::UplimbState iddp_status(::upperlimb_msgs::msg::UplimbState::_iddp_status_type arg)
  {
    msg_.iddp_status = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::UplimbState msg_;
};

class Init_UplimbState_right_arm_is_singular
{
public:
  explicit Init_UplimbState_right_arm_is_singular(::upperlimb_msgs::msg::UplimbState & msg)
  : msg_(msg)
  {}
  Init_UplimbState_iddp_status right_arm_is_singular(::upperlimb_msgs::msg::UplimbState::_right_arm_is_singular_type arg)
  {
    msg_.right_arm_is_singular = std::move(arg);
    return Init_UplimbState_iddp_status(msg_);
  }

private:
  ::upperlimb_msgs::msg::UplimbState msg_;
};

class Init_UplimbState_left_arm_is_singular
{
public:
  explicit Init_UplimbState_left_arm_is_singular(::upperlimb_msgs::msg::UplimbState & msg)
  : msg_(msg)
  {}
  Init_UplimbState_right_arm_is_singular left_arm_is_singular(::upperlimb_msgs::msg::UplimbState::_left_arm_is_singular_type arg)
  {
    msg_.left_arm_is_singular = std::move(arg);
    return Init_UplimbState_right_arm_is_singular(msg_);
  }

private:
  ::upperlimb_msgs::msg::UplimbState msg_;
};

class Init_UplimbState_cmd_name
{
public:
  explicit Init_UplimbState_cmd_name(::upperlimb_msgs::msg::UplimbState & msg)
  : msg_(msg)
  {}
  Init_UplimbState_left_arm_is_singular cmd_name(::upperlimb_msgs::msg::UplimbState::_cmd_name_type arg)
  {
    msg_.cmd_name = std::move(arg);
    return Init_UplimbState_left_arm_is_singular(msg_);
  }

private:
  ::upperlimb_msgs::msg::UplimbState msg_;
};

class Init_UplimbState_cmd_num
{
public:
  explicit Init_UplimbState_cmd_num(::upperlimb_msgs::msg::UplimbState & msg)
  : msg_(msg)
  {}
  Init_UplimbState_cmd_name cmd_num(::upperlimb_msgs::msg::UplimbState::_cmd_num_type arg)
  {
    msg_.cmd_num = std::move(arg);
    return Init_UplimbState_cmd_name(msg_);
  }

private:
  ::upperlimb_msgs::msg::UplimbState msg_;
};

class Init_UplimbState_header
{
public:
  Init_UplimbState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_UplimbState_cmd_num header(::upperlimb_msgs::msg::UplimbState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_UplimbState_cmd_num(msg_);
  }

private:
  ::upperlimb_msgs::msg::UplimbState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::UplimbState>()
{
  return upperlimb_msgs::msg::builder::Init_UplimbState_header();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__UPLIMB_STATE__BUILDER_HPP_
