// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__SPEED_J_HPP_
#define UPPERLIMB_MSGS__MSG__SPEED_J_HPP_

#include "upperlimb_msgs/msg/detail/speed_j__struct.hpp"
#include "upperlimb_msgs/msg/detail/speed_j__builder.hpp"
#include "upperlimb_msgs/msg/detail/speed_j__traits.hpp"
#include "upperlimb_msgs/msg/detail/speed_j__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__SPEED_J_HPP_
