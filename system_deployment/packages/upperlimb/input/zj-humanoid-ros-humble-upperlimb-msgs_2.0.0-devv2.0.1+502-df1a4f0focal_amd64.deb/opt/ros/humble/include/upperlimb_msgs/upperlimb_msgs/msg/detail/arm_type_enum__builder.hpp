// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/ArmTypeEnum.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/arm_type_enum__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{


}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::ArmTypeEnum>()
{
  return ::upperlimb_msgs::msg::ArmTypeEnum(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_TYPE_ENUM__BUILDER_HPP_
