// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:srv/IK.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__IK__TRAITS_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__IK__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/srv/detail/ik__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const IK_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: pose
  {
    if (msg.pose.size() == 0) {
      out << "pose: []";
    } else {
      out << "pose: [";
      size_t pending_items = msg.pose.size();
      for (auto item : msg.pose) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: q7
  {
    out << "q7: ";
    rosidl_generator_traits::value_to_yaml(msg.q7, out);
    out << ", ";
  }

  // member: q_init
  {
    if (msg.q_init.size() == 0) {
      out << "q_init: []";
    } else {
      out << "q_init: [";
      size_t pending_items = msg.q_init.size();
      for (auto item : msg.q_init) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: q_ref
  {
    if (msg.q_ref.size() == 0) {
      out << "q_ref: []";
    } else {
      out << "q_ref: [";
      size_t pending_items = msg.q_ref.size();
      for (auto item : msg.q_ref) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: arm_type
  {
    out << "arm_type: ";
    rosidl_generator_traits::value_to_yaml(msg.arm_type, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const IK_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.pose.size() == 0) {
      out << "pose: []\n";
    } else {
      out << "pose:\n";
      for (auto item : msg.pose) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: q7
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "q7: ";
    rosidl_generator_traits::value_to_yaml(msg.q7, out);
    out << "\n";
  }

  // member: q_init
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.q_init.size() == 0) {
      out << "q_init: []\n";
    } else {
      out << "q_init:\n";
      for (auto item : msg.q_init) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: q_ref
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.q_ref.size() == 0) {
      out << "q_ref: []\n";
    } else {
      out << "q_ref:\n";
      for (auto item : msg.q_ref) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: arm_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "arm_type: ";
    rosidl_generator_traits::value_to_yaml(msg.arm_type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const IK_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::IK_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::IK_Request & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::IK_Request>()
{
  return "upperlimb_msgs::srv::IK_Request";
}

template<>
inline const char * name<upperlimb_msgs::srv::IK_Request>()
{
  return "upperlimb_msgs/srv/IK_Request";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::IK_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::IK_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::IK_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'joints'
#include "upperlimb_msgs/msg/detail/joints__traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const IK_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << ", ";
  }

  // member: nums
  {
    out << "nums: ";
    rosidl_generator_traits::value_to_yaml(msg.nums, out);
    out << ", ";
  }

  // member: joints
  {
    if (msg.joints.size() == 0) {
      out << "joints: []";
    } else {
      out << "joints: [";
      size_t pending_items = msg.joints.size();
      for (auto item : msg.joints) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: arm_type
  {
    if (msg.arm_type.size() == 0) {
      out << "arm_type: []";
    } else {
      out << "arm_type: [";
      size_t pending_items = msg.arm_type.size();
      for (auto item : msg.arm_type) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: phi
  {
    if (msg.phi.size() == 0) {
      out << "phi: []";
    } else {
      out << "phi: [";
      size_t pending_items = msg.phi.size();
      for (auto item : msg.phi) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const IK_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }

  // member: nums
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nums: ";
    rosidl_generator_traits::value_to_yaml(msg.nums, out);
    out << "\n";
  }

  // member: joints
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.joints.size() == 0) {
      out << "joints: []\n";
    } else {
      out << "joints:\n";
      for (auto item : msg.joints) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: arm_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.arm_type.size() == 0) {
      out << "arm_type: []\n";
    } else {
      out << "arm_type:\n";
      for (auto item : msg.arm_type) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: phi
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.phi.size() == 0) {
      out << "phi: []\n";
    } else {
      out << "phi:\n";
      for (auto item : msg.phi) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const IK_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::IK_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::IK_Response & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::IK_Response>()
{
  return "upperlimb_msgs::srv::IK_Response";
}

template<>
inline const char * name<upperlimb_msgs::srv::IK_Response>()
{
  return "upperlimb_msgs/srv/IK_Response";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::IK_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::IK_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::IK_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<upperlimb_msgs::srv::IK>()
{
  return "upperlimb_msgs::srv::IK";
}

template<>
inline const char * name<upperlimb_msgs::srv::IK>()
{
  return "upperlimb_msgs/srv/IK";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::IK>
  : std::integral_constant<
    bool,
    has_fixed_size<upperlimb_msgs::srv::IK_Request>::value &&
    has_fixed_size<upperlimb_msgs::srv::IK_Response>::value
  >
{
};

template<>
struct has_bounded_size<upperlimb_msgs::srv::IK>
  : std::integral_constant<
    bool,
    has_bounded_size<upperlimb_msgs::srv::IK_Request>::value &&
    has_bounded_size<upperlimb_msgs::srv::IK_Response>::value
  >
{
};

template<>
struct is_service<upperlimb_msgs::srv::IK>
  : std::true_type
{
};

template<>
struct is_service_request<upperlimb_msgs::srv::IK_Request>
  : std::true_type
{
};

template<>
struct is_service_response<upperlimb_msgs::srv::IK_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__IK__TRAITS_HPP_
