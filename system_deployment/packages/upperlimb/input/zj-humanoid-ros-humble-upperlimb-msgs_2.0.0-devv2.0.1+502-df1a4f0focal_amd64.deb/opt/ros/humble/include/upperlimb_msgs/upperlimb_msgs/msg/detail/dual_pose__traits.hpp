// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:msg/DualPose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__TRAITS_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/msg/detail/dual_pose__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'left_arm_pose'
// Member 'right_arm_pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"

namespace upperlimb_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DualPose & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: left_arm_pose
  {
    out << "left_arm_pose: ";
    to_flow_style_yaml(msg.left_arm_pose, out);
    out << ", ";
  }

  // member: right_arm_pose
  {
    out << "right_arm_pose: ";
    to_flow_style_yaml(msg.right_arm_pose, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DualPose & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: left_arm_pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_arm_pose:\n";
    to_block_style_yaml(msg.left_arm_pose, out, indentation + 2);
  }

  // member: right_arm_pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_arm_pose:\n";
    to_block_style_yaml(msg.right_arm_pose, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DualPose & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::msg::DualPose & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::msg::DualPose & msg)
{
  return upperlimb_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::msg::DualPose>()
{
  return "upperlimb_msgs::msg::DualPose";
}

template<>
inline const char * name<upperlimb_msgs::msg::DualPose>()
{
  return "upperlimb_msgs/msg/DualPose";
}

template<>
struct has_fixed_size<upperlimb_msgs::msg::DualPose>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Pose>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<upperlimb_msgs::msg::DualPose>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Pose>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<upperlimb_msgs::msg::DualPose>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__TRAITS_HPP_
