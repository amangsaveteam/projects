// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/Joints.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__JOINTS__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__JOINTS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/joints__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_Joints_joint
{
public:
  explicit Init_Joints_joint(::upperlimb_msgs::msg::Joints & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::Joints joint(::upperlimb_msgs::msg::Joints::_joint_type arg)
  {
    msg_.joint = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::Joints msg_;
};

class Init_Joints_header
{
public:
  Init_Joints_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Joints_joint header(::upperlimb_msgs::msg::Joints::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Joints_joint(msg_);
  }

private:
  ::upperlimb_msgs::msg::Joints msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::Joints>()
{
  return upperlimb_msgs::msg::builder::Init_Joints_header();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__JOINTS__BUILDER_HPP_
