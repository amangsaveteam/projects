﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/MotionsManage.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'filename'
// Member 'alias'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/MotionsManage in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MotionsManage_Request
{
  /// 动作文件名称 (只检索后缀为.h5的文件,且符合内置规范的h5文件)
  rosidl_runtime_c__String filename;
  /// 动作别名,如果为空,默认为动作文件名称
  rosidl_runtime_c__String alias;
} upperlimb_msgs__srv__MotionsManage_Request;

// Struct for a sequence of upperlimb_msgs__srv__MotionsManage_Request.
typedef struct upperlimb_msgs__srv__MotionsManage_Request__Sequence
{
  upperlimb_msgs__srv__MotionsManage_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MotionsManage_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"
// Member 'info'
#include "upperlimb_msgs/msg/detail/motion_info__struct.h"

/// Struct defined in srv/MotionsManage in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MotionsManage_Response
{
  bool success;
  rosidl_runtime_c__String message;
  /// 如果成功加载,则为该动作的详细信息. (详细信息中会返回动作文件的第一个点数据,用户可利用该点数据自行运行到第一个点,然后再决定是否执行动作文件)
  upperlimb_msgs__msg__MotionInfo info;
} upperlimb_msgs__srv__MotionsManage_Response;

// Struct for a sequence of upperlimb_msgs__srv__MotionsManage_Response.
typedef struct upperlimb_msgs__srv__MotionsManage_Response__Sequence
{
  upperlimb_msgs__srv__MotionsManage_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MotionsManage_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__STRUCT_H_
