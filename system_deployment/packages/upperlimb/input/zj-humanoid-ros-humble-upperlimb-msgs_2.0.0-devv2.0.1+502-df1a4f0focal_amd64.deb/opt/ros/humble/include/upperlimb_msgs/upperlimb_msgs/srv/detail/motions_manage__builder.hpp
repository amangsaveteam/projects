// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/MotionsManage.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/motions_manage__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MotionsManage_Request_alias
{
public:
  explicit Init_MotionsManage_Request_alias(::upperlimb_msgs::srv::MotionsManage_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MotionsManage_Request alias(::upperlimb_msgs::srv::MotionsManage_Request::_alias_type arg)
  {
    msg_.alias = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsManage_Request msg_;
};

class Init_MotionsManage_Request_filename
{
public:
  Init_MotionsManage_Request_filename()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionsManage_Request_alias filename(::upperlimb_msgs::srv::MotionsManage_Request::_filename_type arg)
  {
    msg_.filename = std::move(arg);
    return Init_MotionsManage_Request_alias(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsManage_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MotionsManage_Request>()
{
  return upperlimb_msgs::srv::builder::Init_MotionsManage_Request_filename();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MotionsManage_Response_info
{
public:
  explicit Init_MotionsManage_Response_info(::upperlimb_msgs::srv::MotionsManage_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MotionsManage_Response info(::upperlimb_msgs::srv::MotionsManage_Response::_info_type arg)
  {
    msg_.info = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsManage_Response msg_;
};

class Init_MotionsManage_Response_message
{
public:
  explicit Init_MotionsManage_Response_message(::upperlimb_msgs::srv::MotionsManage_Response & msg)
  : msg_(msg)
  {}
  Init_MotionsManage_Response_info message(::upperlimb_msgs::srv::MotionsManage_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_MotionsManage_Response_info(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsManage_Response msg_;
};

class Init_MotionsManage_Response_success
{
public:
  Init_MotionsManage_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MotionsManage_Response_message success(::upperlimb_msgs::srv::MotionsManage_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_MotionsManage_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::MotionsManage_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MotionsManage_Response>()
{
  return upperlimb_msgs::srv::builder::Init_MotionsManage_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__BUILDER_HPP_
