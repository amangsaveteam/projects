﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/FK.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__FK__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__FK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'joints'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/FK in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__FK_Request
{
  /// 关节角
  rosidl_runtime_c__double__Sequence joints;
  /// 参与笛卡尔空间规划的机器人身体部位(必须有左臂或右臂或双臂的索引). 仅当全身控制时有用,用来指定当前要控制的目标部位,可以通过8421码进行叠加。参考 ArmTypeEnum.msg (Add on 1.4.0+)
  int8_t arm_type;
} upperlimb_msgs__srv__FK_Request;

// Struct for a sequence of upperlimb_msgs__srv__FK_Request.
typedef struct upperlimb_msgs__srv__FK_Request__Sequence
{
  upperlimb_msgs__srv__FK_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__FK_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"
// Member 'pose'
// Member 'pose_array'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'arm_type_array'
// already included above
// #include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/FK in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__FK_Response
{
  bool success;
  rosidl_runtime_c__String message;
  /// tcp的位姿     xyz:
  geometry_msgs__msg__Pose pose;
  /// tcp位姿对应的机器人身体部位。参考 ArmTypeEnum.msg (Add on 2.0.0+)
  int8_t arm_type;
  /// 对应的位姿数组  xyz: 仅当全身控制时在pose_array中返回数据,当指定的armtype为多部位时,该数组对应各个部位的pose (Add on 1.4.0+)
  geometry_msgs__msg__Pose__Sequence pose_array;
  /// pose_array中每个位姿对应的机器人身体部位。参考 ArmTypeEnum.msg (Add on 2.0.0+)
  rosidl_runtime_c__int8__Sequence arm_type_array;
} upperlimb_msgs__srv__FK_Response;

// Struct for a sequence of upperlimb_msgs__srv__FK_Response.
typedef struct upperlimb_msgs__srv__FK_Response__Sequence
{
  upperlimb_msgs__srv__FK_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__FK_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__FK__STRUCT_H_
