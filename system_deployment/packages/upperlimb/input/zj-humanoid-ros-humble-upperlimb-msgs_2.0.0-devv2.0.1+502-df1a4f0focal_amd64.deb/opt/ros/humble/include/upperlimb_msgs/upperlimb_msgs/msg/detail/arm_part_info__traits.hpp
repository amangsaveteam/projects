// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:msg/ArmPartInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__TRAITS_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/msg/detail/arm_part_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace upperlimb_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ArmPartInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: mask
  {
    out << "mask: ";
    rosidl_generator_traits::value_to_yaml(msg.mask, out);
    out << ", ";
  }

  // member: enabled
  {
    out << "enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.enabled, out);
    out << ", ";
  }

  // member: joint_num
  {
    out << "joint_num: ";
    rosidl_generator_traits::value_to_yaml(msg.joint_num, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ArmPartInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: mask
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mask: ";
    rosidl_generator_traits::value_to_yaml(msg.mask, out);
    out << "\n";
  }

  // member: enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.enabled, out);
    out << "\n";
  }

  // member: joint_num
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "joint_num: ";
    rosidl_generator_traits::value_to_yaml(msg.joint_num, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ArmPartInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::msg::ArmPartInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::msg::ArmPartInfo & msg)
{
  return upperlimb_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::msg::ArmPartInfo>()
{
  return "upperlimb_msgs::msg::ArmPartInfo";
}

template<>
inline const char * name<upperlimb_msgs::msg::ArmPartInfo>()
{
  return "upperlimb_msgs/msg/ArmPartInfo";
}

template<>
struct has_fixed_size<upperlimb_msgs::msg::ArmPartInfo>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<upperlimb_msgs::msg::ArmPartInfo>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<upperlimb_msgs::msg::ArmPartInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__TRAITS_HPP_
