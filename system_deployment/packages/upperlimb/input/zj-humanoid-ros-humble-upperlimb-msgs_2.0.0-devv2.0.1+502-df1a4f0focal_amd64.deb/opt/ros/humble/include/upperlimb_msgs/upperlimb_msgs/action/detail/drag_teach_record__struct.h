﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:action/DragTeachRecord.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__STRUCT_H_
#define UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_Goal
{
  /// 要生成的拖拽文件名称,如果不给定的话 则自己生成
  rosidl_runtime_c__String name;
} upperlimb_msgs__action__DragTeachRecord_Goal;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_Goal.
typedef struct upperlimb_msgs__action__DragTeachRecord_Goal__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_Goal__Sequence;


// Constants defined in the message

/// Constant 'SUCCESS'.
/**
  * 当前无法记录(机器人状态不允许执行动作)
 */
enum
{
  upperlimb_msgs__action__DragTeachRecord_Result__SUCCESS = 0
};

/// Constant 'ROBOT_CONTROL_STATE_EXCEPTION'.
/**
  * 轨迹记录过程中退出了示教模式或因为当前不在示教模式而无法进入轨迹记录状态
 */
enum
{
  upperlimb_msgs__action__DragTeachRecord_Result__ROBOT_CONTROL_STATE_EXCEPTION = 1
};

/// Constant 'FILE_NAME_EXISTED'.
/**
  * 给定的文件名已存在
 */
enum
{
  upperlimb_msgs__action__DragTeachRecord_Result__FILE_NAME_EXISTED = 2
};

/// Constant 'FILE_SAVE_FAILED'.
/**
  * 文件保存失败
 */
enum
{
  upperlimb_msgs__action__DragTeachRecord_Result__FILE_SAVE_FAILED = 3
};

/// Constant 'USER_OPERATION_EXCEPTION'.
/**
  * 用户操作异常(取消/新数据等)
 */
enum
{
  upperlimb_msgs__action__DragTeachRecord_Result__USER_OPERATION_EXCEPTION = 4
};

// Include directives for member types
// Member 'message'
// Member 'name'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_Result
{
  /// 执行结果
  bool success;
  /// 执行结果信息
  rosidl_runtime_c__String message;
  /// 最后生成的文件名称
  rosidl_runtime_c__String name;
  /// 轨迹的当前总时长
  double total_time;
  /// 状态码
  int32_t state_code;
} upperlimb_msgs__action__DragTeachRecord_Result;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_Result.
typedef struct upperlimb_msgs__action__DragTeachRecord_Result__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_Result__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'name'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_Feedback
{
  rosidl_runtime_c__String name;
  /// 轨迹的当前总时长
  double total_time;
} upperlimb_msgs__action__DragTeachRecord_Feedback;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_Feedback.
typedef struct upperlimb_msgs__action__DragTeachRecord_Feedback__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "upperlimb_msgs/action/detail/drag_teach_record__struct.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  upperlimb_msgs__action__DragTeachRecord_Goal goal;
} upperlimb_msgs__action__DragTeachRecord_SendGoal_Request;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_SendGoal_Request.
typedef struct upperlimb_msgs__action__DragTeachRecord_SendGoal_Request__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} upperlimb_msgs__action__DragTeachRecord_SendGoal_Response;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_SendGoal_Response.
typedef struct upperlimb_msgs__action__DragTeachRecord_SendGoal_Response__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} upperlimb_msgs__action__DragTeachRecord_GetResult_Request;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_GetResult_Request.
typedef struct upperlimb_msgs__action__DragTeachRecord_GetResult_Request__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_record__struct.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_GetResult_Response
{
  int8_t status;
  upperlimb_msgs__action__DragTeachRecord_Result result;
} upperlimb_msgs__action__DragTeachRecord_GetResult_Response;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_GetResult_Response.
typedef struct upperlimb_msgs__action__DragTeachRecord_GetResult_Response__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_record__struct.h"

/// Struct defined in action/DragTeachRecord in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachRecord_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  upperlimb_msgs__action__DragTeachRecord_Feedback feedback;
} upperlimb_msgs__action__DragTeachRecord_FeedbackMessage;

// Struct for a sequence of upperlimb_msgs__action__DragTeachRecord_FeedbackMessage.
typedef struct upperlimb_msgs__action__DragTeachRecord_FeedbackMessage__Sequence
{
  upperlimb_msgs__action__DragTeachRecord_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachRecord_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__STRUCT_H_
