// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/FilesLists.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__FILES_LISTS__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__FILES_LISTS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/files_lists__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::FilesLists_Request>()
{
  return ::upperlimb_msgs::srv::FilesLists_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_FilesLists_Response_files
{
public:
  explicit Init_FilesLists_Response_files(::upperlimb_msgs::srv::FilesLists_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::FilesLists_Response files(::upperlimb_msgs::srv::FilesLists_Response::_files_type arg)
  {
    msg_.files = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::FilesLists_Response msg_;
};

class Init_FilesLists_Response_message
{
public:
  explicit Init_FilesLists_Response_message(::upperlimb_msgs::srv::FilesLists_Response & msg)
  : msg_(msg)
  {}
  Init_FilesLists_Response_files message(::upperlimb_msgs::srv::FilesLists_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_FilesLists_Response_files(msg_);
  }

private:
  ::upperlimb_msgs::srv::FilesLists_Response msg_;
};

class Init_FilesLists_Response_success
{
public:
  Init_FilesLists_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FilesLists_Response_message success(::upperlimb_msgs::srv::FilesLists_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_FilesLists_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::FilesLists_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::FilesLists_Response>()
{
  return upperlimb_msgs::srv::builder::Init_FilesLists_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__FILES_LISTS__BUILDER_HPP_
