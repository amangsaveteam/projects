// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/SpeedL.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__SPEED_L_H_
#define UPPERLIMB_MSGS__MSG__SPEED_L_H_

#include "upperlimb_msgs/msg/detail/speed_l__struct.h"
#include "upperlimb_msgs/msg/detail/speed_l__functions.h"
#include "upperlimb_msgs/msg/detail/speed_l__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__SPEED_L_H_
