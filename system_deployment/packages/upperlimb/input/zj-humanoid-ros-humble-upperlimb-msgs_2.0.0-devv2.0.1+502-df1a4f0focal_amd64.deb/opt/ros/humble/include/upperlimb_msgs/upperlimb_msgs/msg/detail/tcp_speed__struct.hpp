// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:msg/TcpSpeed.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__STRUCT_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__msg__TcpSpeed __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__msg__TcpSpeed __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct TcpSpeed_
{
  using Type = TcpSpeed_<ContainerAllocator>;

  explicit TcpSpeed_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<double, 6>::iterator, double>(this->left_arm.begin(), this->left_arm.end(), 0.0);
      std::fill<typename std::array<double, 6>::iterator, double>(this->right_arm.begin(), this->right_arm.end(), 0.0);
    }
  }

  explicit TcpSpeed_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    left_arm(_alloc),
    right_arm(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<double, 6>::iterator, double>(this->left_arm.begin(), this->left_arm.end(), 0.0);
      std::fill<typename std::array<double, 6>::iterator, double>(this->right_arm.begin(), this->right_arm.end(), 0.0);
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _left_arm_type =
    std::array<double, 6>;
  _left_arm_type left_arm;
  using _right_arm_type =
    std::array<double, 6>;
  _right_arm_type right_arm;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__left_arm(
    const std::array<double, 6> & _arg)
  {
    this->left_arm = _arg;
    return *this;
  }
  Type & set__right_arm(
    const std::array<double, 6> & _arg)
  {
    this->right_arm = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__msg__TcpSpeed
    std::shared_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__msg__TcpSpeed
    std::shared_ptr<upperlimb_msgs::msg::TcpSpeed_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const TcpSpeed_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->left_arm != other.left_arm) {
      return false;
    }
    if (this->right_arm != other.right_arm) {
      return false;
    }
    return true;
  }
  bool operator!=(const TcpSpeed_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct TcpSpeed_

// alias to use template instance with default allocator
using TcpSpeed =
  upperlimb_msgs::msg::TcpSpeed_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__STRUCT_HPP_
