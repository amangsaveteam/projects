// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/ArmType.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__ARM_TYPE__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__ARM_TYPE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/arm_type__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_ArmType_Request_arm_type
{
public:
  Init_ArmType_Request_arm_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::srv::ArmType_Request arm_type(::upperlimb_msgs::srv::ArmType_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::ArmType_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::ArmType_Request>()
{
  return upperlimb_msgs::srv::builder::Init_ArmType_Request_arm_type();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_ArmType_Response_message
{
public:
  explicit Init_ArmType_Response_message(::upperlimb_msgs::srv::ArmType_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::ArmType_Response message(::upperlimb_msgs::srv::ArmType_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::ArmType_Response msg_;
};

class Init_ArmType_Response_success
{
public:
  Init_ArmType_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ArmType_Response_message success(::upperlimb_msgs::srv::ArmType_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_ArmType_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::ArmType_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::ArmType_Response>()
{
  return upperlimb_msgs::srv::builder::Init_ArmType_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__ARM_TYPE__BUILDER_HPP_
