// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/FK.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__FK__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__FK__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/fk__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_FK_Request_arm_type
{
public:
  explicit Init_FK_Request_arm_type(::upperlimb_msgs::srv::FK_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::FK_Request arm_type(::upperlimb_msgs::srv::FK_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Request msg_;
};

class Init_FK_Request_joints
{
public:
  Init_FK_Request_joints()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FK_Request_arm_type joints(::upperlimb_msgs::srv::FK_Request::_joints_type arg)
  {
    msg_.joints = std::move(arg);
    return Init_FK_Request_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::FK_Request>()
{
  return upperlimb_msgs::srv::builder::Init_FK_Request_joints();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_FK_Response_arm_type_array
{
public:
  explicit Init_FK_Response_arm_type_array(::upperlimb_msgs::srv::FK_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::FK_Response arm_type_array(::upperlimb_msgs::srv::FK_Response::_arm_type_array_type arg)
  {
    msg_.arm_type_array = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Response msg_;
};

class Init_FK_Response_pose_array
{
public:
  explicit Init_FK_Response_pose_array(::upperlimb_msgs::srv::FK_Response & msg)
  : msg_(msg)
  {}
  Init_FK_Response_arm_type_array pose_array(::upperlimb_msgs::srv::FK_Response::_pose_array_type arg)
  {
    msg_.pose_array = std::move(arg);
    return Init_FK_Response_arm_type_array(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Response msg_;
};

class Init_FK_Response_arm_type
{
public:
  explicit Init_FK_Response_arm_type(::upperlimb_msgs::srv::FK_Response & msg)
  : msg_(msg)
  {}
  Init_FK_Response_pose_array arm_type(::upperlimb_msgs::srv::FK_Response::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return Init_FK_Response_pose_array(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Response msg_;
};

class Init_FK_Response_pose
{
public:
  explicit Init_FK_Response_pose(::upperlimb_msgs::srv::FK_Response & msg)
  : msg_(msg)
  {}
  Init_FK_Response_arm_type pose(::upperlimb_msgs::srv::FK_Response::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_FK_Response_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Response msg_;
};

class Init_FK_Response_message
{
public:
  explicit Init_FK_Response_message(::upperlimb_msgs::srv::FK_Response & msg)
  : msg_(msg)
  {}
  Init_FK_Response_pose message(::upperlimb_msgs::srv::FK_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_FK_Response_pose(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Response msg_;
};

class Init_FK_Response_success
{
public:
  Init_FK_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FK_Response_message success(::upperlimb_msgs::srv::FK_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_FK_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::FK_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::FK_Response>()
{
  return upperlimb_msgs::srv::builder::Init_FK_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__FK__BUILDER_HPP_
