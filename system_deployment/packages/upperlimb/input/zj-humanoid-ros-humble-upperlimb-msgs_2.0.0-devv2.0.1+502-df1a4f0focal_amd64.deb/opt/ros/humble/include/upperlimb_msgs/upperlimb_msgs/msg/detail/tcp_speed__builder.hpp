// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/TcpSpeed.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/tcp_speed__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_TcpSpeed_right_arm
{
public:
  explicit Init_TcpSpeed_right_arm(::upperlimb_msgs::msg::TcpSpeed & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::TcpSpeed right_arm(::upperlimb_msgs::msg::TcpSpeed::_right_arm_type arg)
  {
    msg_.right_arm = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::TcpSpeed msg_;
};

class Init_TcpSpeed_left_arm
{
public:
  explicit Init_TcpSpeed_left_arm(::upperlimb_msgs::msg::TcpSpeed & msg)
  : msg_(msg)
  {}
  Init_TcpSpeed_right_arm left_arm(::upperlimb_msgs::msg::TcpSpeed::_left_arm_type arg)
  {
    msg_.left_arm = std::move(arg);
    return Init_TcpSpeed_right_arm(msg_);
  }

private:
  ::upperlimb_msgs::msg::TcpSpeed msg_;
};

class Init_TcpSpeed_header
{
public:
  Init_TcpSpeed_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TcpSpeed_left_arm header(::upperlimb_msgs::msg::TcpSpeed::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_TcpSpeed_left_arm(msg_);
  }

private:
  ::upperlimb_msgs::msg::TcpSpeed msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::TcpSpeed>()
{
  return upperlimb_msgs::msg::builder::Init_TcpSpeed_header();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__BUILDER_HPP_
