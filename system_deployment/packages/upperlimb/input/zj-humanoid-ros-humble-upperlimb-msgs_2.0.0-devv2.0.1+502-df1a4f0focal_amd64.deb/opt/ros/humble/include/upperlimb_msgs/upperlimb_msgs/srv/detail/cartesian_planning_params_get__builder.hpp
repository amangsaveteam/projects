// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/CartesianPlanningParamsGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_GET__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_GET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/cartesian_planning_params_get__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_CartesianPlanningParamsGet_Request_arm_type
{
public:
  Init_CartesianPlanningParamsGet_Request_arm_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::srv::CartesianPlanningParamsGet_Request arm_type(::upperlimb_msgs::srv::CartesianPlanningParamsGet_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsGet_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::CartesianPlanningParamsGet_Request>()
{
  return upperlimb_msgs::srv::builder::Init_CartesianPlanningParamsGet_Request_arm_type();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_CartesianPlanningParamsGet_Response_message
{
public:
  explicit Init_CartesianPlanningParamsGet_Response_message(::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response message(::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response msg_;
};

class Init_CartesianPlanningParamsGet_Response_success
{
public:
  explicit Init_CartesianPlanningParamsGet_Response_success(::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response & msg)
  : msg_(msg)
  {}
  Init_CartesianPlanningParamsGet_Response_message success(::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_CartesianPlanningParamsGet_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response msg_;
};

class Init_CartesianPlanningParamsGet_Response_joint_mask
{
public:
  Init_CartesianPlanningParamsGet_Response_joint_mask()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CartesianPlanningParamsGet_Response_success joint_mask(::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response::_joint_mask_type arg)
  {
    msg_.joint_mask = std::move(arg);
    return Init_CartesianPlanningParamsGet_Response_success(msg_);
  }

private:
  ::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::CartesianPlanningParamsGet_Response>()
{
  return upperlimb_msgs::srv::builder::Init_CartesianPlanningParamsGet_Response_joint_mask();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__CARTESIAN_PLANNING_PARAMS_GET__BUILDER_HPP_
