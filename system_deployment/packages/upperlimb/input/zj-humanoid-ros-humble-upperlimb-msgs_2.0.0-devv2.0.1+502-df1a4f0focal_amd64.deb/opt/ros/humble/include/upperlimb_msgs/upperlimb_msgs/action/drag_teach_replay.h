// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:action/DragTeachReplay.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DRAG_TEACH_REPLAY_H_
#define UPPERLIMB_MSGS__ACTION__DRAG_TEACH_REPLAY_H_

#include "upperlimb_msgs/action/detail/drag_teach_replay__struct.h"
#include "upperlimb_msgs/action/detail/drag_teach_replay__functions.h"
#include "upperlimb_msgs/action/detail/drag_teach_replay__type_support.h"

#endif  // UPPERLIMB_MSGS__ACTION__DRAG_TEACH_REPLAY_H_
