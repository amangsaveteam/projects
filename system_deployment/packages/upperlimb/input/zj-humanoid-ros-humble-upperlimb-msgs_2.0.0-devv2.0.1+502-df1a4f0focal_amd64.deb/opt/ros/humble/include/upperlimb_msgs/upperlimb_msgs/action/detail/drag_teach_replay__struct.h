﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:action/DragTeachReplay.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__STRUCT_H_
#define UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_Goal
{
  /// 要回放的拖拽文件名称
  rosidl_runtime_c__String name;
  /// 运行到上述指定动作第一个点的最大速度
  double v;
  /// 运行到上述指定动作第一个点的最大加速度
  double acc;
  /// 从当前位置运行到上述指定动作第一个点的总时长;当给定该参数的时候,忽略v和acc参数.
  double t;
  /// 起始时间
  double start_time;
  /// 结束时间
  double end_time;
} upperlimb_msgs__action__DragTeachReplay_Goal;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_Goal.
typedef struct upperlimb_msgs__action__DragTeachReplay_Goal__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_Goal * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_Goal__Sequence;


// Constants defined in the message

/// Constant 'SUCCESS'.
/**
  * 执行成功
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__SUCCESS = 0
};

/// Constant 'ROBOT_CONTROL_STATE_EXCEPTION'.
/**
  * 机器人控制状态异常，无法执行动作
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__ROBOT_CONTROL_STATE_EXCEPTION = 1
};

/// Constant 'FILE_NAME_INVALID'.
/**
  * 文件名无效
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__FILE_NAME_INVALID = 2
};

/// Constant 'FILE_NOT_FOUND'.
/**
  * 指定的文件不存在
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__FILE_NOT_FOUND = 3
};

/// Constant 'FILE_INVALID'.
/**
  * 文件无效或损坏
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__FILE_INVALID = 4
};

/// Constant 'FILE_READ_FAILED'.
/**
  * 文件读取失败
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__FILE_READ_FAILED = 5
};

/// Constant 'REPLAY_START_FAILED'.
/**
  * 回放启动失败
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__REPLAY_START_FAILED = 6
};

/// Constant 'USER_OPERATION_EXCEPTION'.
/**
  * 用户操作异常(取消/新数据等)
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__USER_OPERATION_EXCEPTION = 7
};

/// Constant 'REPLAY_INTERRUPTED'.
/**
  * 回放被中断
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__REPLAY_INTERRUPTED = 8
};

/// Constant 'MOVE_TO_FIRST_POINT_FAILED'.
/**
  * 移动到第一个点失败
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__MOVE_TO_FIRST_POINT_FAILED = 9
};

/// Constant 'MOVE_TO_FIRST_POINT_PREEMPTED'.
/**
  * 移动到第一个点被抢占
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__MOVE_TO_FIRST_POINT_PREEMPTED = 10
};

/// Constant 'INPUT_PARAM_INVALID'.
/**
  * 输入参数无效
 */
enum
{
  upperlimb_msgs__action__DragTeachReplay_Result__INPUT_PARAM_INVALID = 11
};

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_Result
{
  /// 执行结果
  bool success;
  /// 执行结果信息
  rosidl_runtime_c__String message;
  /// 状态码
  int32_t state_code;
} upperlimb_msgs__action__DragTeachReplay_Result;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_Result.
typedef struct upperlimb_msgs__action__DragTeachReplay_Result__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_Result * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_Result__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'name'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_Feedback
{
  rosidl_runtime_c__String name;
  /// 执行进度百分比
  int32_t progress;
} upperlimb_msgs__action__DragTeachReplay_Feedback;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_Feedback.
typedef struct upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_Feedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_Feedback__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'goal'
#include "upperlimb_msgs/action/detail/drag_teach_replay__struct.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_SendGoal_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
  upperlimb_msgs__action__DragTeachReplay_Goal goal;
} upperlimb_msgs__action__DragTeachReplay_SendGoal_Request;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_SendGoal_Request.
typedef struct upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_SendGoal_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_SendGoal_Response
{
  bool accepted;
  builtin_interfaces__msg__Time stamp;
} upperlimb_msgs__action__DragTeachReplay_SendGoal_Response;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_SendGoal_Response.
typedef struct upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_SendGoal_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_GetResult_Request
{
  unique_identifier_msgs__msg__UUID goal_id;
} upperlimb_msgs__action__DragTeachReplay_GetResult_Request;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_GetResult_Request.
typedef struct upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_GetResult_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_GetResult_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'result'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_replay__struct.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_GetResult_Response
{
  int8_t status;
  upperlimb_msgs__action__DragTeachReplay_Result result;
} upperlimb_msgs__action__DragTeachReplay_GetResult_Response;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_GetResult_Response.
typedef struct upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_GetResult_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_GetResult_Response__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.h"
// Member 'feedback'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_replay__struct.h"

/// Struct defined in action/DragTeachReplay in the package upperlimb_msgs.
typedef struct upperlimb_msgs__action__DragTeachReplay_FeedbackMessage
{
  unique_identifier_msgs__msg__UUID goal_id;
  upperlimb_msgs__action__DragTeachReplay_Feedback feedback;
} upperlimb_msgs__action__DragTeachReplay_FeedbackMessage;

// Struct for a sequence of upperlimb_msgs__action__DragTeachReplay_FeedbackMessage.
typedef struct upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence
{
  upperlimb_msgs__action__DragTeachReplay_FeedbackMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__action__DragTeachReplay_FeedbackMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_REPLAY__STRUCT_H_
