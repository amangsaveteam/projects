// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:srv/MotionsManage.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__TRAITS_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/srv/detail/motions_manage__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const MotionsManage_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: filename
  {
    out << "filename: ";
    rosidl_generator_traits::value_to_yaml(msg.filename, out);
    out << ", ";
  }

  // member: alias
  {
    out << "alias: ";
    rosidl_generator_traits::value_to_yaml(msg.alias, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MotionsManage_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: filename
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "filename: ";
    rosidl_generator_traits::value_to_yaml(msg.filename, out);
    out << "\n";
  }

  // member: alias
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alias: ";
    rosidl_generator_traits::value_to_yaml(msg.alias, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MotionsManage_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::MotionsManage_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::MotionsManage_Request & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::MotionsManage_Request>()
{
  return "upperlimb_msgs::srv::MotionsManage_Request";
}

template<>
inline const char * name<upperlimb_msgs::srv::MotionsManage_Request>()
{
  return "upperlimb_msgs/srv/MotionsManage_Request";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MotionsManage_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MotionsManage_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::MotionsManage_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'info'
#include "upperlimb_msgs/msg/detail/motion_info__traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const MotionsManage_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << ", ";
  }

  // member: info
  {
    out << "info: ";
    to_flow_style_yaml(msg.info, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MotionsManage_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }

  // member: info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "info:\n";
    to_block_style_yaml(msg.info, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MotionsManage_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::MotionsManage_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::MotionsManage_Response & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::MotionsManage_Response>()
{
  return "upperlimb_msgs::srv::MotionsManage_Response";
}

template<>
inline const char * name<upperlimb_msgs::srv::MotionsManage_Response>()
{
  return "upperlimb_msgs/srv/MotionsManage_Response";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MotionsManage_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MotionsManage_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::MotionsManage_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<upperlimb_msgs::srv::MotionsManage>()
{
  return "upperlimb_msgs::srv::MotionsManage";
}

template<>
inline const char * name<upperlimb_msgs::srv::MotionsManage>()
{
  return "upperlimb_msgs/srv/MotionsManage";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::MotionsManage>
  : std::integral_constant<
    bool,
    has_fixed_size<upperlimb_msgs::srv::MotionsManage_Request>::value &&
    has_fixed_size<upperlimb_msgs::srv::MotionsManage_Response>::value
  >
{
};

template<>
struct has_bounded_size<upperlimb_msgs::srv::MotionsManage>
  : std::integral_constant<
    bool,
    has_bounded_size<upperlimb_msgs::srv::MotionsManage_Request>::value &&
    has_bounded_size<upperlimb_msgs::srv::MotionsManage_Response>::value
  >
{
};

template<>
struct is_service<upperlimb_msgs::srv::MotionsManage>
  : std::true_type
{
};

template<>
struct is_service_request<upperlimb_msgs::srv::MotionsManage_Request>
  : std::true_type
{
};

template<>
struct is_service_response<upperlimb_msgs::srv::MotionsManage_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOTIONS_MANAGE__TRAITS_HPP_
