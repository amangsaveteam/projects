// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:msg/SpeedJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__STRUCT_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__msg__SpeedJ __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__msg__SpeedJ __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SpeedJ_
{
  using Type = SpeedJ_<ContainerAllocator>;

  explicit SpeedJ_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->acc = 0.0;
      this->arm_type = 0;
    }
  }

  explicit SpeedJ_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->acc = 0.0;
      this->arm_type = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _joint_speed_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _joint_speed_type joint_speed;
  using _acc_type =
    double;
  _acc_type acc;
  using _arm_type_type =
    int8_t;
  _arm_type_type arm_type;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__joint_speed(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->joint_speed = _arg;
    return *this;
  }
  Type & set__acc(
    const double & _arg)
  {
    this->acc = _arg;
    return *this;
  }
  Type & set__arm_type(
    const int8_t & _arg)
  {
    this->arm_type = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::msg::SpeedJ_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::msg::SpeedJ_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::SpeedJ_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::SpeedJ_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__msg__SpeedJ
    std::shared_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__msg__SpeedJ
    std::shared_ptr<upperlimb_msgs::msg::SpeedJ_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SpeedJ_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->joint_speed != other.joint_speed) {
      return false;
    }
    if (this->acc != other.acc) {
      return false;
    }
    if (this->arm_type != other.arm_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const SpeedJ_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SpeedJ_

// alias to use template instance with default allocator
using SpeedJ =
  upperlimb_msgs::msg::SpeedJ_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__SPEED_J__STRUCT_HPP_
