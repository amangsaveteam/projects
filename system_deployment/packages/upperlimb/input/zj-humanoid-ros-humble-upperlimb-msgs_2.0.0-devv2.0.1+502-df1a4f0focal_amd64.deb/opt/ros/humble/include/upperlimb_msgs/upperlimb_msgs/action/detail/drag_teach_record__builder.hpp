// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:action/DragTeachRecord.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__BUILDER_HPP_
#define UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/action/detail/drag_teach_record__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_Goal_name
{
public:
  Init_DragTeachRecord_Goal_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_Goal name(::upperlimb_msgs::action::DragTeachRecord_Goal::_name_type arg)
  {
    msg_.name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Goal msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_Goal>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_Goal_name();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_Result_state_code
{
public:
  explicit Init_DragTeachRecord_Result_state_code(::upperlimb_msgs::action::DragTeachRecord_Result & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_Result state_code(::upperlimb_msgs::action::DragTeachRecord_Result::_state_code_type arg)
  {
    msg_.state_code = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Result msg_;
};

class Init_DragTeachRecord_Result_total_time
{
public:
  explicit Init_DragTeachRecord_Result_total_time(::upperlimb_msgs::action::DragTeachRecord_Result & msg)
  : msg_(msg)
  {}
  Init_DragTeachRecord_Result_state_code total_time(::upperlimb_msgs::action::DragTeachRecord_Result::_total_time_type arg)
  {
    msg_.total_time = std::move(arg);
    return Init_DragTeachRecord_Result_state_code(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Result msg_;
};

class Init_DragTeachRecord_Result_name
{
public:
  explicit Init_DragTeachRecord_Result_name(::upperlimb_msgs::action::DragTeachRecord_Result & msg)
  : msg_(msg)
  {}
  Init_DragTeachRecord_Result_total_time name(::upperlimb_msgs::action::DragTeachRecord_Result::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_DragTeachRecord_Result_total_time(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Result msg_;
};

class Init_DragTeachRecord_Result_message
{
public:
  explicit Init_DragTeachRecord_Result_message(::upperlimb_msgs::action::DragTeachRecord_Result & msg)
  : msg_(msg)
  {}
  Init_DragTeachRecord_Result_name message(::upperlimb_msgs::action::DragTeachRecord_Result::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_DragTeachRecord_Result_name(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Result msg_;
};

class Init_DragTeachRecord_Result_success
{
public:
  Init_DragTeachRecord_Result_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DragTeachRecord_Result_message success(::upperlimb_msgs::action::DragTeachRecord_Result::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_DragTeachRecord_Result_message(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Result msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_Result>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_Result_success();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_Feedback_total_time
{
public:
  explicit Init_DragTeachRecord_Feedback_total_time(::upperlimb_msgs::action::DragTeachRecord_Feedback & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_Feedback total_time(::upperlimb_msgs::action::DragTeachRecord_Feedback::_total_time_type arg)
  {
    msg_.total_time = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Feedback msg_;
};

class Init_DragTeachRecord_Feedback_name
{
public:
  Init_DragTeachRecord_Feedback_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DragTeachRecord_Feedback_total_time name(::upperlimb_msgs::action::DragTeachRecord_Feedback::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_DragTeachRecord_Feedback_total_time(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_Feedback msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_Feedback>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_Feedback_name();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_SendGoal_Request_goal
{
public:
  explicit Init_DragTeachRecord_SendGoal_Request_goal(::upperlimb_msgs::action::DragTeachRecord_SendGoal_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_SendGoal_Request goal(::upperlimb_msgs::action::DragTeachRecord_SendGoal_Request::_goal_type arg)
  {
    msg_.goal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_SendGoal_Request msg_;
};

class Init_DragTeachRecord_SendGoal_Request_goal_id
{
public:
  Init_DragTeachRecord_SendGoal_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DragTeachRecord_SendGoal_Request_goal goal_id(::upperlimb_msgs::action::DragTeachRecord_SendGoal_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_DragTeachRecord_SendGoal_Request_goal(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_SendGoal_Request>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_SendGoal_Request_goal_id();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_SendGoal_Response_stamp
{
public:
  explicit Init_DragTeachRecord_SendGoal_Response_stamp(::upperlimb_msgs::action::DragTeachRecord_SendGoal_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_SendGoal_Response stamp(::upperlimb_msgs::action::DragTeachRecord_SendGoal_Response::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_SendGoal_Response msg_;
};

class Init_DragTeachRecord_SendGoal_Response_accepted
{
public:
  Init_DragTeachRecord_SendGoal_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DragTeachRecord_SendGoal_Response_stamp accepted(::upperlimb_msgs::action::DragTeachRecord_SendGoal_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_DragTeachRecord_SendGoal_Response_stamp(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_SendGoal_Response>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_SendGoal_Response_accepted();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_GetResult_Request_goal_id
{
public:
  Init_DragTeachRecord_GetResult_Request_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_GetResult_Request goal_id(::upperlimb_msgs::action::DragTeachRecord_GetResult_Request::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_GetResult_Request msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_GetResult_Request>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_GetResult_Request_goal_id();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_GetResult_Response_result
{
public:
  explicit Init_DragTeachRecord_GetResult_Response_result(::upperlimb_msgs::action::DragTeachRecord_GetResult_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_GetResult_Response result(::upperlimb_msgs::action::DragTeachRecord_GetResult_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_GetResult_Response msg_;
};

class Init_DragTeachRecord_GetResult_Response_status
{
public:
  Init_DragTeachRecord_GetResult_Response_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DragTeachRecord_GetResult_Response_result status(::upperlimb_msgs::action::DragTeachRecord_GetResult_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_DragTeachRecord_GetResult_Response_result(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_GetResult_Response msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_GetResult_Response>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_GetResult_Response_status();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace action
{

namespace builder
{

class Init_DragTeachRecord_FeedbackMessage_feedback
{
public:
  explicit Init_DragTeachRecord_FeedbackMessage_feedback(::upperlimb_msgs::action::DragTeachRecord_FeedbackMessage & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::action::DragTeachRecord_FeedbackMessage feedback(::upperlimb_msgs::action::DragTeachRecord_FeedbackMessage::_feedback_type arg)
  {
    msg_.feedback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_FeedbackMessage msg_;
};

class Init_DragTeachRecord_FeedbackMessage_goal_id
{
public:
  Init_DragTeachRecord_FeedbackMessage_goal_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DragTeachRecord_FeedbackMessage_feedback goal_id(::upperlimb_msgs::action::DragTeachRecord_FeedbackMessage::_goal_id_type arg)
  {
    msg_.goal_id = std::move(arg);
    return Init_DragTeachRecord_FeedbackMessage_feedback(msg_);
  }

private:
  ::upperlimb_msgs::action::DragTeachRecord_FeedbackMessage msg_;
};

}  // namespace builder

}  // namespace action

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::action::DragTeachRecord_FeedbackMessage>()
{
  return upperlimb_msgs::action::builder::Init_DragTeachRecord_FeedbackMessage_goal_id();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__BUILDER_HPP_
