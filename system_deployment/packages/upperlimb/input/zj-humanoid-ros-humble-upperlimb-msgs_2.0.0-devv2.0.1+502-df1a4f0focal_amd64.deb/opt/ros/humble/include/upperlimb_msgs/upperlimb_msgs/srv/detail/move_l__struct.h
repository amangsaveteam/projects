﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:srv/MoveL.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_L__STRUCT_H_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_L__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"

/// Struct defined in srv/MoveL in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MoveL_Request
{
  /// 位姿数组,当控制单臂时始终使用索引为0的数据,当控制双臂时索引0为左臂,索引1为右臂    xyz 单位:m
  geometry_msgs__msg__Pose pose[2];
  /// 最大关节速度
  double v;
  /// 最大加速度
  double acc;
  /// 执行方式 true:立即返回,并且可以被打断;false:阻塞执行,等待执行完成后返回.
  bool is_async;
  /// 参与笛卡尔空间规划的机器人身体部位(必须有左臂或右臂或双臂的索引). 仅当全身控制时有用,用来指定当前要控制的目标部位,可以通过8421码进行叠加。参考 ArmTypeEnum.msg (Add on 1.4.0+)
  int8_t arm_type;
} upperlimb_msgs__srv__MoveL_Request;

// Struct for a sequence of upperlimb_msgs__srv__MoveL_Request.
typedef struct upperlimb_msgs__srv__MoveL_Request__Sequence
{
  upperlimb_msgs__srv__MoveL_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MoveL_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/MoveL in the package upperlimb_msgs.
typedef struct upperlimb_msgs__srv__MoveL_Response
{
  /// 执行结果,该结果只反映命令的调用结果,并不能代表动作是否执行到位
  bool success;
  /// 提示信息
  rosidl_runtime_c__String message;
} upperlimb_msgs__srv__MoveL_Response;

// Struct for a sequence of upperlimb_msgs__srv__MoveL_Response.
typedef struct upperlimb_msgs__srv__MoveL_Response__Sequence
{
  upperlimb_msgs__srv__MoveL_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__srv__MoveL_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_L__STRUCT_H_
