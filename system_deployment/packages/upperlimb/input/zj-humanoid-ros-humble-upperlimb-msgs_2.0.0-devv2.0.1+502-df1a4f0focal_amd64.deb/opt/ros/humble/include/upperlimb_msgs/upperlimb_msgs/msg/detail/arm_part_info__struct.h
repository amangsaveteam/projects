﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/ArmPartInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/ArmPartInfo in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__ArmPartInfo
{
  /// 对应ArmTypeEnum中的定义
  uint8_t mask;
  /// 当前部位是否启用
  bool enabled;
  /// 当前部位的关节数量
  uint8_t joint_num;
} upperlimb_msgs__msg__ArmPartInfo;

// Struct for a sequence of upperlimb_msgs__msg__ArmPartInfo.
typedef struct upperlimb_msgs__msg__ArmPartInfo__Sequence
{
  upperlimb_msgs__msg__ArmPartInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__ArmPartInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__STRUCT_H_
