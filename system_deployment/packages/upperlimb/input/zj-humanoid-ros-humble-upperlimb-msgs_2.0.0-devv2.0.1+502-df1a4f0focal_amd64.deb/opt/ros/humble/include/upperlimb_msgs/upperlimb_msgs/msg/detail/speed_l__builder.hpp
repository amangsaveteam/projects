// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/SpeedL.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__SPEED_L__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__SPEED_L__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/speed_l__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_SpeedL_arm_type
{
public:
  explicit Init_SpeedL_arm_type(::upperlimb_msgs::msg::SpeedL & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::SpeedL arm_type(::upperlimb_msgs::msg::SpeedL::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedL msg_;
};

class Init_SpeedL_acc
{
public:
  explicit Init_SpeedL_acc(::upperlimb_msgs::msg::SpeedL & msg)
  : msg_(msg)
  {}
  Init_SpeedL_arm_type acc(::upperlimb_msgs::msg::SpeedL::_acc_type arg)
  {
    msg_.acc = std::move(arg);
    return Init_SpeedL_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedL msg_;
};

class Init_SpeedL_tcp_speed
{
public:
  explicit Init_SpeedL_tcp_speed(::upperlimb_msgs::msg::SpeedL & msg)
  : msg_(msg)
  {}
  Init_SpeedL_acc tcp_speed(::upperlimb_msgs::msg::SpeedL::_tcp_speed_type arg)
  {
    msg_.tcp_speed = std::move(arg);
    return Init_SpeedL_acc(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedL msg_;
};

class Init_SpeedL_header
{
public:
  Init_SpeedL_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SpeedL_tcp_speed header(::upperlimb_msgs::msg::SpeedL::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SpeedL_tcp_speed(msg_);
  }

private:
  ::upperlimb_msgs::msg::SpeedL msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::SpeedL>()
{
  return upperlimb_msgs::msg::builder::Init_SpeedL_header();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__SPEED_L__BUILDER_HPP_
