// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from upperlimb_msgs:srv/MoveJByPose.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "upperlimb_msgs/srv/detail/move_j_by_pose__rosidl_typesupport_introspection_c.h"
#include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "upperlimb_msgs/srv/detail/move_j_by_pose__functions.h"
#include "upperlimb_msgs/srv/detail/move_j_by_pose__struct.h"


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/pose.h"
// Member `pose`
#include "geometry_msgs/msg/detail/pose__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__MoveJByPose_Request__init(message_memory);
}

void upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__MoveJByPose_Request__fini(message_memory);
}

size_t upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__size_function__MoveJByPose_Request__pose(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_const_function__MoveJByPose_Request__pose(
  const void * untyped_member, size_t index)
{
  const geometry_msgs__msg__Pose * member =
    (const geometry_msgs__msg__Pose *)(untyped_member);
  return &member[index];
}

void * upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_function__MoveJByPose_Request__pose(
  void * untyped_member, size_t index)
{
  geometry_msgs__msg__Pose * member =
    (geometry_msgs__msg__Pose *)(untyped_member);
  return &member[index];
}

void upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__fetch_function__MoveJByPose_Request__pose(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const geometry_msgs__msg__Pose * item =
    ((const geometry_msgs__msg__Pose *)
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_const_function__MoveJByPose_Request__pose(untyped_member, index));
  geometry_msgs__msg__Pose * value =
    (geometry_msgs__msg__Pose *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__assign_function__MoveJByPose_Request__pose(
  void * untyped_member, size_t index, const void * untyped_value)
{
  geometry_msgs__msg__Pose * item =
    ((geometry_msgs__msg__Pose *)
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_function__MoveJByPose_Request__pose(untyped_member, index));
  const geometry_msgs__msg__Pose * value =
    (const geometry_msgs__msg__Pose *)(untyped_value);
  *item = *value;
}

size_t upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__size_function__MoveJByPose_Request__q7(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_const_function__MoveJByPose_Request__q7(
  const void * untyped_member, size_t index)
{
  const double * member =
    (const double *)(untyped_member);
  return &member[index];
}

void * upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_function__MoveJByPose_Request__q7(
  void * untyped_member, size_t index)
{
  double * member =
    (double *)(untyped_member);
  return &member[index];
}

void upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__fetch_function__MoveJByPose_Request__q7(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_const_function__MoveJByPose_Request__q7(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__assign_function__MoveJByPose_Request__q7(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_function__MoveJByPose_Request__q7(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_member_array[6] = {
  {
    "pose",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Request, pose),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__size_function__MoveJByPose_Request__pose,  // size() function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_const_function__MoveJByPose_Request__pose,  // get_const(index) function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_function__MoveJByPose_Request__pose,  // get(index) function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__fetch_function__MoveJByPose_Request__pose,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__assign_function__MoveJByPose_Request__pose,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "q7",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Request, q7),  // bytes offset in struct
    NULL,  // default value
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__size_function__MoveJByPose_Request__q7,  // size() function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_const_function__MoveJByPose_Request__q7,  // get_const(index) function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__get_function__MoveJByPose_Request__q7,  // get(index) function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__fetch_function__MoveJByPose_Request__q7,  // fetch(index, &value) function pointer
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__assign_function__MoveJByPose_Request__q7,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "v",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Request, v),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "acc",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Request, acc),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "is_async",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Request, is_async),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arm_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Request, arm_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "MoveJByPose_Request",  // message name
  6,  // number of fields
  sizeof(upperlimb_msgs__srv__MoveJByPose_Request),
  upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_member_array,  // message members
  upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, MoveJByPose_Request)() {
  upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Pose)();
  if (!upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__MoveJByPose_Request__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "upperlimb_msgs/srv/detail/move_j_by_pose__rosidl_typesupport_introspection_c.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "upperlimb_msgs/srv/detail/move_j_by_pose__functions.h"
// already included above
// #include "upperlimb_msgs/srv/detail/move_j_by_pose__struct.h"


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  upperlimb_msgs__srv__MoveJByPose_Response__init(message_memory);
}

void upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_fini_function(void * message_memory)
{
  upperlimb_msgs__srv__MoveJByPose_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_member_array[2] = {
  {
    "success",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Response, success),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "message",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(upperlimb_msgs__srv__MoveJByPose_Response, message),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_members = {
  "upperlimb_msgs__srv",  // message namespace
  "MoveJByPose_Response",  // message name
  2,  // number of fields
  sizeof(upperlimb_msgs__srv__MoveJByPose_Response),
  upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_member_array,  // message members
  upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_type_support_handle = {
  0,
  &upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, MoveJByPose_Response)() {
  if (!upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &upperlimb_msgs__srv__MoveJByPose_Response__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "upperlimb_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "upperlimb_msgs/srv/detail/move_j_by_pose__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_service_members = {
  "upperlimb_msgs__srv",  // service namespace
  "MoveJByPose",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_Request_message_type_support_handle,
  NULL  // response message
  // upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_Response_message_type_support_handle
};

static rosidl_service_type_support_t upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_service_type_support_handle = {
  0,
  &upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, MoveJByPose_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, MoveJByPose_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_upperlimb_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, MoveJByPose)() {
  if (!upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_service_type_support_handle.typesupport_identifier) {
    upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, MoveJByPose_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, upperlimb_msgs, srv, MoveJByPose_Response)()->data;
  }

  return &upperlimb_msgs__srv__detail__move_j_by_pose__rosidl_typesupport_introspection_c__MoveJByPose_service_type_support_handle;
}
