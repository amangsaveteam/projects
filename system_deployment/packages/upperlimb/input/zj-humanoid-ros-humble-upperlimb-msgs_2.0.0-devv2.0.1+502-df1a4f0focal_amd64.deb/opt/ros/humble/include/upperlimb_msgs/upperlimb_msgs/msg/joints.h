// generated from rosidl_generator_c/resource/idl.h.em
// with input from upperlimb_msgs:msg/Joints.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__JOINTS_H_
#define UPPERLIMB_MSGS__MSG__JOINTS_H_

#include "upperlimb_msgs/msg/detail/joints__struct.h"
#include "upperlimb_msgs/msg/detail/joints__functions.h"
#include "upperlimb_msgs/msg/detail/joints__type_support.h"

#endif  // UPPERLIMB_MSGS__MSG__JOINTS_H_
