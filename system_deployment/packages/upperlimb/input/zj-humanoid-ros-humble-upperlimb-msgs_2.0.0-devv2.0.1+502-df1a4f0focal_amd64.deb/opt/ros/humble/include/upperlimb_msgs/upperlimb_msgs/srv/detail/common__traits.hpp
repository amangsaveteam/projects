// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from upperlimb_msgs:srv/Common.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__COMMON__TRAITS_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__COMMON__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "upperlimb_msgs/srv/detail/common__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const Common_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: request
  {
    out << "request: ";
    rosidl_generator_traits::value_to_yaml(msg.request, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Common_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: request
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "request: ";
    rosidl_generator_traits::value_to_yaml(msg.request, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Common_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::Common_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::Common_Request & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::Common_Request>()
{
  return "upperlimb_msgs::srv::Common_Request";
}

template<>
inline const char * name<upperlimb_msgs::srv::Common_Request>()
{
  return "upperlimb_msgs/srv/Common_Request";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::Common_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::Common_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::Common_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace upperlimb_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const Common_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: response
  {
    out << "response: ";
    rosidl_generator_traits::value_to_yaml(msg.response, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Common_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: response
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "response: ";
    rosidl_generator_traits::value_to_yaml(msg.response, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Common_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace upperlimb_msgs

namespace rosidl_generator_traits
{

[[deprecated("use upperlimb_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const upperlimb_msgs::srv::Common_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  upperlimb_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use upperlimb_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const upperlimb_msgs::srv::Common_Response & msg)
{
  return upperlimb_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<upperlimb_msgs::srv::Common_Response>()
{
  return "upperlimb_msgs::srv::Common_Response";
}

template<>
inline const char * name<upperlimb_msgs::srv::Common_Response>()
{
  return "upperlimb_msgs/srv/Common_Response";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::Common_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<upperlimb_msgs::srv::Common_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<upperlimb_msgs::srv::Common_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<upperlimb_msgs::srv::Common>()
{
  return "upperlimb_msgs::srv::Common";
}

template<>
inline const char * name<upperlimb_msgs::srv::Common>()
{
  return "upperlimb_msgs/srv/Common";
}

template<>
struct has_fixed_size<upperlimb_msgs::srv::Common>
  : std::integral_constant<
    bool,
    has_fixed_size<upperlimb_msgs::srv::Common_Request>::value &&
    has_fixed_size<upperlimb_msgs::srv::Common_Response>::value
  >
{
};

template<>
struct has_bounded_size<upperlimb_msgs::srv::Common>
  : std::integral_constant<
    bool,
    has_bounded_size<upperlimb_msgs::srv::Common_Request>::value &&
    has_bounded_size<upperlimb_msgs::srv::Common_Response>::value
  >
{
};

template<>
struct is_service<upperlimb_msgs::srv::Common>
  : std::true_type
{
};

template<>
struct is_service_request<upperlimb_msgs::srv::Common_Request>
  : std::true_type
{
};

template<>
struct is_service_response<upperlimb_msgs::srv::Common_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__COMMON__TRAITS_HPP_
