// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/Pose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__POSE__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__POSE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/pose__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_Pose_rpy_deg
{
public:
  explicit Init_Pose_rpy_deg(::upperlimb_msgs::msg::Pose & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::Pose rpy_deg(::upperlimb_msgs::msg::Pose::_rpy_deg_type arg)
  {
    msg_.rpy_deg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::Pose msg_;
};

class Init_Pose_rpy_rad
{
public:
  explicit Init_Pose_rpy_rad(::upperlimb_msgs::msg::Pose & msg)
  : msg_(msg)
  {}
  Init_Pose_rpy_deg rpy_rad(::upperlimb_msgs::msg::Pose::_rpy_rad_type arg)
  {
    msg_.rpy_rad = std::move(arg);
    return Init_Pose_rpy_deg(msg_);
  }

private:
  ::upperlimb_msgs::msg::Pose msg_;
};

class Init_Pose_quaternion
{
public:
  explicit Init_Pose_quaternion(::upperlimb_msgs::msg::Pose & msg)
  : msg_(msg)
  {}
  Init_Pose_rpy_rad quaternion(::upperlimb_msgs::msg::Pose::_quaternion_type arg)
  {
    msg_.quaternion = std::move(arg);
    return Init_Pose_rpy_rad(msg_);
  }

private:
  ::upperlimb_msgs::msg::Pose msg_;
};

class Init_Pose_position
{
public:
  explicit Init_Pose_position(::upperlimb_msgs::msg::Pose & msg)
  : msg_(msg)
  {}
  Init_Pose_quaternion position(::upperlimb_msgs::msg::Pose::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_Pose_quaternion(msg_);
  }

private:
  ::upperlimb_msgs::msg::Pose msg_;
};

class Init_Pose_header
{
public:
  Init_Pose_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Pose_position header(::upperlimb_msgs::msg::Pose::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Pose_position(msg_);
  }

private:
  ::upperlimb_msgs::msg::Pose msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::Pose>()
{
  return upperlimb_msgs::msg::builder::Init_Pose_header();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__POSE__BUILDER_HPP_
