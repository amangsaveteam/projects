// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__TCP_SPEED_HPP_
#define UPPERLIMB_MSGS__MSG__TCP_SPEED_HPP_

#include "upperlimb_msgs/msg/detail/tcp_speed__struct.hpp"
#include "upperlimb_msgs/msg/detail/tcp_speed__builder.hpp"
#include "upperlimb_msgs/msg/detail/tcp_speed__traits.hpp"
#include "upperlimb_msgs/msg/detail/tcp_speed__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__TCP_SPEED_HPP_
