// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__ARM_TYPE_ENUM_HPP_
#define UPPERLIMB_MSGS__MSG__ARM_TYPE_ENUM_HPP_

#include "upperlimb_msgs/msg/detail/arm_type_enum__struct.hpp"
#include "upperlimb_msgs/msg/detail/arm_type_enum__builder.hpp"
#include "upperlimb_msgs/msg/detail/arm_type_enum__traits.hpp"
#include "upperlimb_msgs/msg/detail/arm_type_enum__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__ARM_TYPE_ENUM_HPP_
