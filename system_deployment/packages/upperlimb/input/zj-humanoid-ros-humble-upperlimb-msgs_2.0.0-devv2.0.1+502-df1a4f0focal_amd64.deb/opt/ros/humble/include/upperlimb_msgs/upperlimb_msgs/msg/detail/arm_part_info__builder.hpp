// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:msg/ArmPartInfo.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__BUILDER_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/msg/detail/arm_part_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace msg
{

namespace builder
{

class Init_ArmPartInfo_joint_num
{
public:
  explicit Init_ArmPartInfo_joint_num(::upperlimb_msgs::msg::ArmPartInfo & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::msg::ArmPartInfo joint_num(::upperlimb_msgs::msg::ArmPartInfo::_joint_num_type arg)
  {
    msg_.joint_num = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::msg::ArmPartInfo msg_;
};

class Init_ArmPartInfo_enabled
{
public:
  explicit Init_ArmPartInfo_enabled(::upperlimb_msgs::msg::ArmPartInfo & msg)
  : msg_(msg)
  {}
  Init_ArmPartInfo_joint_num enabled(::upperlimb_msgs::msg::ArmPartInfo::_enabled_type arg)
  {
    msg_.enabled = std::move(arg);
    return Init_ArmPartInfo_joint_num(msg_);
  }

private:
  ::upperlimb_msgs::msg::ArmPartInfo msg_;
};

class Init_ArmPartInfo_mask
{
public:
  Init_ArmPartInfo_mask()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ArmPartInfo_enabled mask(::upperlimb_msgs::msg::ArmPartInfo::_mask_type arg)
  {
    msg_.mask = std::move(arg);
    return Init_ArmPartInfo_enabled(msg_);
  }

private:
  ::upperlimb_msgs::msg::ArmPartInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::msg::ArmPartInfo>()
{
  return upperlimb_msgs::msg::builder::Init_ArmPartInfo_mask();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__ARM_PART_INFO__BUILDER_HPP_
