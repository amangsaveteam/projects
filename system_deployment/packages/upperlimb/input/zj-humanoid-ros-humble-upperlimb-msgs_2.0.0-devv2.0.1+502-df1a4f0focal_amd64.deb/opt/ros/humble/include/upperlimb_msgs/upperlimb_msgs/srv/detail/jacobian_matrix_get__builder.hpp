// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/JacobianMatrixGet.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__JACOBIAN_MATRIX_GET__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__JACOBIAN_MATRIX_GET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/jacobian_matrix_get__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_JacobianMatrixGet_Request_arm_type
{
public:
  Init_JacobianMatrixGet_Request_arm_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::upperlimb_msgs::srv::JacobianMatrixGet_Request arm_type(::upperlimb_msgs::srv::JacobianMatrixGet_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::JacobianMatrixGet_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::JacobianMatrixGet_Request>()
{
  return upperlimb_msgs::srv::builder::Init_JacobianMatrixGet_Request_arm_type();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_JacobianMatrixGet_Response_jacobian_matrix
{
public:
  explicit Init_JacobianMatrixGet_Response_jacobian_matrix(::upperlimb_msgs::srv::JacobianMatrixGet_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::JacobianMatrixGet_Response jacobian_matrix(::upperlimb_msgs::srv::JacobianMatrixGet_Response::_jacobian_matrix_type arg)
  {
    msg_.jacobian_matrix = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::JacobianMatrixGet_Response msg_;
};

class Init_JacobianMatrixGet_Response_message
{
public:
  explicit Init_JacobianMatrixGet_Response_message(::upperlimb_msgs::srv::JacobianMatrixGet_Response & msg)
  : msg_(msg)
  {}
  Init_JacobianMatrixGet_Response_jacobian_matrix message(::upperlimb_msgs::srv::JacobianMatrixGet_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_JacobianMatrixGet_Response_jacobian_matrix(msg_);
  }

private:
  ::upperlimb_msgs::srv::JacobianMatrixGet_Response msg_;
};

class Init_JacobianMatrixGet_Response_success
{
public:
  Init_JacobianMatrixGet_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JacobianMatrixGet_Response_message success(::upperlimb_msgs::srv::JacobianMatrixGet_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_JacobianMatrixGet_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::JacobianMatrixGet_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::JacobianMatrixGet_Response>()
{
  return upperlimb_msgs::srv::builder::Init_JacobianMatrixGet_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__JACOBIAN_MATRIX_GET__BUILDER_HPP_
