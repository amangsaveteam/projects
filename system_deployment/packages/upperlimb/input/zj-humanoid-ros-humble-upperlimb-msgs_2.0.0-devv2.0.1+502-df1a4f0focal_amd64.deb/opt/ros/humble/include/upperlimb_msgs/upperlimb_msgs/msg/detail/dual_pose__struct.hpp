// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:msg/DualPose.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__STRUCT_HPP_
#define UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'left_arm_pose'
// Member 'right_arm_pose'
#include "geometry_msgs/msg/detail/pose__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__msg__DualPose __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__msg__DualPose __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DualPose_
{
  using Type = DualPose_<ContainerAllocator>;

  explicit DualPose_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    left_arm_pose(_init),
    right_arm_pose(_init)
  {
    (void)_init;
  }

  explicit DualPose_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    left_arm_pose(_alloc, _init),
    right_arm_pose(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _left_arm_pose_type =
    geometry_msgs::msg::Pose_<ContainerAllocator>;
  _left_arm_pose_type left_arm_pose;
  using _right_arm_pose_type =
    geometry_msgs::msg::Pose_<ContainerAllocator>;
  _right_arm_pose_type right_arm_pose;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__left_arm_pose(
    const geometry_msgs::msg::Pose_<ContainerAllocator> & _arg)
  {
    this->left_arm_pose = _arg;
    return *this;
  }
  Type & set__right_arm_pose(
    const geometry_msgs::msg::Pose_<ContainerAllocator> & _arg)
  {
    this->right_arm_pose = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::msg::DualPose_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::msg::DualPose_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::DualPose_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::msg::DualPose_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__msg__DualPose
    std::shared_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__msg__DualPose
    std::shared_ptr<upperlimb_msgs::msg::DualPose_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DualPose_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->left_arm_pose != other.left_arm_pose) {
      return false;
    }
    if (this->right_arm_pose != other.right_arm_pose) {
      return false;
    }
    return true;
  }
  bool operator!=(const DualPose_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DualPose_

// alias to use template instance with default allocator
using DualPose =
  upperlimb_msgs::msg::DualPose_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__DUAL_POSE__STRUCT_HPP_
