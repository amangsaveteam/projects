﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from upperlimb_msgs:msg/TcpSpeed.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__STRUCT_H_
#define UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/TcpSpeed in the package upperlimb_msgs.
typedef struct upperlimb_msgs__msg__TcpSpeed
{
  std_msgs__msg__Header header;
  /// 左臂TCP速度信息
  double left_arm[6];
  /// 右臂TCP速度信息
  double right_arm[6];
} upperlimb_msgs__msg__TcpSpeed;

// Struct for a sequence of upperlimb_msgs__msg__TcpSpeed.
typedef struct upperlimb_msgs__msg__TcpSpeed__Sequence
{
  upperlimb_msgs__msg__TcpSpeed * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} upperlimb_msgs__msg__TcpSpeed__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // UPPERLIMB_MSGS__MSG__DETAIL__TCP_SPEED__STRUCT_H_
