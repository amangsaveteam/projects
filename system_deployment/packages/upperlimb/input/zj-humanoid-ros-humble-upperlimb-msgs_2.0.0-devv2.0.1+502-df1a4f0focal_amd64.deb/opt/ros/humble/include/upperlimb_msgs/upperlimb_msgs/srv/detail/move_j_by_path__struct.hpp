// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:srv/MoveJByPath.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_PATH__STRUCT_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_PATH__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'path'
#include "upperlimb_msgs/msg/detail/joints__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Request __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Request __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MoveJByPath_Request_
{
  using Type = MoveJByPath_Request_<ContainerAllocator>;

  explicit MoveJByPath_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->time = 0.0;
      this->is_async = false;
      this->arm_type = 0;
    }
  }

  explicit MoveJByPath_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->time = 0.0;
      this->is_async = false;
      this->arm_type = 0;
    }
  }

  // field types and members
  using _path_type =
    std::vector<upperlimb_msgs::msg::Joints_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<upperlimb_msgs::msg::Joints_<ContainerAllocator>>>;
  _path_type path;
  using _time_type =
    double;
  _time_type time;
  using _timestamp_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _timestamp_type timestamp;
  using _is_async_type =
    bool;
  _is_async_type is_async;
  using _arm_type_type =
    int8_t;
  _arm_type_type arm_type;

  // setters for named parameter idiom
  Type & set__path(
    const std::vector<upperlimb_msgs::msg::Joints_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<upperlimb_msgs::msg::Joints_<ContainerAllocator>>> & _arg)
  {
    this->path = _arg;
    return *this;
  }
  Type & set__time(
    const double & _arg)
  {
    this->time = _arg;
    return *this;
  }
  Type & set__timestamp(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__is_async(
    const bool & _arg)
  {
    this->is_async = _arg;
    return *this;
  }
  Type & set__arm_type(
    const int8_t & _arg)
  {
    this->arm_type = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Request
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Request
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MoveJByPath_Request_ & other) const
  {
    if (this->path != other.path) {
      return false;
    }
    if (this->time != other.time) {
      return false;
    }
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->is_async != other.is_async) {
      return false;
    }
    if (this->arm_type != other.arm_type) {
      return false;
    }
    return true;
  }
  bool operator!=(const MoveJByPath_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MoveJByPath_Request_

// alias to use template instance with default allocator
using MoveJByPath_Request =
  upperlimb_msgs::srv::MoveJByPath_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Response __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Response __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct MoveJByPath_Response_
{
  using Type = MoveJByPath_Response_<ContainerAllocator>;

  explicit MoveJByPath_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  explicit MoveJByPath_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Response
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__srv__MoveJByPath_Response
    std::shared_ptr<upperlimb_msgs::srv::MoveJByPath_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MoveJByPath_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const MoveJByPath_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MoveJByPath_Response_

// alias to use template instance with default allocator
using MoveJByPath_Response =
  upperlimb_msgs::srv::MoveJByPath_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace upperlimb_msgs

namespace upperlimb_msgs
{

namespace srv
{

struct MoveJByPath
{
  using Request = upperlimb_msgs::srv::MoveJByPath_Request;
  using Response = upperlimb_msgs::srv::MoveJByPath_Response;
};

}  // namespace srv

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J_BY_PATH__STRUCT_HPP_
