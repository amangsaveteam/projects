// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from upperlimb_msgs:srv/MoveJ.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__BUILDER_HPP_
#define UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "upperlimb_msgs/srv/detail/move_j__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MoveJ_Request_arm_type
{
public:
  explicit Init_MoveJ_Request_arm_type(::upperlimb_msgs::srv::MoveJ_Request & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MoveJ_Request arm_type(::upperlimb_msgs::srv::MoveJ_Request::_arm_type_type arg)
  {
    msg_.arm_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Request msg_;
};

class Init_MoveJ_Request_is_async
{
public:
  explicit Init_MoveJ_Request_is_async(::upperlimb_msgs::srv::MoveJ_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJ_Request_arm_type is_async(::upperlimb_msgs::srv::MoveJ_Request::_is_async_type arg)
  {
    msg_.is_async = std::move(arg);
    return Init_MoveJ_Request_arm_type(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Request msg_;
};

class Init_MoveJ_Request_t
{
public:
  explicit Init_MoveJ_Request_t(::upperlimb_msgs::srv::MoveJ_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJ_Request_is_async t(::upperlimb_msgs::srv::MoveJ_Request::_t_type arg)
  {
    msg_.t = std::move(arg);
    return Init_MoveJ_Request_is_async(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Request msg_;
};

class Init_MoveJ_Request_acc
{
public:
  explicit Init_MoveJ_Request_acc(::upperlimb_msgs::srv::MoveJ_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJ_Request_t acc(::upperlimb_msgs::srv::MoveJ_Request::_acc_type arg)
  {
    msg_.acc = std::move(arg);
    return Init_MoveJ_Request_t(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Request msg_;
};

class Init_MoveJ_Request_v
{
public:
  explicit Init_MoveJ_Request_v(::upperlimb_msgs::srv::MoveJ_Request & msg)
  : msg_(msg)
  {}
  Init_MoveJ_Request_acc v(::upperlimb_msgs::srv::MoveJ_Request::_v_type arg)
  {
    msg_.v = std::move(arg);
    return Init_MoveJ_Request_acc(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Request msg_;
};

class Init_MoveJ_Request_joints
{
public:
  Init_MoveJ_Request_joints()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJ_Request_v joints(::upperlimb_msgs::srv::MoveJ_Request::_joints_type arg)
  {
    msg_.joints = std::move(arg);
    return Init_MoveJ_Request_v(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MoveJ_Request>()
{
  return upperlimb_msgs::srv::builder::Init_MoveJ_Request_joints();
}

}  // namespace upperlimb_msgs


namespace upperlimb_msgs
{

namespace srv
{

namespace builder
{

class Init_MoveJ_Response_message
{
public:
  explicit Init_MoveJ_Response_message(::upperlimb_msgs::srv::MoveJ_Response & msg)
  : msg_(msg)
  {}
  ::upperlimb_msgs::srv::MoveJ_Response message(::upperlimb_msgs::srv::MoveJ_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Response msg_;
};

class Init_MoveJ_Response_success
{
public:
  Init_MoveJ_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveJ_Response_message success(::upperlimb_msgs::srv::MoveJ_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_MoveJ_Response_message(msg_);
  }

private:
  ::upperlimb_msgs::srv::MoveJ_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::upperlimb_msgs::srv::MoveJ_Response>()
{
  return upperlimb_msgs::srv::builder::Init_MoveJ_Response_success();
}

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__SRV__DETAIL__MOVE_J__BUILDER_HPP_
