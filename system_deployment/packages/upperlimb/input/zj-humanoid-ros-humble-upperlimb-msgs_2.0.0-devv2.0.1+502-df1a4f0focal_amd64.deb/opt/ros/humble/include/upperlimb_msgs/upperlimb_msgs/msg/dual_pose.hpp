// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__MSG__DUAL_POSE_HPP_
#define UPPERLIMB_MSGS__MSG__DUAL_POSE_HPP_

#include "upperlimb_msgs/msg/detail/dual_pose__struct.hpp"
#include "upperlimb_msgs/msg/detail/dual_pose__builder.hpp"
#include "upperlimb_msgs/msg/detail/dual_pose__traits.hpp"
#include "upperlimb_msgs/msg/detail/dual_pose__type_support.hpp"

#endif  // UPPERLIMB_MSGS__MSG__DUAL_POSE_HPP_
