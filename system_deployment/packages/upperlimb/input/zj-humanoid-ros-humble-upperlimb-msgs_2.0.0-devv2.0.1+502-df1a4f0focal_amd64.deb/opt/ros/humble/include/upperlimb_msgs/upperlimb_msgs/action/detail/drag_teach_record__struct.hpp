// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from upperlimb_msgs:action/DragTeachRecord.idl
// generated code does not contain a copyright notice

#ifndef UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__STRUCT_HPP_
#define UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Goal __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Goal __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_Goal_
{
  using Type = DragTeachRecord_Goal_<ContainerAllocator>;

  explicit DragTeachRecord_Goal_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
    }
  }

  explicit DragTeachRecord_Goal_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
    }
  }

  // field types and members
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;

  // setters for named parameter idiom
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Goal
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Goal
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_Goal_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_Goal_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_Goal_

// alias to use template instance with default allocator
using DragTeachRecord_Goal =
  upperlimb_msgs::action::DragTeachRecord_Goal_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace upperlimb_msgs


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Result __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Result __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_Result_
{
  using Type = DragTeachRecord_Result_<ContainerAllocator>;

  explicit DragTeachRecord_Result_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->name = "";
      this->total_time = 0.0;
      this->state_code = 0l;
    }
  }

  explicit DragTeachRecord_Result_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc),
    name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
      this->name = "";
      this->total_time = 0.0;
      this->state_code = 0l;
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _total_time_type =
    double;
  _total_time_type total_time;
  using _state_code_type =
    int32_t;
  _state_code_type state_code;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__total_time(
    const double & _arg)
  {
    this->total_time = _arg;
    return *this;
  }
  Type & set__state_code(
    const int32_t & _arg)
  {
    this->state_code = _arg;
    return *this;
  }

  // constant declarations
  static constexpr unsigned char SUCCESS =
    0;
  static constexpr unsigned char ROBOT_CONTROL_STATE_EXCEPTION =
    1;
  static constexpr unsigned char FILE_NAME_EXISTED =
    2;
  static constexpr unsigned char FILE_SAVE_FAILED =
    3;
  static constexpr unsigned char USER_OPERATION_EXCEPTION =
    4;

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Result
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Result
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_Result_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->total_time != other.total_time) {
      return false;
    }
    if (this->state_code != other.state_code) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_Result_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_Result_

// alias to use template instance with default allocator
using DragTeachRecord_Result =
  upperlimb_msgs::action::DragTeachRecord_Result_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char DragTeachRecord_Result_<ContainerAllocator>::SUCCESS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char DragTeachRecord_Result_<ContainerAllocator>::ROBOT_CONTROL_STATE_EXCEPTION;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char DragTeachRecord_Result_<ContainerAllocator>::FILE_NAME_EXISTED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char DragTeachRecord_Result_<ContainerAllocator>::FILE_SAVE_FAILED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr unsigned char DragTeachRecord_Result_<ContainerAllocator>::USER_OPERATION_EXCEPTION;
#endif  // __cplusplus < 201703L

}  // namespace action

}  // namespace upperlimb_msgs


#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Feedback __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Feedback __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_Feedback_
{
  using Type = DragTeachRecord_Feedback_<ContainerAllocator>;

  explicit DragTeachRecord_Feedback_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->total_time = 0.0;
    }
  }

  explicit DragTeachRecord_Feedback_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->total_time = 0.0;
    }
  }

  // field types and members
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _total_time_type =
    double;
  _total_time_type total_time;

  // setters for named parameter idiom
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__total_time(
    const double & _arg)
  {
    this->total_time = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Feedback
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_Feedback
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_Feedback_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    if (this->total_time != other.total_time) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_Feedback_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_Feedback_

// alias to use template instance with default allocator
using DragTeachRecord_Feedback =
  upperlimb_msgs::action::DragTeachRecord_Feedback_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace upperlimb_msgs


// Include directives for member types
// Member 'goal_id'
#include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"
// Member 'goal'
#include "upperlimb_msgs/action/detail/drag_teach_record__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Request __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Request __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_SendGoal_Request_
{
  using Type = DragTeachRecord_SendGoal_Request_<ContainerAllocator>;

  explicit DragTeachRecord_SendGoal_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_init),
    goal(_init)
  {
    (void)_init;
  }

  explicit DragTeachRecord_SendGoal_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_alloc, _init),
    goal(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _goal_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _goal_id_type goal_id;
  using _goal_type =
    upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator>;
  _goal_type goal;

  // setters for named parameter idiom
  Type & set__goal_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->goal_id = _arg;
    return *this;
  }
  Type & set__goal(
    const upperlimb_msgs::action::DragTeachRecord_Goal_<ContainerAllocator> & _arg)
  {
    this->goal = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Request
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Request
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_SendGoal_Request_ & other) const
  {
    if (this->goal_id != other.goal_id) {
      return false;
    }
    if (this->goal != other.goal) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_SendGoal_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_SendGoal_Request_

// alias to use template instance with default allocator
using DragTeachRecord_SendGoal_Request =
  upperlimb_msgs::action::DragTeachRecord_SendGoal_Request_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace upperlimb_msgs


// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Response __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Response __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_SendGoal_Response_
{
  using Type = DragTeachRecord_SendGoal_Response_<ContainerAllocator>;

  explicit DragTeachRecord_SendGoal_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accepted = false;
    }
  }

  explicit DragTeachRecord_SendGoal_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accepted = false;
    }
  }

  // field types and members
  using _accepted_type =
    bool;
  _accepted_type accepted;
  using _stamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _stamp_type stamp;

  // setters for named parameter idiom
  Type & set__accepted(
    const bool & _arg)
  {
    this->accepted = _arg;
    return *this;
  }
  Type & set__stamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->stamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Response
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_SendGoal_Response
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_SendGoal_Response_ & other) const
  {
    if (this->accepted != other.accepted) {
      return false;
    }
    if (this->stamp != other.stamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_SendGoal_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_SendGoal_Response_

// alias to use template instance with default allocator
using DragTeachRecord_SendGoal_Response =
  upperlimb_msgs::action::DragTeachRecord_SendGoal_Response_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace upperlimb_msgs

namespace upperlimb_msgs
{

namespace action
{

struct DragTeachRecord_SendGoal
{
  using Request = upperlimb_msgs::action::DragTeachRecord_SendGoal_Request;
  using Response = upperlimb_msgs::action::DragTeachRecord_SendGoal_Response;
};

}  // namespace action

}  // namespace upperlimb_msgs


// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Request __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Request __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_GetResult_Request_
{
  using Type = DragTeachRecord_GetResult_Request_<ContainerAllocator>;

  explicit DragTeachRecord_GetResult_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_init)
  {
    (void)_init;
  }

  explicit DragTeachRecord_GetResult_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _goal_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _goal_id_type goal_id;

  // setters for named parameter idiom
  Type & set__goal_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->goal_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Request
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Request
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_GetResult_Request_ & other) const
  {
    if (this->goal_id != other.goal_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_GetResult_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_GetResult_Request_

// alias to use template instance with default allocator
using DragTeachRecord_GetResult_Request =
  upperlimb_msgs::action::DragTeachRecord_GetResult_Request_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace upperlimb_msgs


// Include directives for member types
// Member 'result'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_record__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Response __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Response __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_GetResult_Response_
{
  using Type = DragTeachRecord_GetResult_Response_<ContainerAllocator>;

  explicit DragTeachRecord_GetResult_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : result(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = 0;
    }
  }

  explicit DragTeachRecord_GetResult_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : result(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = 0;
    }
  }

  // field types and members
  using _status_type =
    int8_t;
  _status_type status;
  using _result_type =
    upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator>;
  _result_type result;

  // setters for named parameter idiom
  Type & set__status(
    const int8_t & _arg)
  {
    this->status = _arg;
    return *this;
  }
  Type & set__result(
    const upperlimb_msgs::action::DragTeachRecord_Result_<ContainerAllocator> & _arg)
  {
    this->result = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Response
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_GetResult_Response
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_GetResult_Response_ & other) const
  {
    if (this->status != other.status) {
      return false;
    }
    if (this->result != other.result) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_GetResult_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_GetResult_Response_

// alias to use template instance with default allocator
using DragTeachRecord_GetResult_Response =
  upperlimb_msgs::action::DragTeachRecord_GetResult_Response_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace upperlimb_msgs

namespace upperlimb_msgs
{

namespace action
{

struct DragTeachRecord_GetResult
{
  using Request = upperlimb_msgs::action::DragTeachRecord_GetResult_Request;
  using Response = upperlimb_msgs::action::DragTeachRecord_GetResult_Response;
};

}  // namespace action

}  // namespace upperlimb_msgs


// Include directives for member types
// Member 'goal_id'
// already included above
// #include "unique_identifier_msgs/msg/detail/uuid__struct.hpp"
// Member 'feedback'
// already included above
// #include "upperlimb_msgs/action/detail/drag_teach_record__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_FeedbackMessage __attribute__((deprecated))
#else
# define DEPRECATED__upperlimb_msgs__action__DragTeachRecord_FeedbackMessage __declspec(deprecated)
#endif

namespace upperlimb_msgs
{

namespace action
{

// message struct
template<class ContainerAllocator>
struct DragTeachRecord_FeedbackMessage_
{
  using Type = DragTeachRecord_FeedbackMessage_<ContainerAllocator>;

  explicit DragTeachRecord_FeedbackMessage_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_init),
    feedback(_init)
  {
    (void)_init;
  }

  explicit DragTeachRecord_FeedbackMessage_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : goal_id(_alloc, _init),
    feedback(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _goal_id_type =
    unique_identifier_msgs::msg::UUID_<ContainerAllocator>;
  _goal_id_type goal_id;
  using _feedback_type =
    upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator>;
  _feedback_type feedback;

  // setters for named parameter idiom
  Type & set__goal_id(
    const unique_identifier_msgs::msg::UUID_<ContainerAllocator> & _arg)
  {
    this->goal_id = _arg;
    return *this;
  }
  Type & set__feedback(
    const upperlimb_msgs::action::DragTeachRecord_Feedback_<ContainerAllocator> & _arg)
  {
    this->feedback = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator> *;
  using ConstRawPtr =
    const upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_FeedbackMessage
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__upperlimb_msgs__action__DragTeachRecord_FeedbackMessage
    std::shared_ptr<upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DragTeachRecord_FeedbackMessage_ & other) const
  {
    if (this->goal_id != other.goal_id) {
      return false;
    }
    if (this->feedback != other.feedback) {
      return false;
    }
    return true;
  }
  bool operator!=(const DragTeachRecord_FeedbackMessage_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DragTeachRecord_FeedbackMessage_

// alias to use template instance with default allocator
using DragTeachRecord_FeedbackMessage =
  upperlimb_msgs::action::DragTeachRecord_FeedbackMessage_<std::allocator<void>>;

// constant definitions

}  // namespace action

}  // namespace upperlimb_msgs

#include "action_msgs/srv/cancel_goal.hpp"
#include "action_msgs/msg/goal_info.hpp"
#include "action_msgs/msg/goal_status_array.hpp"

namespace upperlimb_msgs
{

namespace action
{

struct DragTeachRecord
{
  /// The goal message defined in the action definition.
  using Goal = upperlimb_msgs::action::DragTeachRecord_Goal;
  /// The result message defined in the action definition.
  using Result = upperlimb_msgs::action::DragTeachRecord_Result;
  /// The feedback message defined in the action definition.
  using Feedback = upperlimb_msgs::action::DragTeachRecord_Feedback;

  struct Impl
  {
    /// The send_goal service using a wrapped version of the goal message as a request.
    using SendGoalService = upperlimb_msgs::action::DragTeachRecord_SendGoal;
    /// The get_result service using a wrapped version of the result message as a response.
    using GetResultService = upperlimb_msgs::action::DragTeachRecord_GetResult;
    /// The feedback message with generic fields which wraps the feedback message.
    using FeedbackMessage = upperlimb_msgs::action::DragTeachRecord_FeedbackMessage;

    /// The generic service to cancel a goal.
    using CancelGoalService = action_msgs::srv::CancelGoal;
    /// The generic message for the status of a goal.
    using GoalStatusMessage = action_msgs::msg::GoalStatusArray;
  };
};

typedef struct DragTeachRecord DragTeachRecord;

}  // namespace action

}  // namespace upperlimb_msgs

#endif  // UPPERLIMB_MSGS__ACTION__DETAIL__DRAG_TEACH_RECORD__STRUCT_HPP_
