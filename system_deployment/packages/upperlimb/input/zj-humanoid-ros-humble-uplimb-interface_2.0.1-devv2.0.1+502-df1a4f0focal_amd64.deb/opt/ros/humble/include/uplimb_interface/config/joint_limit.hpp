#pragma once

#include <yaml-cpp/yaml.h>

#include <cmath>
#include <exception>
#include <filesystem>
#include <optional>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace zj_humanoid::upperlimb::config
{
    struct RangeLimit
    {
        double min = 0.0;
        double max = 0.0;

        RangeLimit() = default;

        RangeLimit(const double min, const double max) : min(min), max(max)
        {
            if (!std::isfinite(min) || !std::isfinite(max) || min > max)
            {
                throw std::invalid_argument("Invalid range");
            }
        }
    };

    struct DynamicLimit
    {
        RangeLimit               envelope{};  // Lua 计算前先检查的绝对安全范围
        std::string              scriptId;
        std::vector<std::string> params;
    };

    struct AlgoLimit
    {
        std::optional<RangeLimit>   range;
        std::optional<DynamicLimit> dynamicLimit;

        AlgoLimit() : AlgoLimit(RangeLimit{})
        {
        }

        explicit AlgoLimit(RangeLimit range)
            : AlgoLimit(std::optional<RangeLimit>{std::move(range)}, std::nullopt)
        {
        }

        explicit AlgoLimit(DynamicLimit dynamicLimit)
            : AlgoLimit(std::nullopt, std::optional<DynamicLimit>{std::move(dynamicLimit)})
        {
        }

        AlgoLimit(std::optional<RangeLimit> range, std::optional<DynamicLimit> dynamicLimit)
            : range(std::move(range)), dynamicLimit(std::move(dynamicLimit))
        {
            if (this->range.has_value() == this->dynamicLimit.has_value())
            {
                throw std::invalid_argument("AlgoLimit must contain exactly one of range or dynamicLimit");
            }
            if (this->dynamicLimit.has_value() && this->dynamicLimit->scriptId.empty())
            {
                throw std::invalid_argument("Dynamic AlgoLimit scriptId must not be empty");
            }
        }
    };

    struct JointLimit
    {
        RangeLimit hw;
        AlgoLimit  algo;
        RangeLimit sdk;
        RangeLimit servo;

        JointLimit()
            : JointLimit(RangeLimit{-3.0, 3.0}, AlgoLimit{}, RangeLimit{-1.0, 1.0}, RangeLimit{-2.0, 2.0})
        {
        }

        JointLimit(RangeLimit hw, AlgoLimit algo, RangeLimit sdk, RangeLimit servo)
            : hw(std::move(hw)), algo(std::move(algo)), sdk(std::move(sdk)), servo(std::move(servo))
        {
        }
    };

    struct ZeroConfig
    {
        double position;
        double offset;
        double maxOffset;
        double minOffset;
    };

    struct ScriptConfig
    {
        std::string name;
        std::string content;

        ScriptConfig() = default;
        ScriptConfig(std::string name, std::string content);
    };

    struct JointConfig
    {
        std::string name;
        std::string urdfName;
        JointLimit  limit;
        ZeroConfig  zero;
        bool        is_lifting = false;  // 由 name 包含 "lifting" 自动推导，不来自 YAML

        JointConfig()
            : JointConfig("unknown", "unknown", JointLimit{}, ZeroConfig{})
        {
        }

        JointConfig(std::string name, std::string urdfName, JointLimit limit, ZeroConfig zero)
            : name(std::move(name)), urdfName(std::move(urdfName)), limit(std::move(limit)), zero(std::move(zero))
        {
            if (this->name.empty() || this->urdfName.empty())
            {
                throw std::invalid_argument("JointConfig name and urdfName must not be empty");
            }
            // Note 当关节名称是lift的时候，is_lifting为true，表示该关节是升降关节， 该升降关节不check min limit, 只check max limit
            this->is_lifting = this->name.find("lift") != std::string::npos;
        }
    };

    struct HardwareBodyConfig
    {
        std::string               model;
        std::string               version;
        std::vector<ScriptConfig> scripts;
        std::vector<JointConfig>  joints;

        static inline HardwareBodyConfig from_yaml(const std::filesystem::path& path)
        {
            const std::string file_path = path.string();
            try
            {
                const YAML::Node root = YAML::LoadFile(file_path);
                HardwareBodyConfig config = root.as<HardwareBodyConfig>();
                config.validate();
                return config;
            }
            catch (const std::exception& error)
            {
                throw std::runtime_error("Failed to parse `" + file_path + "`: " + error.what());
            }
        }

        void validate() const;

        const ScriptConfig* find_script_by_name(const std::string& name) const
        {
            for (const auto& script : scripts)
            {
                if (script.name == name)
                {
                    return &script;
                }
            }
            return nullptr;
        }
    };

    namespace detail
    {
        inline YAML::Node require_node(const YAML::Node& node, const char* key, const char* owner)
        {
            const YAML::Node child = node[key];
            if (!child)
            {
                throw std::runtime_error(std::string("Missing required field `") + owner + "." + key + "`");
            }
            return child;
        }
    }  // namespace detail
}  // namespace zj_humanoid::upperlimb::config

namespace YAML
{
    namespace config_detail = ::zj_humanoid::upperlimb::config::detail;

    template <>
    struct convert<::zj_humanoid::upperlimb::config::RangeLimit>
    {
        using RangeLimit = ::zj_humanoid::upperlimb::config::RangeLimit;

        static bool decode(const Node& node, RangeLimit& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }
            rhs = RangeLimit{
                config_detail::require_node(node, "min", "RangeLimit").as<double>(),
                config_detail::require_node(node, "max", "RangeLimit").as<double>(),
            };
            return true;
        }
    };

    template <>
    struct convert<::zj_humanoid::upperlimb::config::DynamicLimit>
    {
        using DynamicLimit = ::zj_humanoid::upperlimb::config::DynamicLimit;

        static bool decode(const Node& node, DynamicLimit& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }
            rhs.scriptId = config_detail::require_node(node, "scriptId", "DynamicLimit").as<std::string>();
            rhs.params   = config_detail::require_node(node, "params", "DynamicLimit").as<std::vector<std::string>>();
            return true;
        }
    };

    template <>
    struct convert<::zj_humanoid::upperlimb::config::AlgoLimit>
    {
        using AlgoLimit    = ::zj_humanoid::upperlimb::config::AlgoLimit;
        using DynamicLimit = ::zj_humanoid::upperlimb::config::DynamicLimit;
        using RangeLimit   = ::zj_humanoid::upperlimb::config::RangeLimit;

        static bool decode(const Node& node, AlgoLimit& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }

            std::optional<RangeLimit>   range;
            std::optional<DynamicLimit> dynamicLimit;

            if (node["min"] || node["max"])
            {
                range = RangeLimit{
                    config_detail::require_node(node, "min", "AlgoLimit").as<double>(),
                    config_detail::require_node(node, "max", "AlgoLimit").as<double>(),
                };
            }

            if (node["dynamic"] || node["envelope"])
            {
                DynamicLimit parsedDynamicLimit = config_detail::require_node(node, "dynamic", "AlgoLimit").as<DynamicLimit>();
                parsedDynamicLimit.envelope     = config_detail::require_node(node, "envelope", "AlgoLimit").as<RangeLimit>();
                dynamicLimit                    = std::move(parsedDynamicLimit);
            }

            rhs = AlgoLimit{std::move(range), std::move(dynamicLimit)};
            return true;
        }
    };

    template <>
    struct convert<::zj_humanoid::upperlimb::config::JointLimit>
    {
        using JointLimit = ::zj_humanoid::upperlimb::config::JointLimit;

        static bool decode(const Node& node, JointLimit& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }
            rhs = JointLimit{
                config_detail::require_node(node, "hw", "JointLimit").as<::zj_humanoid::upperlimb::config::RangeLimit>(),
                config_detail::require_node(node, "algo", "JointLimit").as<::zj_humanoid::upperlimb::config::AlgoLimit>(),
                config_detail::require_node(node, "sdk", "JointLimit").as<::zj_humanoid::upperlimb::config::RangeLimit>(),
                config_detail::require_node(node, "servo", "JointLimit").as<::zj_humanoid::upperlimb::config::RangeLimit>(),
            };
            return true;
        }
    };

    template <>
    struct convert<::zj_humanoid::upperlimb::config::ZeroConfig>
    {
        using ZeroConfig = ::zj_humanoid::upperlimb::config::ZeroConfig;

        static bool decode(const Node& node, ZeroConfig& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }
            rhs.position  = config_detail::require_node(node, "position", "ZeroConfig").as<double>();
            rhs.offset    = config_detail::require_node(node, "offset", "ZeroConfig").as<double>();
            rhs.maxOffset = config_detail::require_node(node, "maxOffset", "ZeroConfig").as<double>();
            rhs.minOffset = config_detail::require_node(node, "minOffset", "ZeroConfig").as<double>();
            return true;
        }
    };

    template <>
    struct convert<::zj_humanoid::upperlimb::config::ScriptConfig>
    {
        using ScriptConfig = ::zj_humanoid::upperlimb::config::ScriptConfig;

        static bool decode(const Node& node, ScriptConfig& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }
            rhs = ScriptConfig{
                config_detail::require_node(node, "name", "ScriptConfig").as<std::string>(),
                config_detail::require_node(node, "content", "ScriptConfig").as<std::string>(),
            };
            return true;
        }
    };

    template <>
    struct convert<::zj_humanoid::upperlimb::config::JointConfig>
    {
        using JointConfig = ::zj_humanoid::upperlimb::config::JointConfig;

        static bool decode(const Node& node, JointConfig& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }
            rhs = JointConfig{
                config_detail::require_node(node, "name", "JointConfig").as<std::string>(),
                config_detail::require_node(node, "urdfName", "JointConfig").as<std::string>(),
                config_detail::require_node(node, "limit", "JointConfig").as<::zj_humanoid::upperlimb::config::JointLimit>(),
                config_detail::require_node(node, "zero", "JointConfig").as<::zj_humanoid::upperlimb::config::ZeroConfig>(),
            };
            return true;
        }
    };

    template <>
    struct convert<::zj_humanoid::upperlimb::config::HardwareBodyConfig>
    {
        using HardwareBodyConfig = ::zj_humanoid::upperlimb::config::HardwareBodyConfig;
        using ScriptConfig       = ::zj_humanoid::upperlimb::config::ScriptConfig;

        static bool decode(const Node& node, HardwareBodyConfig& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }
            rhs.model   = config_detail::require_node(node, "model", "HardwareBodyConfig").as<std::string>();
            rhs.version = config_detail::require_node(node, "version", "HardwareBodyConfig").as<std::string>();
            const Node scripts = node["scripts"];
            rhs.scripts        = scripts ? scripts.as<std::vector<ScriptConfig>>() : std::vector<ScriptConfig>{};
            rhs.joints  = config_detail::require_node(node, "joints", "HardwareBodyConfig").as<std::vector<::zj_humanoid::upperlimb::config::JointConfig>>();
            return true;
        }
    };
}  // namespace YAML
