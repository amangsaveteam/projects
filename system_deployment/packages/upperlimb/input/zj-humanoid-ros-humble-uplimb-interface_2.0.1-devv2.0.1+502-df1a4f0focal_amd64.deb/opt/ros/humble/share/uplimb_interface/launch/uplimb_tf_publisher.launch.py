from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def _build_node(context):
    robot_name = LaunchConfiguration("robot_name").perform(context).strip()
    if not robot_name:
        raise RuntimeError("robot_name must not be empty")

    return [
        Node(
            package="uplimb_interface",
            executable="uplimb_tf_publisher_node",
            name="uplimb_tf_publisher_node",
            namespace=robot_name,
            output="screen",
            parameters=[
                {
                    "add_tf_prefix": True,
                    "tf_prefix": robot_name,
                }
            ],
        )
    ]


def generate_launch_description():
    robot_name_arg = DeclareLaunchArgument(
        "robot_name",
        default_value="zj_humanoid",
        description="Robot namespace, must match the joint_states publisher",
    )

    return LaunchDescription(
        [
            robot_name_arg,
            OpaqueFunction(function=_build_node),
        ]
    )
