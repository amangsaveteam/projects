#pragma once

#include <array>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include "uplimb_interface/controller.hpp"

namespace zj_humanoid::upperlimb::app
{
    struct MoveJRequest
    {
        std::vector<double> joints{};
        int                 mdw_arm_type{0};
        double              velocity{0.0};
        double              acceleration{0.0};
        double              time{0.0};
        bool                asynchronous{false};
    };

    struct MoveJByPathRequest
    {
        std::vector<std::vector<double>> path{};
        std::vector<double>              timestamp{};
        int                              mdw_arm_type{0};
        double                           time{0.0};
        bool                             asynchronous{false};
    };

    struct MoveJByPoseRequest
    {
        std::vector<std::array<double, 6>> pose{};
        std::vector<double>                q7{};
        int                                mdw_arm_type{0};
        double                             velocity{0.0};
        double                             acceleration{0.0};
        bool                               asynchronous{false};
    };

    struct MoveLRequest
    {
        std::vector<std::array<double, 6>> pose{};
        int                                mdw_arm_type{0};
        double                             velocity{0.0};
        double                             acceleration{0.0};
        bool                               asynchronous{false};
    };

    // TODO 在DTO中构建一个Pose结构体，包含位置和姿态 xyz ypr，, 然后对应所有的movel相关都需要使用该接口 替换std::array<double, 6> 先plan在开始修改文件
    struct MoveLByPathRequest
    {
        std::vector<std::array<double, 6>> left_arm_path{};
        std::vector<std::array<double, 6>> right_arm_path{};
        std::vector<double>                timestamp{};
        int                                mdw_arm_type{0};
        double                             time{0.0};
        double                             velocity{0.0};
        double                             acceleration{0.0};
        bool                               asynchronous{false};
    };

    struct SpeedJRequest
    {
        std::vector<double> joint_speed{};
        int                 mdw_arm_type{0};
        double              acceleration{0.0};
        double              time{0.001};
    };

    struct SpeedLRequest
    {
        std::vector<double> tcp_speed{};
        int                 mdw_arm_type{0};
        double              acceleration{0.0};
        double              time{0.001};
    };

    struct PayloadDTO
    {
        double                mass{0.0};
        std::vector<double>   cog{0.0, 0.0, 0.0};
    };

    struct PayloadSetRequest
    {
        PayloadDTO payload{};
        int        mdw_arm_type{0};
    };

    struct HandParamsRequest
    {
        std::array<PayloadDTO, 2> hands{};
    };

    struct ControllerParamsRequest
    {
        std::vector<double> params{};
        int                 mdw_arm_type{0};
    };

    struct CartesianPlanningParamsRequest
    {
        std::vector<bool> joint_mask{};
        int               mdw_arm_type{0};
    };

    struct FKRequest
    {
        std::vector<double> joints{};
        int                 mdw_arm_type{0};
    };

    struct FKPoseDTO
    {
        int                   arm_type{0};
        std::array<double, 6> pose{};
    };

    struct FKResponseDTO
    {
        std::vector<FKPoseDTO> poses{};
    };

    struct IKRequest
    {
        CartesianPose         pose{};
        double                q7{0.0};
        std::vector<double>   q_init{};
        std::vector<double>   q_ref{};
        int                   mdw_arm_type{0};
    };

    struct IKResponseDTO
    {
        int                              nums{0};
        std::vector<std::vector<double>> joints{};
        std::vector<int>                 arm_type{};
        std::vector<double>              phi{};
    };

    struct IsSingularRequest
    {
        std::vector<double> joints{};
        int                 mdw_arm_type{0};
    };

    struct MotionInfoDTO
    {
        std::string         filename{};
        std::string         alias{};
        int                 arm_type{0};
        std::vector<double> joints{};
        long                number{0};
    };

    struct MotionManageRequest
    {
        std::string folder{};
        std::string filename{};
        std::string alias{};
    };

    struct MotionExecuteFeedbackDTO
    {
        std::string name{};
        int         progress{0};
    };

    struct MotionExecutionStateDTO
    {
        std::string name{};
        int         step{0};
        bool        moving{false};
    };

    struct ActionResultDTO
    {
        bool        success{false};
        std::string message{};
        int         state_code{0};
        std::string name{};
        double      total_time{0.0};
    };

    using MotionExecuteFeedbackCallback = std::function<void(const MotionExecuteFeedbackDTO&)>;
    using ActionCancelCallback          = std::function<bool()>;

    struct TeachFileRequest
    {
        std::string folder{};
        std::string name{};
    };

    struct TeachFileDataDTO
    {
        std::vector<double>              timestamp{};
        std::vector<std::vector<double>> joints{};
        int                              record_frequency{50};
    };

    struct TeachWriteFileRequest
    {
        std::string                      folder{};
        std::string                      name{};
        std::string                      robot_name{};
        int                              record_frequency{50};
        std::vector<double>              timestamp{};
        std::vector<std::vector<double>> joints{};
    };

    struct TeachRecordRequest
    {
        std::string folder{};
        std::string name{};
        std::string robot_name{};
        int         record_frequency{50};
        int         record_max_time{180};
    };

    struct TeachRecordFeedbackDTO
    {
        std::string name{};
        double      total_time{0.0};
    };

    using TeachRecordFeedbackCallback = std::function<void(const TeachRecordFeedbackDTO&)>;

    struct TeachReplayRequest
    {
        std::string folder{};
        std::string name{};
        double      velocity{0.0};
        double      acceleration{0.0};
        double      time{0.0};
        double      start_time{0.0};
        double      end_time{0.0};
    };

    struct ServoJRequest
    {
        std::vector<double> joints{};
        int                 mdw_arm_type{0};
        double              velocity{0.0};
        double              acceleration{0.0};
        double              time{0.0};
        double              lookahead_time{0.0};
        int                 gain{0};
    };

    struct ServoLRequest
    {
        std::vector<std::array<double, 6>> pose{};
        int                                mdw_arm_type{0};
        double                             velocity{0.0};
        double                             acceleration{0.0};
        double                             time{0.0};
        double                             lookahead_time{0.0};
        int                                gain{0};
    };

    struct ExternalTorqueDTO
    {
        std::vector<std::string> joint_names{};
        std::vector<double>      effort{};
    };

    struct WaistForceExtDTO
    {
        std::array<double, 6> force_ext{};
    };

    struct PublishJointStateDTO
    {
        std::vector<std::string> joint_names{};
        std::vector<double>      position{};
        std::vector<double>      velocity{};
        std::vector<double>      effort{};
    };

    struct PublishJointStateInput
    {
        int                      algo_mask{0};
        std::vector<std::string> algo_joint_names{};
        std::vector<double>      algo_position{};
        std::vector<double>      algo_velocity{};
        std::vector<double>      algo_effort{};
    };

    struct ArmDataSnapshotDTO
    {
        ArmVar var{};
        ArmCMD cmd{};
    };

    struct ArmTcpPoseDTO
    {
        std::array<double, 6> left_arm{};
        std::array<double, 6> right_arm{};
    };

    struct TcpSpeedDTO
    {
        std::array<double, 6> left_arm{};
        std::array<double, 6> right_arm{};
    };

    struct RobotCmdStateDTO
    {
        int         cmd_num{0};
        std::string cmd_name{"Unknown"};
        bool        left_arm_is_singular{false};
        bool        right_arm_is_singular{false};
        bool        iddp_status{false};
    };

    struct MatrixDTO
    {
        int                 rows{0};
        int                 cols{0};
        std::vector<double> data{};
    };

    struct JacobianMatricesDTO
    {
        MatrixDTO left_arm{};
        MatrixDTO right_arm{};
    };

    struct ServoSessionState
    {
        bool   enabled{false};
        double velocity{0.0};
        double acceleration{0.0};
        double lookahead_time{0.0};
        double time{0.0};
        int    gain{0};
        int    mdw_arm_type{0};
        mutable std::uint64_t servoj_count{0};
        mutable std::uint64_t servol_count{0};
    };

    struct SpeedSessionState
    {
        int                   enabled{0};
        mutable std::uint64_t count{0};
    };

}  // namespace zj_humanoid::upperlimb::app
