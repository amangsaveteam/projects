#pragma once

#include <fmt/format.h>

#include "uplimb_interface/controller.hpp"

template <>
struct fmt::formatter<zj_humanoid::upperlimb::Matrix> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::Matrix& matrix, FormatContext& ctx) const
    {
        auto out = fmt::format_to(ctx.out(), "{{rows: {}, cols: {}, data: [", matrix.rows, matrix.cols);
        for (std::size_t i = 0; i < matrix.data.size(); ++i)
        {
            out = fmt::format_to(out, "{}{}", i == 0 ? "" : ", ", matrix.data[i]);
        }
        return fmt::format_to(out, "]}}");
    }
};
