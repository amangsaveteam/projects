/*
 * @Author       : Jay junjie.zhang@zj-humanoid.com
 * @Date         : 2026-03-21 11:17:53
 * @LastEditTime : 2026-04-25 13:38:02
 * @LastEditors  : Jay junjie.zhang@zj-humanoid.com
 * @Description  : Controller interface.
 */
#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <logging.hpp>
#include <memory>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "uplimb_interface/definitions.hpp"

namespace zj_humanoid::upperlimb
{

    using JointState     = std::vector<double>;
    using JointPath      = std::vector<JointState>;
    using JointSolutions = std::vector<JointPath>;

    using Pose6D              = std::array<double, 6>;
    using Point3D             = std::array<double, 3>;
    using CartesianPose       = std::vector<Pose6D>;
    using DualArmCartesianVel = std::array<Pose6D, 2>;
    using CartesianVel        = std::variant<Pose6D, DualArmCartesianVel>;

    inline constexpr std::size_t kArmMaxJointNum = 30;

    struct Matrix
    {
        int                 rows;
        int                 cols;
        std::vector<double> data;
    };

    struct ArmState
    {
        std::array<std::uint8_t, kArmMaxJointNum>  mode{};
        std::array<std::uint16_t, kArmMaxJointNum> statuswd{};
        std::array<double, kArmMaxJointNum>        act_pos{};
        std::array<double, kArmMaxJointNum>        act_vel{};
        std::array<double, kArmMaxJointNum>        act_acc{};
        std::array<double, kArmMaxJointNum>        act_tau{};
        unsigned long long int                     upTime{0};
    };

    struct ArmVar
    {
        std::array<int, kArmMaxJointNum>    var1{};
        std::array<int, kArmMaxJointNum>    var2{};
        std::array<int, kArmMaxJointNum>    var3{};
        std::array<int, kArmMaxJointNum>    var4{};
        std::array<int, kArmMaxJointNum>    var5{};
        std::array<double, kArmMaxJointNum> var6{};
        std::array<double, kArmMaxJointNum> var7{};
        std::array<double, kArmMaxJointNum> var8{};
        std::array<double, kArmMaxJointNum> var9{};
        std::array<double, kArmMaxJointNum> var10{};
    };

    struct ArmCMD
    {
        std::array<double, kArmMaxJointNum>        offset_torque{};
        std::array<double, kArmMaxJointNum>        offset_vel{};
        std::array<std::uint8_t, kArmMaxJointNum>  mode_operation{};
        std::array<std::uint16_t, kArmMaxJointNum> ctrlwd{};
        std::array<double, kArmMaxJointNum>        cmd_pos{};
        std::array<double, kArmMaxJointNum>        cmd_vel{};
        std::array<double, kArmMaxJointNum>        cmd_tau{};
        unsigned long long int                     downTime{0};
    };

    enum class ControllerType
    {
        Unknown = 0,
        V1      = 1,
        V2      = 2,
        FAKE    = 3,
        SIM     = 4,
    };

    enum class AnyDualArmType : int
    {
        LeftArm  = 1,
        RightArm = 2,
        DualArm  = 3,
    };

    enum class RobotRunMode
    {
        PT  = 4,
        CSP = 8,
        CSV,
        CST
    };

    enum class ControllerParasList
    {
        JOINT_COLLISION_THRESHOLD = 2,
        KP                        = 3,
        KD                        = 4,
        K_IMPDC,
        D_IMPDC
    };

    enum class ControllerMode
    {
        POSITION_CSP = 0,
        POSITION_CST = 1,
        IMPEDANCE    = 2,
        CUSTOM_DYNAMICS
    };

    class IController
    {
    public:
        virtual ~IController() = default;

        IController(const IController&)                = delete;
        IController& operator=(const IController&)     = delete;
        IController(IController&&) noexcept            = default;
        IController& operator=(IController&&) noexcept = default;

        static std::unique_ptr<IController> create(ControllerType type);
        static std::unique_ptr<IController> create(const std::string& type);

        virtual void init(const std::string& config_path) = 0;

        virtual bool movej_for_v_acc(const JointState& q, double speed, double acceleration, bool asynchronous, int arm_type) = 0;

        virtual bool movej_for_v_acc(const JointState& q,
                                     const std::array<double, 2>& speed,
                                     const std::array<double, 2>& acceleration,
                                     bool asynchronous,
                                     int arm_type) = 0;

        virtual bool movej_for_t(const JointState& q, double freq, bool asynchronous, int arm_type) = 0;

        virtual bool movej_for_qd(const JointState& q, const JointState& qd, double freq, bool asynchronous, int arm_type) = 0;

        virtual bool movej_by_path_for_total_time(const std::vector<std::vector<double>>& path, const double& time, bool asynchronous, int arm_type) = 0;

        virtual bool movej_by_path_for_timestamp(const std::vector<std::vector<double>>& path,
                                                 const std::vector<double>&              time,
                                                 bool                                    asynchronous,
                                                 int                                     arm_type) = 0;

        virtual int movej_by_pose(const CartesianPose& pose, double speed, double acceleration, bool asynchronous, int arm_type) = 0;

        virtual bool movel_refq(const CartesianPose& pose, const JointState& ref_q, double speed, double acceleration, bool asynchronous) = 0;

        virtual bool movel(const CartesianPose& pose, double speed, double acceleration, bool asynchronous, int arm_type) = 0;

        virtual bool movel_by_path_for_total_time(const std::vector<std::vector<double>>& path,
                                                  const double&                           time,
                                                  const bool&                             asynchronous,
                                                  int                                     arm_type) = 0;

        virtual bool movel_by_path_for_timestamp(const std::vector<std::vector<double>>& path,
                                                 const std::vector<double>&              time,
                                                 const bool&                             asynchronous,
                                                 int                                     arm_type) = 0;

        virtual bool servoj(const JointState& q, double speed, double acceleration, double time, double lookahead_time, double gain, int arm_type) = 0;

        virtual bool servol(const CartesianPose& pose, double speed, double acceleration, double time, double lookahead_time, double gain, int arm_type) = 0;

        virtual bool speedj(const JointState& qd, double acceleration, double time, int arm_type) = 0;

        virtual bool speedl(const CartesianVel& xd, const double& acceleration, const double& time, int arm_type) = 0;

        virtual bool speedStop(double a) = 0;

        virtual bool       set_joint_mode_operation(const RobotRunMode& run_mode, int arm_type)                             = 0;
        virtual bool       set_collision_detection_state(bool enable)                                                       = 0;
        virtual bool       get_collision_detection_state() const                                                            = 0;
        virtual bool       set_cartesian_planning_joints(const JointState& mask, int arm_type)                              = 0;
        virtual bool       set_controller_para(const ControllerParasList& para_label, const JointState& para, int arm_type) = 0;
        virtual JointState get_controller_para(const ControllerParasList& para_label, int arm_type) const                   = 0;
        virtual bool       set_controller_mode(const ControllerMode& mode)                                                  = 0;

        virtual bool get_safety_lock() const                                                                  = 0;
        virtual bool release_safety_lock()                                                                    = 0;
        virtual bool set_payload(std::vector<double>& load_mass, std::vector<Point3D>& load_barycenter_trans) = 0;
        virtual bool set_hand_params(std::vector<double>& mass, std::vector<Point3D>& barycenter_trans)       = 0;

        virtual bool set_joint_position(const JointState& q, int arm_type) = 0;
        virtual bool set_joint_torque(const JointState& tau, int arm_type) = 0;
        virtual bool go_home(int arm_type)                                 = 0;

        virtual void   get_joint_position(JointState& q, int arm_type) const                     = 0;
        virtual void   get_joint_velocity(JointState& qd, int arm_type) const                    = 0;
        virtual Pose6D get_tcp_pose(int arm_type = 3) const                                      = 0;
        virtual Pose6D get_tcp_velocity(AnyDualArmType arm_type = AnyDualArmType::DualArm) const = 0;

        virtual CartesianPose FK(int arm_type = 3) const                      = 0;
        virtual CartesianPose FK(const JointState& q, int arm_type = 3) const = 0;
        virtual int           IK(const CartesianPose& pose,
                                 const JointState&    q_init,
                                 const JointState&    q_ref,
                                 JointSolutions&      q,
                                 std::vector<int>&    solution_arm_type,
                                 std::string&         message,
                                 int                  arm_type)               = 0;

        virtual void   get_jacobian_matrix(Matrix& matrix, int arm_type = 0) const                    = 0;
        virtual bool   get_jacobian_matrices(std::array<Matrix, 2>& matrices, int arm_type = 0) const = 0;
        virtual bool   get_gravity_torque(JointState& tau_g) const                                    = 0;
        virtual void   get_external_torque(JointState& tau, int arm_type) const                       = 0;
        virtual Pose6D get_waist_force_ext() const                                                    = 0;

        virtual bool                     load_trajectory(std::vector<std::vector<double>>&& data, int arm_type, const std::string& traj_name) = 0;
        virtual std::vector<std::string> get_loaded_trajectory_names() const                                                                  = 0;
        virtual void                     unload_trajectory(const std::string& traj_name)                                                      = 0;
        virtual bool                     execute_preloaded_trajectory(const std::string& traj_name, bool asynchronous)                        = 0;
        virtual bool                     get_trajectory_step(std::string& traj_name, int& trajectory_current_step) const                      = 0;

        virtual bool enable_teach_mode(int arm_type)  = 0;
        virtual bool disable_teach_mode(int arm_type) = 0;

        virtual std::size_t get_dof() const                                      = 0;
        virtual int         get_run_cmd() const                                  = 0;
        virtual void        getArmState(ArmState& state) const                   = 0;
        virtual void        getArmVar(ArmVar& var) const                         = 0;
        virtual void        getArmCMD(ArmCMD& cmd) const                         = 0;
        virtual int         is_singular(const JointState& q, int arm_type) const = 0;
        virtual int         is_singular(int arm_type) const                      = 0;

        virtual const char* get_version() const        = 0;
        virtual const char* get_detail_version() const = 0;

    protected:
        IController()
        {
            const auto root_logger = zj_humanoid::log::Logging::get_logger(kUplimbLogName);
            if (root_logger != nullptr && root_logger->is_valid() && root_logger->find_module_index(kControllerLogModuleName) != root_logger->module_count())
            {
                this->logger_ = root_logger->module(kControllerLogModuleName);
            }
        }

        mutable zj_humanoid::log::ModuleLogger logger_;
    };

}  // namespace zj_humanoid::upperlimb
