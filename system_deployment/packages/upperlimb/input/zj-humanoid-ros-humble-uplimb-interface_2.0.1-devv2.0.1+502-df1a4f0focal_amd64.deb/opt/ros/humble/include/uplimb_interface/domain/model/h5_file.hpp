#pragma once

#include <string>
#include <vector>

#include "uplimb_interface/domain/model/path.hpp"
#include "uplimb_interface/domain/model/result.hpp"

namespace zj_humanoid::upperlimb::domain
{
    class H5File : public Path
    {
    public:
        explicit H5File(const std::string& file_path);
        virtual ~H5File() = default;

        const Path& path() const;

        DomainResult<bool>                             dataset_exists(const std::string& dataset) const;
        DomainResult<bool>                             attribute_exists(const std::string& name) const;
        DomainResult<std::vector<std::vector<double>>> read_double_dataset(const std::string& dataset) const;
        DomainResult<std::string>                      read_string_attribute(const std::string& name) const;
        DomainResultVoid                               write_string_attribute(const std::string& name, const std::string& value) const;
        DomainResultVoid                               write_dataset(const std::string& dataset, const std::vector<double>& data) const;
        DomainResultVoid                               write_dataset(const std::string& dataset, const std::vector<std::vector<double>>& data) const;

        static const std::string file_suffix;

    };

}  // namespace zj_humanoid::upperlimb::domain
