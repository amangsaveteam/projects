
#ifndef FAKE_IDDP_H
#define FAKE_IDDP_H

#include <UplimbController.h>

#include <pthread.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstddef>
#include <thread>

#include "uplimb_interface/logging_helpers.hpp"

namespace Runtime
{

class FakeIddp
{
public:
    FakeIddp() = default;

    ~FakeIddp()
    {
        shutdown();
    }

    void shutdown()
    {
        stop_.store(true);
        algoStart.store(false);

        if (sim_loop_thread_.joinable())
        {
            sim_loop_thread_.join();
        }

        run.store(false);
    }

    void requestStop() { stop_.store(true); }

    // void robotIddpInit(uint8_t robot_type)
    void robotIddpInit()
    {
        init();
        auto logger = zj_humanoid::upperlimb::log_helper::module_logger(zj_humanoid::upperlimb::kRosLogModuleName);
        LOGGING_INFO(&logger, "fake robotIddpInit");

        if (sim_loop_thread_.joinable())
        {
            return;
        }
        stop_.store(false);
        sim_loop_thread_ = std::thread(&FakeIddp::loop, this);

    }

    std::atomic<bool> run{false};
    std::atomic<bool> algoStart{false};

private:
    void loop()
    {
        pthread_setname_np(pthread_self(), "uplimbFakeIddpL");
        run.store(true);
        const auto period = std::chrono::microseconds(1000000 / this->DEFAULT_ALGO_LOOP_T_);
        auto       next   = std::chrono::steady_clock::now();
        const auto dof         = getDof();
        const auto joint_count = std::min(dof, static_cast<std::size_t>(UPLIMB_ALG_JOINT_MAX_NUM));
        while (!stop_.load())
        {
            if (algoStart.load())
            {
                getDriverInfo(&this->upload_data_);
                sendDriverInfo(&this->download_data_);
            }

            // HACK: 将算法计算出来的数据直接反馈出去,模拟一个闭环
            std::copy_n(this->download_data_.cmd_pos, joint_count, this->upload_data_.act_pos);
            next += period;
            std::this_thread::sleep_until(next);
        }
        run.store(false);
    }


    std::thread sim_loop_thread_;
    std::atomic<bool> stop_{false};
    const int DEFAULT_ALGO_LOOP_T_ = 1000;
    UPLIMB_INPUT_INFO_STRUCT upload_data_ = {};
    UPLIMB_OUTPUT_INFO_STRUCT download_data_ = {};
};

} // namespace Runtime

#endif /* FAKE_IDDP_H */
