#pragma once

#include "uplimb_interface/result.hpp"

namespace zj_humanoid::upperlimb::domain
{
    template <typename T>
    using DomainResult = Result<T>;

    using DomainResultVoid = Status;

}  // namespace zj_humanoid::upperlimb::domain
