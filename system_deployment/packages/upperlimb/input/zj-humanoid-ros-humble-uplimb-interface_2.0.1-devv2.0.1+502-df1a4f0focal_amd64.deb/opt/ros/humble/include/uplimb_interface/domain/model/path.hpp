#pragma once

#include <filesystem>
#include <string>
#include <vector>

#include "uplimb_interface/domain/model/result.hpp"

namespace zj_humanoid::upperlimb::domain
{
    class Path
    {
    public:
        explicit Path(const std::string& path);

        DomainResultVoid touch(bool exist_ok = false, bool parents = false) const;
        DomainResultVoid mkdir(bool parents = false, bool exist_ok = false) const;
        DomainResultVoid chown(const std::string& username = "nav01") const;
        DomainResult<std::vector<Path>> glob(const std::string& pattern) const;
        DomainResult<std::vector<Path>> rglob(const std::string& pattern) const;

        bool exists() const;
        bool is_file() const;
        bool is_dir() const;

        Path        parent() const;
        std::string name() const;
        std::string stem() const;
        std::string suffix() const;
        std::string string() const;

    private:
        std::filesystem::path path_{};
    };

}  // namespace zj_humanoid::upperlimb::domain
