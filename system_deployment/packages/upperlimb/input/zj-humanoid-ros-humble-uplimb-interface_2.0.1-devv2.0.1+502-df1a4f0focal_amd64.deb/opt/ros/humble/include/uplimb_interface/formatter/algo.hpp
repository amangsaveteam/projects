#pragma once

#include <fmt/format.h>
#include <fmt/ranges.h>

#include "uplimb_interface/config/alog.hpp"

template <>
struct fmt::formatter<zj_humanoid::upperlimb::config::LimitConfig> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::config::LimitConfig& config, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "{{max: {:.6f}, min: {:.6f}}}", config.max, config.min);
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::config::AlgoJointConfig> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::config::AlgoJointConfig& config, FormatContext& ctx) const
    {
        const std::string limits = config.limits.has_value() ? fmt::format("{}", config.limits.value()) : "null";
        return fmt::format_to(
            ctx.out(),
            "{{name: \"{}\", algo_index: {}, home_pos: {:.6f}, limits: {}}}",
            config.name,
            config.algo_index,
            config.home_pos,
            limits);
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::config::ControllerParaConfig> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::config::ControllerParaConfig& config, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "{{joint_collision_threshold: [{}]}}", fmt::join(config.joint_collision_threshold, ", "));
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::config::AlgoConfig> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::config::AlgoConfig& config, FormatContext& ctx) const
    {
        auto out = fmt::format_to(
            ctx.out(),
            "{{define_path: \"{}\", robot_name: \"{}\", urdf_file: \"{}\", collision_detection_on: {}, total_joint_num: {}, joint_collision_threshold: [{}], joints_list: [",
            config.define_path,
            config.robot_name,
            config.urdf_file,
            config.collision_detection_on,
            config.total_joint_num,
            fmt::join(config.joint_collision_threshold, ", "));

        for (std::size_t i = 0; i < config.joints_list.size(); ++i)
        {
            out = fmt::format_to(out, "{}{}", i == 0 ? "" : ", ", config.joints_list[i]);
        }

        return fmt::format_to(out, "]}}");
    }
};
