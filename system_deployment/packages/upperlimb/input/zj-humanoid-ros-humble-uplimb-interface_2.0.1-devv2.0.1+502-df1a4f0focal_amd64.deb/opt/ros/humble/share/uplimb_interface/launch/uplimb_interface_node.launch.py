import os
import shlex

import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


DEFAULT_PARAMS_FILE = "ros2.yaml"


def _default_params_file():
    return os.path.join(
        get_package_share_directory("uplimb_interface"),
        "config",
        DEFAULT_PARAMS_FILE,
    )


def _load_ros_parameters(params_file):
    if not os.path.isfile(params_file):
        raise RuntimeError(f"params_file does not exist: {params_file}")

    with open(params_file, "r", encoding="utf-8") as file:
        content = yaml.safe_load(file) or {}

    if not isinstance(content, dict):
        return {}

    wildcard_params = content.get("/**", {}).get("ros__parameters")
    if isinstance(wildcard_params, dict):
        return dict(wildcard_params)

    for value in content.values():
        if isinstance(value, dict) and isinstance(value.get("ros__parameters"), dict):
            return dict(value["ros__parameters"])

    return {}


def _build_node(context):
    params_file = LaunchConfiguration("params_file").perform(context).strip()
    configured_parameters = _load_ros_parameters(params_file)

    controller_arg = LaunchConfiguration("controller").perform(context).strip()
    if not controller_arg:
        controller_arg = str(configured_parameters.get("controller", "")).strip()
    controller_lower = controller_arg.lower()
    is_fake = controller_lower == "fake"
    is_sim = controller_lower in ("sim", "simulation")
    is_v1 = controller_lower in ("v1", "real")
    if is_fake:
        executable = "uplimb_interface_fake_node"
    elif is_sim:
        executable = "uplimb_interface_sim_node"
    elif is_v1:
        executable = "uplimb_interface_node"
    else:
        raise RuntimeError(
            f"Unsupported controller: {controller_arg}. Expected fake, sim, simulation, v1, or real."
        )
    gdb = LaunchConfiguration("gdb").perform(context).strip()
    prefix = ["gdb -ex run --args"] if gdb in ("true", "True", "1") else None
    runtime_controller = "FAKE" if is_fake else "SIM" if is_sim else "V1"
    runtime_robot_name = (
        "fake" if is_sim else LaunchConfiguration("robot_name").perform(context).strip()
    )
    runtime_robot_type = LaunchConfiguration("robot_type").perform(context).strip()
    runtime_log_dir = LaunchConfiguration("log_dir").perform(context).strip()

    if runtime_robot_name:
        parameter_overrides = {"robot_name": runtime_robot_name}
    else:
        parameter_overrides = {}
    if runtime_robot_type:
        parameter_overrides["robot_type"] = runtime_robot_type
    if runtime_log_dir:
        parameter_overrides["log_dir"] = runtime_log_dir
    parameter_overrides["controller"] = runtime_controller
    parameter_overrides["zmq_plot_endpoint"] = "tcp://*:9874" if is_sim else "tcp://*:9873"

    node_namespace = parameter_overrides.get(
        "robot_name", configured_parameters.get("robot_name", "")
    )
    if not node_namespace:
        raise RuntimeError("robot_name must be provided by robot_name arg or params_file")

    node_args = shlex.split(LaunchConfiguration("node_args").perform(context))

    print(f"Using params_file: {params_file}")
    print(f"Using parameter overrides: {parameter_overrides}")
    print(
        f"Using executable: {executable} (controller={controller_arg}, runtime_controller={runtime_controller})"
    )

    return [
        Node(
            package="uplimb_interface",
            executable=executable,
            name="upperlimb",
            output="screen",
            emulate_tty=True,
            additional_env={"RCUTILS_COLORIZED_OUTPUT": "1"},
            prefix=prefix,
            arguments=node_args,
            namespace=node_namespace,
            parameters=[params_file, parameter_overrides],
        )
    ]


def generate_launch_description():
    # Legacy LifecycleNode launch example retained for reference:
    # from launch_ros.actions import LifecycleNode
    # lifecycle_node = LifecycleNode(
    #     package='uplimb_interface',
    #     executable='uplimb_interface_node',
    #     name='uplimb_interface_node',
    #     output='screen',
    # )
    # return LaunchDescription([lifecycle_node])
    #
    # Legacy multi-threaded component container example retained for reference:
    # from launch_ros.actions import ComposableNodeContainer
    # from launch_ros.descriptions import ComposableNode
    # mt_container = ComposableNodeContainer(
    #     name='uplimb_container',
    #     namespace='',
    #     package='rclcpp_components',
    #     executable='component_container_mt',
    #     output='screen',
    #     composable_node_descriptions=[
    #         ComposableNode(
    #             package='uplimb_interface',
    #             plugin='zj_humanoid::upperlimb::UplimbInterfaceWrapper',
    #             name='uplimb_interface_node',
    #         )
    #     ],
    # )
    # return LaunchDescription([mt_container])
    #
    robot_name_arg = DeclareLaunchArgument("robot_name", default_value="zj_humanoid")
    robot_type_arg = DeclareLaunchArgument(
        "robot_type", default_value=os.environ.get("ROBOT_TYPE", "")
    )
    params_file_arg = DeclareLaunchArgument(
        "params_file",
        default_value=_default_params_file(),
        description="ROS2 parameters yaml file",
    )
    node_args_arg = DeclareLaunchArgument("node_args", default_value="")
    controller_arg = DeclareLaunchArgument(
        "controller",
        default_value=os.environ.get("CONTROLLER", ""),
        description="Controller: fake/sim/v1",
    )
    log_dir_arg = DeclareLaunchArgument(
        "log_dir",
        default_value=os.environ.get("UPLIMB_LOG_PDIR", "/home/nav01/zj_humanoid"),
        description="upperlimb compressed log parent directory",
    )
    gdb_arg = DeclareLaunchArgument(
        "gdb", default_value="false", description="Run node under gdb: true/false"
    )

    return LaunchDescription(
        [
            robot_name_arg,
            robot_type_arg,
            params_file_arg,
            node_args_arg,
            controller_arg,
            log_dir_arg,
            gdb_arg,
            OpaqueFunction(function=_build_node),
        ]
    )
