#pragma once

#include <array>
#include <map>
#include <nlohmann/json.hpp>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <toml++/toml.hpp>
#include <type_traits>
#include <utility>
#include <vector>
#include <visit_struct/visit_struct.hpp>

#include "uplimb_interface/config/params.hpp"

VISITABLE_STRUCT(zj_humanoid::upperlimb::config::ROSParamsDTO::HandLinkSideDTO, hand_model, enable, mass_kg, cog_m);
VISITABLE_STRUCT(zj_humanoid::upperlimb::config::ROSParamsDTO::HandLinksDTO, left, right);
VISITABLE_STRUCT(zj_humanoid::upperlimb::config::ROSParamsDTO::PayloadSideDTO, mass_kg, cog_m);
VISITABLE_STRUCT(zj_humanoid::upperlimb::config::ROSParamsDTO::DefaultPayloadsDTO, left_arm, right_arm);
VISITABLE_STRUCT(zj_humanoid::upperlimb::config::ROSParamsDTO,
                 robot_name,
                 robot_type,
                 controller,
                 pub_frequency,
                 log_level,
                 log_dir,
                 zmq_plot,
                 zmq_plot_endpoint,
                 collision_detection,
                 motions_folder,
                 drag_teach_folder,
                 record_frequency,
                 record_max_time,
                 hand_links,
                 default_payloads);

namespace zj_humanoid::upperlimb::config::meta
{
    struct ParamMeta
    {
        std::string                type;
        nlohmann::json             default_value;
        std::string                description;
        bool                       read_only{false};
        std::optional<double>      minimum;
        std::optional<double>      maximum;
        std::optional<std::string> item_type;
        std::optional<std::size_t> array_size;
        std::vector<std::string>   valid_values;
        std::string                unit;
        std::string                example;
    };

    NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE_WITH_DEFAULT(ParamMeta,
                                                    type,
                                                    default_value,
                                                    description,
                                                    read_only,
                                                    minimum,
                                                    maximum,
                                                    item_type,
                                                    array_size,
                                                    valid_values,
                                                    unit,
                                                    example)

    using ParamsMetadata = std::map<std::string, ParamMeta>;

    inline ParamsMetadata from_toml(const std::string& toml_path)
    {
        try
        {
            const toml::table metadata_table = toml::parse_file(toml_path);

            std::stringstream metadata_stream;
            metadata_stream << toml::json_formatter{metadata_table};

            const nlohmann::json metadata_json = nlohmann::json::parse(metadata_stream.str());

            ParamsMetadata metadata;
            for (const auto& item : metadata_json.items())
            {
                metadata.emplace(item.key(), item.value().get<ParamMeta>());
            }
            return metadata;
        }
        catch (const std::exception& e)
        {
            throw std::runtime_error("from_toml failed. path: " + toml_path + ", error: " + std::string(e.what()));
        }
    }

    namespace detail
    {
        inline std::string join_param_path(const std::string& prefix, const char* field_name)
        {
            return prefix.empty() ? std::string(field_name) : prefix + "." + field_name;
        }

        template <typename T>
        using CleanType = std::decay_t<T>;

        template <typename T>
        constexpr bool is_visitable_v = visit_struct::traits::is_visitable<CleanType<T>>::value;

        template <typename T, typename Visitor>
        bool for_each_leaf(const std::string& path, T& value, Visitor&& visitor)
        {
            if constexpr (is_visitable_v<T>)
            {
                bool ok = true;
                visit_struct::for_each(
                    value, [&](const char* field_name, auto& field) { ok = for_each_leaf(join_param_path(path, field_name), field, visitor) && ok; });
                return ok;
            }
            else
            {
                return visitor(path, value);
            }
        }
    }  // namespace detail

    template <typename Visitor>
    bool for_each_ros_param(ROSParamsDTO& params, Visitor&& visitor)
    {
        return detail::for_each_leaf("", params, std::forward<Visitor>(visitor));
    }
}  // namespace zj_humanoid::upperlimb::config::meta
