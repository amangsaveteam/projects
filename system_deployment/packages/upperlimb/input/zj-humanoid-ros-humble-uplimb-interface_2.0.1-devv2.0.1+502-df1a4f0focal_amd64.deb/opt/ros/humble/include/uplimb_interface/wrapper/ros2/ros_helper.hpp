/*
 * @Author       : Jay junjie.zhang@zj-humanoid.com
 * @Date         : 2026-03-30 13:39:12
 * @LastEditTime : 2026-03-30 13:45:23
 * @LastEditors  : Jay junjie.zhang@zj-humanoid.com
 * @Description  : 
 */
#pragma once

#include <array>
#include <cmath>
#include <string>

#include <fmt/format.h>

#include <geometry_msgs/msg/pose.hpp>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/float64_multi_array.hpp>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2/LinearMath/Quaternion.h>

#include "uplimb_interface/app/dto.hpp"


/**
 * @brief 将一个 `geometry_msgs::msg::Pose` 转换为包含位置和欧拉角(yaw, pitch, roll)的 6 维数组。
 * 
 * 
 * @param pose 输入的 `geometry_msgs::msg::Pose` 对象，包含位置和四元数方向数据。
 * @param xyzrpy 输出的 6 维数组，填充完数据后返回。
 */
inline bool pose_to_xyzypr(const geometry_msgs::msg::Pose &pose, std::array<double, 6> &xyzrpy, std::string* error_message = nullptr)
{
    const auto& q_msg = pose.orientation;
    if (!std::isfinite(q_msg.x) || !std::isfinite(q_msg.y) || !std::isfinite(q_msg.z) || !std::isfinite(q_msg.w))
    {
        if (error_message != nullptr)
        {
            *error_message =
                fmt::format("invalid quaternion: orientation contains non-finite value, x={} y={} z={} w={}", q_msg.x, q_msg.y, q_msg.z, q_msg.w);
        }
        return false;
    }

    const double norm2 = q_msg.x * q_msg.x + q_msg.y * q_msg.y + q_msg.z * q_msg.z + q_msg.w * q_msg.w;
    if (!std::isfinite(norm2) || norm2 <= 0.0)
    {
        if (error_message != nullptr)
        {
            *error_message = fmt::format(
                "invalid quaternion: orientation norm is invalid, norm2={} x={} y={} z={} w={}", norm2, q_msg.x, q_msg.y, q_msg.z, q_msg.w);
        }
        return false;
    }

    xyzrpy[0] = pose.position.x;
    xyzrpy[1] = pose.position.y;
    xyzrpy[2] = pose.position.z;

    tf2::Quaternion q_tf;
    double roll = 0.0;
    double pitch = 0.0;
    double yaw = 0.0;
    q_tf.setX(q_msg.x);
    q_tf.setY(q_msg.y);
    q_tf.setZ(q_msg.z);
    q_tf.setW(q_msg.w);
    tf2::Matrix3x3 matrix(q_tf);
    const double m20 = matrix[2][0];
    constexpr double kGimbalLockEpsilon = 1e-7;
    constexpr double kHalfPi = 1.57079632679489661923;
    if (std::abs(std::abs(m20) - 1.0) <= kGimbalLockEpsilon)
    {
        yaw = 0.0;
        if (m20 > 0.0)
        {
            pitch = -kHalfPi;
            roll = std::atan2(-matrix[0][1], -matrix[0][2]);
        }
        else
        {
            pitch = kHalfPi;
            roll = std::atan2(matrix[0][1], matrix[0][2]);
        }
        RCLCPP_WARN(rclcpp::get_logger("uplimb_interface.ros_helper"),
                    "pose_to_xyzypr | near gimbal lock, use stable yaw=0 branch. m20:%.17g quaternion[x,y,z,w]:[%.17g, %.17g, %.17g, %.17g]",
                    m20,
                    q_msg.x,
                    q_msg.y,
                    q_msg.z,
                    q_msg.w);
    }
    else
    {
        matrix.getRPY(roll, pitch, yaw);
    }

    xyzrpy[3] = yaw;
    xyzrpy[4] = pitch;
    xyzrpy[5] = roll;
    return true;
}


/**
 * @brief 将一个包含位置和欧拉角(yaw, pitch, roll)的 6 维数组转换为 `geometry_msgs::msg::Pose`
 * 
 * @param xyzrpy 输入的 6 维数组，包含位置和欧拉角数据
 * @param pose 输出的 geometry_msgs::msg::Pose 对象，填充完数据后返回
 */
inline void xyzypr_to_pose(const std::array<double, 6> &xyzypr, geometry_msgs::msg::Pose &pose)
{
    pose.position.x = xyzypr[0];
    pose.position.y = xyzypr[1];
    pose.position.z = xyzypr[2];

    // 填充 四元数
    tf2::Quaternion q;

    auto roll  = xyzypr[5];
    auto pitch = xyzypr[4];
    auto yaw   = xyzypr[3];

    q.setRPY(roll, pitch, yaw);
    pose.orientation.x = q.x();
    pose.orientation.y = q.y();
    pose.orientation.z = q.z();
    pose.orientation.w = q.w();
}

inline void matrix_to_multi_array(const zj_humanoid::upperlimb::app::MatrixDTO& matrix, std_msgs::msg::Float64MultiArray& msg)
{
    const std::size_t rows = matrix.rows > 0 ? static_cast<std::size_t>(matrix.rows) : 0U;
    const std::size_t cols = matrix.cols > 0 ? static_cast<std::size_t>(matrix.cols) : 0U;

    msg.layout.dim.resize(2);
    msg.layout.dim[0].label  = "rows";
    msg.layout.dim[0].size   = rows;
    msg.layout.dim[0].stride = rows * cols;
    msg.layout.dim[1].label  = "cols";
    msg.layout.dim[1].size   = cols;
    msg.layout.dim[1].stride = cols;
    msg.data                 = matrix.data;
}




// inline std_msgs::msg::Float64MultiArray eigenToRosMultiArray(const Eigen::MatrixXd& eigen_mat) {
//     std_msgs::msg::Float64MultiArray msg;
//     // --- 设置布局 ---
//     msg.layout.dim.push_back(std_msgs::msg::MultiArrayDimension());
//     msg.layout.dim[0].label = "rows";
//     msg.layout.dim[0].size = eigen_mat.rows();
//     msg.layout.dim[0].stride = eigen_mat.rows() * eigen_mat.cols();
//     msg.layout.dim.push_back(std_msgs::msg::MultiArrayDimension());
//     msg.layout.dim[1].label = "cols";
//     msg.layout.dim[1].size = eigen_mat.cols();
//     msg.layout.dim[1].stride = eigen_mat.cols();
    
//     msg.layout.data_offset = 0;
//     // --- 高性能数据复制 ---
//     // 利用Eigen数据的内存连续性和std::vector::assign的高效实现
//     // 来完成一次性的数据块复制，避免了循环中的多次push_back。
//     const double* data_ptr = eigen_mat.data();
//     msg.data.assign(data_ptr, data_ptr + eigen_mat.size());
//     return msg;
// }
