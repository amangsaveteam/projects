#pragma once

#include <cstddef>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "uplimb_interface/definitions.hpp"
#include "uplimb_interface/domain/model/result.hpp"

namespace zj_humanoid::upperlimb::domain
{


    struct RobotPartChannelProfile
    {
        std::vector<int> index;
        int              mask;
        int              num;

        RobotPartChannelProfile(std::vector<int> index = {}, const int mask = 0)
            : index(std::move(index)), mask(mask), num(static_cast<int>(this->index.size()))
        {
            // index 允许为空，表示当前 mask 未启用
            // index 中的值和 mask 都不能为负数
            // mask 不为 0 时，index 不能为空，且 mask 必须为单比特位
            // mask 为 0 时，index 必须为空
            // num 由 index 的元素数量计算
            if (this->mask < 0 || (this->mask == 0) != this->index.empty() || (this->mask > 0 && (this->mask & (this->mask - 1)) != 0))
            {
                throw std::invalid_argument("RobotPartChannelProfile index or mask is invalid");
            }
            for (const int value : this->index)
            {
                if (value < 0)
                {
                    throw std::invalid_argument("RobotPartChannelProfile index must not contain negative values");
                }
            }
        }
    };

    struct RobotPartProfile
    {
        RobotPartChannelProfile mdw;
        RobotPartChannelProfile algo;

        RobotPartProfile(RobotPartChannelProfile mdw = {}, RobotPartChannelProfile algo = {}) : mdw(std::move(mdw)), algo(std::move(algo))
        {
            // mdw 和 algo 必须同时启用或同时禁用
            // mdw 和 algo 的 index 长度必须一致
            if ((this->mdw.mask == 0) != (this->algo.mask == 0))
            {
                throw std::invalid_argument("RobotPartProfile mdw and algo enabled states differ");
            }
            if (this->mdw.num != this->algo.num)
            {
                throw std::invalid_argument("RobotPartProfile mdw and algo index lengths differ");
            }
        }
    };

    struct RobotPartsProfile
    {
        RobotPartProfile left;
        RobotPartProfile right;
        RobotPartProfile neck;
        RobotPartProfile waist;
        RobotPartProfile lifting;

        template <typename Visitor>
        inline void for_each(Visitor&& visitor) const
        {
            visitor(this->left);
            visitor(this->right);
            visitor(this->neck);
            visitor(this->waist);
            visitor(this->lifting);
        }

        [[nodiscard]] std::vector<int> get_valid_mdw_masks() const
        {
            std::vector<int> masks;
            masks.reserve(5);
            this->for_each(
                [&](const RobotPartProfile& part)
                {
                    if (part.mdw.mask != 0)
                    {
                        masks.push_back(part.mdw.mask);
                    }
                });
            return masks;
        }

        [[nodiscard]] std::vector<int> get_valid_algo_masks() const
        {
            std::vector<int> masks;
            masks.reserve(5);
            this->for_each(
                [&](const RobotPartProfile& part)
                {
                    if (part.algo.mask != 0)
                    {
                        masks.push_back(part.algo.mask);
                    }
                });
            return masks;
        }

        [[nodiscard]] std::vector<int> get_mdw_indexes() const
        {
            std::vector<int> indexes;
            this->for_each([&](const RobotPartProfile& part) { indexes.insert(indexes.end(), part.mdw.index.begin(), part.mdw.index.end()); });
            return indexes;
        }

        [[nodiscard]] std::vector<int> get_algo_indexes() const
        {
            std::vector<int> indexes;
            this->for_each([&](const RobotPartProfile& part) { indexes.insert(indexes.end(), part.algo.index.begin(), part.algo.index.end()); });
            return indexes;
        }

        [[nodiscard]] bool validate() const
        {
            // mdw 和 algo 的 mask 分别判重，mask 为 0 的禁用部件忽略
            // mdw 和 algo 的 index 分别判重，并且必须连续覆盖 [0, index_count)
            const std::vector<int> mdw_masks    = this->get_valid_mdw_masks();
            const std::vector<int> algo_masks   = this->get_valid_algo_masks();
            const std::vector<int> mdw_indexes  = this->get_mdw_indexes();
            const std::vector<int> algo_indexes = this->get_algo_indexes();

            const std::set<int> unique_mdw_masks(mdw_masks.begin(), mdw_masks.end());
            const std::set<int> unique_algo_masks(algo_masks.begin(), algo_masks.end());
            const std::set<int> unique_mdw_indexes(mdw_indexes.begin(), mdw_indexes.end());
            const std::set<int> unique_algo_indexes(algo_indexes.begin(), algo_indexes.end());
            if (unique_mdw_masks.size() != mdw_masks.size() || unique_algo_masks.size() != algo_masks.size() ||
                unique_mdw_indexes.size() != mdw_indexes.size() || unique_algo_indexes.size() != algo_indexes.size())
            {
                return false;
            }

            const auto indexes_are_contiguous = [](const std::set<int>& indexes)
            {
                return indexes.empty() || (*indexes.begin() == 0 &&
                                           *indexes.rbegin() == static_cast<int>(indexes.size() - 1));
            };
            return indexes_are_contiguous(unique_mdw_indexes) && indexes_are_contiguous(unique_algo_indexes);
        }
    };

    struct DragTeachRecordProfile
    {
        int         record_frequency = 50;
        int         record_max_time  = 180;
        std::string default_folder   = "/home/nav01/zj_humanoid/orin/drag_teach_files/";
    };

    struct CountdownProfile
    {
        int accuracy_ms = 10;
        int timeout_ms  = 1000;
    };

    // 充血模型
    class RobotProfile
    {
    public:
        RobotProfile() = default;

        static RobotProfile       create(const std::vector<std::string>& alias,
                                         const RobotPartsProfile&        parts,
                                         const std::vector<double>&      left_down_pos,
                                         const std::vector<double>&      right_down_pos,
                                         int                             rtipc_define,
                                         double                          max_payload,
                                         const CountdownProfile&         countdown = {},
                                         double                          max_joint_velocity = 3.5,
                                         double                          max_joint_acceleration = 50.0,
                                         double                          max_linear_velocity = 0.5,
                                         double                          max_linear_acceleration = 5.0,
                                         double                          path_max_running_time = 1800.0,
                                         double                          max_lift_velocity = 0.062,
                                         double                          max_lift_acceleration = 10.0);
        [[nodiscard]] static inline int has_arm_mask(const int mdw_mask)
        {
            return mdw_mask & static_cast<int>(MDWArmTypeMask::DualArm);
        }

        [[nodiscard]] DomainResult<int>  get_total_joint_num_by_mask(int mask, bool is_mdw_mask = true) const;
        [[nodiscard]] DomainResult<bool> has_alias(std::string_view alias_name) const;
        [[nodiscard]] DomainResult<bool> is_enable(MDWArmTypeMask mdw_mask) const;
        [[nodiscard]] DomainResult<bool> has_down_pos(int mdw_mask) const;
        [[nodiscard]] DomainResult<int>  validate(int mask, bool is_mdw_mask = true) const;
        [[nodiscard]] DomainResultVoid   validate(const std::vector<double>& joints, int mask, bool is_mdw_mask = true) const;

        [[nodiscard]] inline const std::vector<std::string>& get_alias() const
        {
            return this->alias;
        }
        [[nodiscard]] inline const RobotPartsProfile& get_parts() const
        {
            return this->parts;
        }
        [[nodiscard]] inline const std::vector<double>& get_left_down_pos() const
        {
            return this->left_down_pos;
        } 
        [[nodiscard]] inline const std::vector<double>& get_right_down_pos() const
        {
            return this->right_down_pos;
        }
        [[nodiscard]] inline int get_total_joints_num() const
        {
            return this->total_algo_num;
        }
        [[nodiscard]] inline int get_total_algo_num() const
        {
            return this->total_algo_num;
        }
        [[nodiscard]] inline int get_total_mdw_num() const
        {
            return this->total_mdw_num;
        }
        [[nodiscard]] inline int get_allowed_mdw_mask() const
        {
            return this->allowed_mdw_mask;
        }
        [[nodiscard]] inline int get_allowed_algo_mask() const
        {
            return this->allowed_algo_mask;
        }
        [[nodiscard]] inline int get_rtipc_define() const
        {
            return this->rtipc_define;
        }
        [[nodiscard]] inline double get_max_payload() const
        {
            return this->max_payload;
        }
        [[nodiscard]] inline double get_max_joint_velocity() const
        {
            return this->max_joint_velocity;
        }
        [[nodiscard]] inline double get_max_joint_acceleration() const
        {
            return this->max_joint_acceleration;
        }
        [[nodiscard]] inline double get_max_lift_velocity() const
        {
            return this->max_lift_velocity;
        }
        [[nodiscard]] inline double get_max_lift_acceleration() const
        {
            return this->max_lift_acceleration;
        }
        [[nodiscard]] inline double get_max_joint_velocity(const int mdw_mask) const
        {
            return (mdw_mask & static_cast<int>(MDWArmTypeMask::Lifting)) != 0 ? this->max_lift_velocity : this->max_joint_velocity;
        }
        [[nodiscard]] inline double get_max_joint_acceleration(const int mdw_mask) const
        {
            return (mdw_mask & static_cast<int>(MDWArmTypeMask::Lifting)) != 0 ? this->max_lift_acceleration : this->max_joint_acceleration;
        }
        [[nodiscard]] inline double get_max_linear_velocity() const
        {
            return this->max_linear_velocity;
        }
        [[nodiscard]] inline double get_max_linear_acceleration() const
        {
            return this->max_linear_acceleration;
        }
        [[nodiscard]] inline const CountdownProfile& get_countdown() const
        {
            return this->countdown;
        }
        [[nodiscard]] inline double get_path_max_running_time() const
        {
            return this->path_max_running_time;
        }

        [[nodiscard]] std::vector<int> get_algo_indexes_by_mdw_mask(int mdw_mask) const;
        [[nodiscard]] std::vector<int> get_mdw_indexes_by_algo_mask(int algo_mask) const;

    private:
        std::vector<std::string> alias;
        RobotPartsProfile        parts;
        std::vector<double>      left_down_pos    = {};  // Note: 为mdw顺序
        std::vector<double>      right_down_pos   = {};  // Note: 为mdw顺序
        int                      total_algo_num    = 0;
        int                      total_mdw_num     = 0;
        int                      allowed_mdw_mask  = 0;
        int                      allowed_algo_mask = 0;
        int                      rtipc_define      = -1;
        double                   max_payload       = 4.0;
        double                   max_joint_velocity     = 3.5;
        double                   max_joint_acceleration = 50.0;
        double                   max_lift_velocity      = 0.062;
        double                   max_lift_acceleration  = 10.0;
        double                   max_linear_velocity    = 0.5;
        double                   max_linear_acceleration = 5.0;
        double                   path_max_running_time  = 1800.0;
        CountdownProfile         countdown;
    };

    struct InterfaceProfile
    {
        std::string               motions_folder = "/home/nav01/zj_humanoid/orin/motions/";
        DragTeachRecordProfile    drag_teach_record;
        std::vector<RobotProfile> robot;

        [[nodiscard]] const RobotProfile* find_robot_by_alias(std::string_view alias) const;
    };

}  // namespace zj_humanoid::upperlimb::domain
