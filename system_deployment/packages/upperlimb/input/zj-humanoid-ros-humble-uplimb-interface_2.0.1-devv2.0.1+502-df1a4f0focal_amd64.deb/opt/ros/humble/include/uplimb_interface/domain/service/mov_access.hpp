/*
 * @Author       : Jay
 * @Date         : 2026-06-30 22:46:53
 * @LastEditTime : 2026-07-02 21:42:01
 * @LastEditors  : Jay
 * @Description  : 
 */

#pragma once

#include <string>

namespace zj_humanoid::upperlimb::domain
{

    // 模式准入服务 用来限定当前是否允许进入指定的运动模式


}  // namespace zj_humanoid::upperlimb::domain