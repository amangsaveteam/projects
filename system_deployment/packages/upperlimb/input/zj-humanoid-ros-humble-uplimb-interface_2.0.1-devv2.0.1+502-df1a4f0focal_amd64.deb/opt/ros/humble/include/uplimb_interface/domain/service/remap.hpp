#pragma once

#include <string>
#include <vector>

#include "uplimb_interface/domain/model/profile.hpp"
#include "uplimb_interface/domain/model/result.hpp"

namespace zj_humanoid::upperlimb::domain
{
    template <typename T>
    struct RemapResult
    {
        int            out_mask{0};
        std::vector<T> joints{};
    };

    using JointValueRemapResult = RemapResult<double>;
    using JointNameRemapResult  = RemapResult<std::string>;
    using JointRemapResult      = JointValueRemapResult;

    class RemapService
    {
    public:
        explicit RemapService(const RobotProfile& profile);

        DomainResult<int>                   mdw_to_algo(int mdw_mask) const;
        DomainResult<JointValueRemapResult> mdw_to_algo(const std::vector<double>& mdw_joints, int mdw_mask) const;
        DomainResult<int>                   algo_to_mdw(int algo_mask) const;
        DomainResult<JointValueRemapResult> algo_to_mdw(const std::vector<double>& algo_joints, int algo_mask) const;
        DomainResult<JointNameRemapResult>  algo_to_mdw(const std::vector<std::string>& algo_joint_names, int algo_mask) const;

    private:
        [[nodiscard]] std::string make_message(std::string message) const;

        RobotProfile profile_{};
        std::string  model_name_{"unknown"};
        bool         need_remap_{true};
    };

    using JointRemapDomainService = RemapService;
}  // namespace zj_humanoid::upperlimb::domain
