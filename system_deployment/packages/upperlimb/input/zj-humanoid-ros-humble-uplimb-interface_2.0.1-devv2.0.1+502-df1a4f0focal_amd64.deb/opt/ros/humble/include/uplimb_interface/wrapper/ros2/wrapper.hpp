#pragma once
#include <memory>

#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "uplimb_interface/app/api.hpp"
#include "uplimb_interface/config/profile.hpp"

namespace zj_humanoid::upperlimb
{
    class UplimbInterfaceWrapper : public rclcpp_lifecycle::LifecycleNode
    {
    public:
        using CallbackReturn = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn;

        explicit UplimbInterfaceWrapper(config::MDWProfileDTO profiles, const rclcpp::NodeOptions& options = rclcpp::NodeOptions());
        ~UplimbInterfaceWrapper() override;

        UplimbInterfaceWrapper(const UplimbInterfaceWrapper&)            = delete;
        UplimbInterfaceWrapper& operator=(const UplimbInterfaceWrapper&) = delete;

        using rclcpp_lifecycle::LifecycleNode::activate;
        using rclcpp_lifecycle::LifecycleNode::cleanup;
        using rclcpp_lifecycle::LifecycleNode::configure;
        using rclcpp_lifecycle::LifecycleNode::deactivate;
        using rclcpp_lifecycle::LifecycleNode::shutdown;

        CallbackReturn on_configure(const rclcpp_lifecycle::State& state) override;
        CallbackReturn on_activate(const rclcpp_lifecycle::State& state) override;
        CallbackReturn on_deactivate(const rclcpp_lifecycle::State& state) override;
        CallbackReturn on_cleanup(const rclcpp_lifecycle::State& state) override;
        CallbackReturn on_shutdown(const rclcpp_lifecycle::State& state) override;

        void register_iddp_ready_callback(app::IddpReadyCallback callback);

    private:
        class Impl;
        std::unique_ptr<Impl>    impl_;
    };


}  // namespace zj_humanoid::upperlimb
