#pragma once

#include <fmt/format.h>
#include <fmt/ranges.h>

#include <string_view>

#include "uplimb_interface/config/profile.hpp"
#include "uplimb_interface/domain/model/profile.hpp"

template <>
struct fmt::formatter<zj_humanoid::upperlimb::RobotPartConfig> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::RobotPartConfig& config, FormatContext& ctx) const
    {
        return fmt::format_to(
            ctx.out(), "{{left: {}, right: {}, neck: {}, waist: {}, lifting: {}}}", config.left, config.right, config.neck, config.waist, config.lifting);
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::config::RobotPartIndexConfig> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::config::RobotPartIndexConfig& config, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "{{left: [{}], right: [{}], neck: [{}], waist: [{}], lifting: [{}]}}",
                              fmt::join(config.left, ", "),
                              fmt::join(config.right, ", "),
                              fmt::join(config.neck, ", "),
                              fmt::join(config.waist, ", "),
                              fmt::join(config.lifting, ", "));
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::config::RobotProfileDTO> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::config::RobotProfileDTO& dto, FormatContext& ctx) const
    {
        return fmt::format_to(
            ctx.out(),
            "{:<24}: [{}]\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: {}\n{:<24}: [{}]\n{:<24}: [{}]",
            "alias",
            fmt::join(dto.alias, ", "),
            "rtipc_define",
            dto.rtipc_define,
            "max_payload",
            dto.max_payload,
            "max_joint_velocity",
            dto.max_joint_velocity,
            "max_joint_acceleration",
            dto.max_joint_acceleration,
            "max_lift_velocity",
            dto.max_lift_velocity,
            "max_lift_acceleration",
            dto.max_lift_acceleration,
            "max_linear_velocity",
            dto.max_linear_velocity,
            "max_linear_acceleration",
            dto.max_linear_acceleration,
            "algo_num",
            dto.algo_num,
            "mdw_num",
            dto.mdw_num,
            "algo_index",
            dto.algo_index,
            "mdw_index",
            dto.mdw_index,
            "algo_mask",
            dto.algo_mask,
            "mdw_mask",
            dto.mdw_mask,
            "left_down_pos",
            fmt::join(dto.left_down_pos, ", "),
            "right_down_pos",
            fmt::join(dto.right_down_pos, ", "));
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::domain::RobotPartProfile> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::domain::RobotPartProfile& part, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "{{mdw: {{index: [{}], mask: {}}}, algo: {{index: [{}], mask: {}}}}}",
                              fmt::join(part.mdw.index, ", "),
                              part.mdw.mask,
                              fmt::join(part.algo.index, ", "),
                              part.algo.mask);
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::domain::DragTeachRecordProfile> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::domain::DragTeachRecordProfile& profile, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "{{record_frequency: {}, record_max_time: {}, default_folder: \"{}\"}}",
                              profile.record_frequency,
                              profile.record_max_time,
                              profile.default_folder);
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::domain::RobotProfile> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::domain::RobotProfile& profile, FormatContext& ctx) const
    {
        const zj_humanoid::upperlimb::domain::RobotPartsProfile& parts             = profile.get_parts();
        const int                                                total_algo_num    = profile.get_total_algo_num();
        const int                                                total_mdw_num     = profile.get_total_mdw_num();
        const int                                                allowed_mdw_mask  = profile.get_allowed_mdw_mask();
        const int                                                allowed_algo_mask = profile.get_allowed_algo_mask();
        return fmt::format_to(
            ctx.out(),
            "{{alias: [{}], rtipc_define: {}, max_payload: {}, max_joint_velocity: {}, max_joint_acceleration: {}, max_lift_velocity: {}, "
            "max_lift_acceleration: {}, max_linear_velocity: {}, max_linear_acceleration: {}, parts: {{left: {}, right: {}, neck: {}, waist: {}, lifting: {}}}, left_down_pos: [{}], "
            "right_down_pos: [{}], total_algo_num: {}, total_mdw_num: {}, allowed_mdw_mask: {}, allowed_algo_mask: {}}}",
            fmt::join(profile.get_alias(), ", "),
            profile.get_rtipc_define(),
            profile.get_max_payload(),
            profile.get_max_joint_velocity(),
            profile.get_max_joint_acceleration(),
            profile.get_max_lift_velocity(),
            profile.get_max_lift_acceleration(),
            profile.get_max_linear_velocity(),
            profile.get_max_linear_acceleration(),
            parts.left,
            parts.right,
            parts.neck,
            parts.waist,
            parts.lifting,
            fmt::join(profile.get_left_down_pos(), ", "),
            fmt::join(profile.get_right_down_pos(), ", "),
            total_algo_num,
            total_mdw_num,
            allowed_mdw_mask,
            allowed_algo_mask);
    }
};

template <>
struct fmt::formatter<zj_humanoid::upperlimb::domain::InterfaceProfile> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const zj_humanoid::upperlimb::domain::InterfaceProfile& profile, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "{{motions_folder: \"{}\", drag_teach_record: {}, robot: [{}]}}",
                              profile.motions_folder,
                              profile.drag_teach_record,
                              fmt::join(profile.robot, ", "));
    }
};
