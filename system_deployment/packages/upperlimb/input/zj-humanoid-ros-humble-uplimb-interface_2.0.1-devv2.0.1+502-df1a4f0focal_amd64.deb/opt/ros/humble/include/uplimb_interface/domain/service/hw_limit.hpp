/*
 * @Author       : Jay
 * @Date         : 2026-06-30 22:46:53
 * @LastEditTime : 2026-07-03 22:27:44
 * @LastEditors  : Jay
 * @Description  : 关节位置是否在范围之内
 */

#pragma once

#include <memory>
#include <vector>

#include "uplimb_interface/config/alog.hpp"
#include "uplimb_interface/domain/model/profile.hpp"
#include "uplimb_interface/domain/model/result.hpp"

namespace zj_humanoid::upperlimb::domain
{
    class HWLimitService
    {
    public:
        HWLimitService(const RobotProfile& profile, const config::AlgoConfig& algo_config);
        ~HWLimitService();

        HWLimitService(const HWLimitService&)            = delete;
        HWLimitService& operator=(const HWLimitService&) = delete;

        [[nodiscard]] DomainResultVoid validate(const std::vector<double>& joints, int mdw_mask) const;

    private:
        class Impl;
        std::unique_ptr<Impl> impl_;    // 此处用于编译防火墙
    };
}  // namespace zj_humanoid::upperlimb::domain
