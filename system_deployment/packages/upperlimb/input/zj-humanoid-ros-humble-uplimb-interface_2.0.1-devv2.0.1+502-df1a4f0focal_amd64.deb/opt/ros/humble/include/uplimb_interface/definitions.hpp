/*
 * @Author       : Jay junjie.zhang@zj-humanoid.com
 * @Date         : 2026-03-21 14:03:03
 * @LastEditTime : 2026-04-25 00:55:33
 * @LastEditors  : Jay junjie.zhang@zj-humanoid.com
 * @Description  :
 */

#pragma once

#include <initializer_list>
#include <string>
#include <vector>

namespace zj_humanoid::upperlimb
{

    inline constexpr const char* kUplimbLogName           = "upperlimb";
    inline constexpr const char* kControllerLogModuleName = "Controller";
    inline constexpr const char* kConfigLogModuleName     = "Config";
    inline constexpr const char* kAppLogModuleName        = "App";
    inline constexpr const char* kZmqPuberLogModuleName   = "ZMQPuber";
    inline constexpr const char* kRosLogModuleName        = "ROS";

    enum class AlgoArmTypeMask
    {
        Disable    = 0b00000000,  // 未知
        LeftArm    = 0b00000001,  // 左臂
        RightArm   = 0b00000010,  // 右臂
        Neck       = 0b00000100,  // 颈部
        Waist      = 0b00001000,  // 腰部偏转            // note 除了WA1外的腰部ID为 8
        WaistWA1   = 0b00010000,  // 腰部偏转 俯仰       // note WA1轮臂的腰部ID为16  算法调整过一次
        WaistZYD   = 0b00010000,  // 腰部偏转 俯仰       // note WA1轮臂的腰部ID为16  算法调整过一次
        LiftingWA1 = 0b00001000,  // 腰部升降            // note WA1轮臂的升降ID为8   算法调整过一次
        LiftingZYD = 0b00001000,  // 腰部升降            // note WA1轮臂的升降ID为8   算法调整过一次
        Lifting    = 0b00010000,  // 升降               // note 原有升降ID为8   算法调整过一次
        WaistJCCP  = 0b00001000,  // JCCP的腰部          // note JCCP的腰部ID为8
    };

    enum class MDWArmTypeMask
    {
        WholeBody = -1,          // WholeBody标志
        Disable   = 0b00000000,  // 未知
        LeftArm   = 0b00000001,  // 左臂
        RightArm  = 0b00000010,  // 右臂
        DualArm   = 0b00000011,  // 双臂
        Neck      = 0b00000100,  // 颈部
        Waist     = 0b00001000,  // 腰部偏转
        Lifting   = 0b00010000,  // 腰部偏转
    };

    [[nodiscard]] inline std::string mdw_arm_type_mask_name(const MDWArmTypeMask mask)
    {
        switch (mask)
        {
            case MDWArmTypeMask::WholeBody:
                return "WholeBody";
            case MDWArmTypeMask::Disable:
                return "Disable";
            case MDWArmTypeMask::LeftArm:
                return "LeftArm";
            case MDWArmTypeMask::RightArm:
                return "RightArm";
            case MDWArmTypeMask::DualArm:
                return "DualArm";
            case MDWArmTypeMask::Neck:
                return "Neck";
            case MDWArmTypeMask::Waist:
                return "Waist";
            case MDWArmTypeMask::Lifting:
                return "Lifting";
        }
        return "Unknown(" + std::to_string(static_cast<int>(mask)) + ")";
    }

    [[nodiscard]] inline std::string mdw_arm_type_mask_names(const std::initializer_list<MDWArmTypeMask> masks)
    {
        std::string names;
        for (const MDWArmTypeMask mask : masks)
        {
            if (!names.empty())
            {
                names += " or ";
            }
            names += mdw_arm_type_mask_name(mask);
        }
        return names;
    }

    struct RobotPartConfig
    {
        enum class ValidationResult
        {
            Valid,
            Unconfigured,
            Invalid,
        };

        int left    = -1;
        int right   = -1;
        int neck    = -1;
        int waist   = -1;
        int lifting = -1;

        [[nodiscard]] ValidationResult validate() const
        {
            if (left == -1 && right == -1 && neck == -1 && waist == -1 && lifting == -1)
            {
                return ValidationResult::Unconfigured;
            }
            if (left < 0 || right < 0 || neck < 0 || waist < 0 || lifting < 0)
            {
                return ValidationResult::Invalid;
            }
            return ValidationResult::Valid;
        }
    };

    struct PayLoad
    {
        double                  mass             = 0.0;
        std::vector<double>     cog              = {0.0, 0.0, 0.0};  // 质心位置，单位为米
        static constexpr double DEFAULT_MAX_MASS = 4.0;              // TODO: 这个数值应该放到配置参数中
    };

    enum class RobotCmdState
    {
        Stopped        = 0,
        MoveJ          = 1,
        MoveJPath      = 2,
        MoveLNullspace = 3,
        MoveL          = 4,
        MoveLPath      = 5,
        SpeedJ         = 6,
        SpeedL         = 7,
        SpeedStop      = 8,
        MoveCsvFile    = 9,
        MoveFourier    = 10,
        MoveJSpline    = 11,
        Teach          = 12,
        ServoJ         = 13,
        ServoL         = 14,
        Protected      = 15
    };

}  // namespace zj_humanoid::upperlimb
