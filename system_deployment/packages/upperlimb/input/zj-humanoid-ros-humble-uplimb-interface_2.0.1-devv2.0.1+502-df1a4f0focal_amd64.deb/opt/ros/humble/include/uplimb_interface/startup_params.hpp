#pragma once

#include <array>
#include <cstddef>
#include <sstream>
#include <string>

#include "uplimb_interface/app/dto.hpp"
#include "uplimb_interface/config/params.hpp"
#include "uplimb_interface/config/profile.hpp"

namespace zj_humanoid::upperlimb::startup
{
    struct ResolvedHandSide
    {
        bool            configured{false};
        app::PayloadDTO params{};
        std::string     source{"skipped"};
        std::string     message{};
    };

    struct ResolvedStartupParams
    {
        bool                            should_set_hand{false};
        app::HandParamsRequest          hand_request{};
        std::array<app::PayloadDTO, 2>  payloads{};
        std::array<ResolvedHandSide, 2> hand_sides{};
    };

    inline std::string format_payload(const app::PayloadDTO& payload)
    {
        std::ostringstream out;
        out << "{mass: " << payload.mass << ", cog: [";
        for (std::size_t i = 0; i < payload.cog.size(); ++i)
        {
            if (i > 0)
            {
                out << ", ";
            }
            out << payload.cog[i];
        }
        out << "]}";
        return out.str();
    }

    inline ResolvedHandSide resolve_hand_side(const config::ROSParamsDTO::HandLinkSideDTO& side, const config::MDWProfileDTO& profiles)
    {
        ResolvedHandSide resolved;
        if (side.enable)
        {
            resolved.configured = true;
            resolved.params     = {side.mass_kg, side.cog_m};
            resolved.source     = "custom_yaml";
            resolved.message    = "enable=true";
            return resolved;
        }

        const config::ToolLoadDTO* tool_load = profiles.find_tool_load_by_model(side.hand_model);
        if (tool_load != nullptr)
        {
            resolved.configured = true;
            resolved.params     = {tool_load->mass, tool_load->cog};
            resolved.source     = "tool_loads";
            resolved.message    = "matched model " + side.hand_model;
            return resolved;
        }

        resolved.message = "model not found: " + side.hand_model;
        return resolved;
    }

    inline ResolvedStartupParams resolve_startup_params(const config::ROSParamsDTO& ros_params, const config::MDWProfileDTO& profiles)
    {
        ResolvedStartupParams resolved;
        resolved.hand_sides[0] = resolve_hand_side(ros_params.hand_links.left, profiles);
        resolved.hand_sides[1] = resolve_hand_side(ros_params.hand_links.right, profiles);

        for (std::size_t i = 0; i < resolved.hand_sides.size(); ++i)
        {
            if (resolved.hand_sides[i].configured)
            {
                resolved.should_set_hand       = true;
                resolved.hand_request.hands[i] = resolved.hand_sides[i].params;
            }
        }

        resolved.payloads[0] = {ros_params.default_payloads.left_arm.mass_kg, ros_params.default_payloads.left_arm.cog_m};
        resolved.payloads[1] = {ros_params.default_payloads.right_arm.mass_kg, ros_params.default_payloads.right_arm.cog_m};
        return resolved;
    }
}  // namespace zj_humanoid::upperlimb::startup
