#pragma once

#include <string>
#include <vector>

#include "uplimb_interface/domain/model/h5_file.hpp"

namespace zj_humanoid::upperlimb::domain
{
    struct DragTeachFileData
    {
        std::vector<double>              timestamp{};
        std::vector<std::vector<double>> joints{};
        int                              record_frequency{50};
    };

    class DragTeachFile : public H5File
    {
    public:
        explicit DragTeachFile(const std::string& file_path);

        DomainResultVoid              is_valid() const;
        DomainResult<DragTeachFileData> read_data() const;
        DomainResultVoid write_data(const std::string& robot_name,
                                    int                record_frequency,
                                    const std::vector<double>&              timestamp,
                                    const std::vector<std::vector<double>>& joints) const;

        static const std::string timestamp_dataset;
        static const std::string joints_dataset;
        static const std::string robot_type_attribute;
        static const std::string create_date_attribute;
        static const std::string record_frequency_attribute;
    };

}  // namespace zj_humanoid::upperlimb::domain
