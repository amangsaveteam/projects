#pragma once

#include <fmt/format.h>
#include <fmt/ranges.h>

#include <string>
#include <vector>

#include "std_srvs/srv/set_bool.hpp"
#include "std_srvs/srv/trigger.hpp"
#include "upperlimb_msgs/srv/arm_type.hpp"
#include "upperlimb_msgs/srv/basic_info_get.hpp"
#include "upperlimb_msgs/srv/cartesian_planning_params_get.hpp"
#include "upperlimb_msgs/srv/cartesian_planning_params_set.hpp"
#include "upperlimb_msgs/srv/common.hpp"
#include "upperlimb_msgs/srv/files_lists.hpp"
#include "upperlimb_msgs/srv/fk.hpp"
#include "upperlimb_msgs/srv/ik.hpp"
#include "upperlimb_msgs/srv/is_singular.hpp"
#include "upperlimb_msgs/srv/jacobian_matrix_get.hpp"
#include "upperlimb_msgs/srv/motions_loaded_list.hpp"
#include "upperlimb_msgs/srv/motions_manage.hpp"
#include "upperlimb_msgs/srv/move_j.hpp"
#include "upperlimb_msgs/srv/move_j_by_path.hpp"
#include "upperlimb_msgs/srv/move_j_by_pose.hpp"
#include "upperlimb_msgs/srv/move_l.hpp"
#include "upperlimb_msgs/srv/move_l_by_path.hpp"
#include "upperlimb_msgs/srv/params_get.hpp"
#include "upperlimb_msgs/srv/params_set.hpp"
#include "upperlimb_msgs/srv/pay_load_get.hpp"
#include "upperlimb_msgs/srv/pay_load_set.hpp"
#include "upperlimb_msgs/srv/servo.hpp"

namespace zj_humanoid::upperlimb::formatter_detail
{
    inline std::string pose_summary(const geometry_msgs::msg::Pose& pose)
    {
        return fmt::format("position: [{}, {}, {}] orientation: [{}, {}, {}, {}]",
                           pose.position.x,
                           pose.position.y,
                           pose.position.z,
                           pose.orientation.x,
                           pose.orientation.y,
                           pose.orientation.z,
                           pose.orientation.w);
    }

    inline std::vector<std::string> pose_array_summary(const std::vector<geometry_msgs::msg::Pose>& poses)
    {
        std::vector<std::string> summaries;
        summaries.reserve(poses.size());
        for (const auto& pose : poses)
        {
            summaries.push_back(pose_summary(pose));
        }
        return summaries;
    }

    inline std::string payload_summary(const ::upperlimb_msgs::msg::PayLoad& payload)
    {
        return fmt::format("mass: {} cog: [{}, {}, {}]", payload.mass, payload.cog.x, payload.cog.y, payload.cog.z);
    }

    inline std::string motion_info_summary(const ::upperlimb_msgs::msg::MotionInfo& info)
    {
        return fmt::format("filename: {} alias: {} arm_type: {} joints_size: {} number: {}",
                           info.filename,
                           info.alias,
                           static_cast<int>(info.arm_type),
                           info.joints.size(),
                           info.number);
    }
}  // namespace zj_humanoid::upperlimb::formatter_detail

template <>
struct fmt::formatter<std_srvs::srv::Trigger_Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const std_srvs::srv::Trigger_Request& request, FormatContext& ctx) const
    {
        (void)request;
        return fmt::format_to(ctx.out(), "Trigger");
    }
};

template <>
struct fmt::formatter<std_srvs::srv::Trigger_Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const std_srvs::srv::Trigger_Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<std_srvs::srv::SetBool_Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const std_srvs::srv::SetBool_Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "data: {}", request.data);
    }
};

template <>
struct fmt::formatter<std_srvs::srv::SetBool_Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const std_srvs::srv::SetBool_Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::ArmType::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::ArmType::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "arm_type: {}", static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::ArmType::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::ArmType::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::BasicInfoGet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::BasicInfoGet::Request& request, FormatContext& ctx) const
    {
        (void)request;
        return fmt::format_to(ctx.out(), "BasicInfoGet");
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::BasicInfoGet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::BasicInfoGet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} available_mask: {} total_joint_num: {} parts_size: {}",
                              response.success,
                              response.message,
                              static_cast<int>(response.available_mask),
                              static_cast<int>(response.total_joint_num),
                              response.parts.size());
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::PayLoadGet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::PayLoadGet::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "arm_type: {}", static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::PayLoadGet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::PayLoadGet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} payload: {{{}}}",
                              response.success,
                              response.message,
                              zj_humanoid::upperlimb::formatter_detail::payload_summary(response.payload));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::PayLoadSet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::PayLoadSet::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "arm_type: {} payload: {{{}}}",
                              static_cast<int>(request.arm_type),
                              zj_humanoid::upperlimb::formatter_detail::payload_summary(request.payload));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::PayLoadSet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::PayLoadSet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveJ::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveJ::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "joints: [{}] v: {} acc: {} t: {} is_async: {} arm_type: {}",
                              fmt::join(request.joints, ", "),
                              request.v,
                              request.acc,
                              request.t,
                              request.is_async,
                              static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveJ::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveJ::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::Servo::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::Servo::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "v: {} acc: {} time: {} lookahead_time: {} gain: {} arm_type: {}",
                              request.v,
                              request.acc,
                              request.time,
                              request.lookahead_time,
                              request.gain,
                              static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::Servo::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::Servo::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::Common::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::Common::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "request: {}", request.request);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::Common::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::Common::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "response: {}", response.response);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::FK::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::FK::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "joints: [{}] arm_type: {}", fmt::join(request.joints, ", "), static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::FK::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::FK::Response& response, FormatContext& ctx) const
    {
        const std::vector<std::string> pose_array = zj_humanoid::upperlimb::formatter_detail::pose_array_summary(response.pose_array);
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} pose: {{{}}} arm_type: {} pose_array_size: {} pose_array: [{}] arm_type_array: [{}]",
                              response.success,
                              response.message,
                              zj_humanoid::upperlimb::formatter_detail::pose_summary(response.pose),
                              static_cast<int>(response.arm_type),
                              response.pose_array.size(),
                              fmt::join(pose_array, "; "),
                              fmt::join(response.arm_type_array, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::IK::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::IK::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "pose_size: {} q7: {} q_init_size: {} q_ref_size: {} arm_type: {}",
                              request.pose.size(),
                              request.q7,
                              request.q_init.size(),
                              request.q_ref.size(),
                              static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::IK::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::IK::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} nums: {} joints_size: {} arm_type: [{}] phi: [{}]",
                              response.success,
                              response.message,
                              response.nums,
                              response.joints.size(),
                              fmt::join(response.arm_type, ", "),
                              fmt::join(response.phi, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::IsSingular::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::IsSingular::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "joints: [{}]", fmt::join(request.joints, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::IsSingular::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::IsSingular::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {} is_singular: {}", response.success, response.message, response.is_singular);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveJByPath::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveJByPath::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "path_size: {} time: {} timestamp_size: {} is_async: {} arm_type: {}",
                              request.path.size(),
                              request.time,
                              request.timestamp.size(),
                              request.is_async,
                              static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveJByPath::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveJByPath::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveJByPose::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveJByPose::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "q7: [{}] v: {} acc: {} is_async: {} arm_type: {}",
                              fmt::join(request.q7, ", "),
                              request.v,
                              request.acc,
                              request.is_async,
                              static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveJByPose::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveJByPose::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveL::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveL::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "v: {} acc: {} is_async: {} arm_type: {}", request.v, request.acc, request.is_async, static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveL::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveL::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveLByPath::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveLByPath::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "left_path_size: {} right_path_size: {} time: {} timestamp_size: {} is_async: {} arm_type: {}",
                              request.left_arm_path.size(),
                              request.right_arm_path.size(),
                              request.time,
                              request.timestamp.size(),
                              request.is_async,
                              static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MoveLByPath::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MoveLByPath::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::ParamsGet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::ParamsGet::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "arm_type: {}", static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::ParamsGet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::ParamsGet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} params: [{}]",
                              response.success,
                              response.message,
                              fmt::join(response.params, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::ParamsSet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::ParamsSet::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "arm_type: {} params: [{}]", static_cast<int>(request.arm_type), fmt::join(request.params, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::ParamsSet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::ParamsSet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::CartesianPlanningParamsGet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::CartesianPlanningParamsGet::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "arm_type: {}", static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::CartesianPlanningParamsGet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::CartesianPlanningParamsGet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} joint_mask: [{}]",
                              response.success,
                              response.message,
                              fmt::join(response.joint_mask, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::CartesianPlanningParamsSet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::CartesianPlanningParamsSet::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "arm_type: {} joint_mask: [{}]",
                              static_cast<int>(request.arm_type),
                              fmt::join(request.joint_mask, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::CartesianPlanningParamsSet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::CartesianPlanningParamsSet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "success: {} message: {}", response.success, response.message);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::FilesLists::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::FilesLists::Request& request, FormatContext& ctx) const
    {
        (void)request;
        return fmt::format_to(ctx.out(), "FilesLists");
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::FilesLists::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::FilesLists::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} files_size: {} files: [{}]",
                              response.success,
                              response.message,
                              response.files.size(),
                              fmt::join(response.files, ", "));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MotionsManage::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MotionsManage::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "filename: {} alias: {}", request.filename, request.alias);
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MotionsManage::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MotionsManage::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} info: {{{}}}",
                              response.success,
                              response.message,
                              zj_humanoid::upperlimb::formatter_detail::motion_info_summary(response.info));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MotionsLoadedList::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MotionsLoadedList::Request& request, FormatContext& ctx) const
    {
        (void)request;
        return fmt::format_to(ctx.out(), "MotionsLoadedList");
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::MotionsLoadedList::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::MotionsLoadedList::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} motions_size: {}",
                              response.success,
                              response.message,
                              response.motions.size());
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::JacobianMatrixGet::Request> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::JacobianMatrixGet::Request& request, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(), "arm_type: {}", static_cast<int>(request.arm_type));
    }
};

template <>
struct fmt::formatter<::upperlimb_msgs::srv::JacobianMatrixGet::Response> : fmt::formatter<std::string_view>
{
    template <typename FormatContext>
    auto format(const ::upperlimb_msgs::srv::JacobianMatrixGet::Response& response, FormatContext& ctx) const
    {
        return fmt::format_to(ctx.out(),
                              "success: {} message: {} left_jacobian_size: {} right_jacobian_size: {}",
                              response.success,
                              response.message,
                              response.jacobian_matrix[0].data.size(),
                              response.jacobian_matrix[1].data.size());
    }
};
