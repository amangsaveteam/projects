#pragma once

#include "uplimb_interface/config/profile.hpp"
#include "uplimb_interface/domain/model/profile.hpp"

namespace zj_humanoid::upperlimb::config
{
    [[nodiscard]] inline domain::RobotProfile to_domain(const RobotProfileDTO& dto, const CountdownConfigDTO& countdown, const PathConfigDTO& path = PathConfigDTO{})
    {
        domain::RobotPartsProfile parts;
        parts.left = {{dto.mdw_index.left, dto.mdw_mask.left}, {dto.algo_index.left, dto.algo_mask.left}};
        parts.right = {{dto.mdw_index.right, dto.mdw_mask.right}, {dto.algo_index.right, dto.algo_mask.right}};
        parts.neck = {{dto.mdw_index.neck, dto.mdw_mask.neck}, {dto.algo_index.neck, dto.algo_mask.neck}};
        parts.waist = {{dto.mdw_index.waist, dto.mdw_mask.waist}, {dto.algo_index.waist, dto.algo_mask.waist}};
        parts.lifting = {{dto.mdw_index.lifting, dto.mdw_mask.lifting}, {dto.algo_index.lifting, dto.algo_mask.lifting}};

        return domain::RobotProfile::create(dto.alias,
                                            parts,
                                            dto.left_down_pos,
                                            dto.right_down_pos,
                                            dto.rtipc_define,
                                            dto.max_payload,
                                            {countdown.accuracy_ms, countdown.timeout_ms},
                                            dto.max_joint_velocity,
                                            dto.max_joint_acceleration,
                                            dto.max_linear_velocity,
                                            dto.max_linear_acceleration,
                                            path.max_running_time,
                                            dto.max_lift_velocity,
                                            dto.max_lift_acceleration);
    }
}  // namespace zj_humanoid::upperlimb::config
