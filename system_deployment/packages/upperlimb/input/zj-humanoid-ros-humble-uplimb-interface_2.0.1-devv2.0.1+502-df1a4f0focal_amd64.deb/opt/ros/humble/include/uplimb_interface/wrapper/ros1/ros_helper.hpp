#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <geometry_msgs/Pose.h>
#include <iomanip>
#include <ros/console.h>
#include <std_msgs/Float64MultiArray.h>
#include <sstream>
#include <string>
#include <tf/transform_datatypes.h>

#include "uplimb_interface/app/dto.hpp"

namespace zj_humanoid::upperlimb::ros1
{
    template <typename T>
    inline std::string ros_msg_one_line(const T& msg)
    {
        std::ostringstream ss;
        ss << msg;
        std::string text = ss.str();
        std::replace(text.begin(), text.end(), '\r', ' ');
        std::replace(text.begin(), text.end(), '\n', ' ');
        return text;
    }

    inline bool pose_to_xyzypr(const geometry_msgs::Pose& pose, std::array<double, 6>& xyz_ypr, std::string* error_message = nullptr)
    {
        const auto& q_msg = pose.orientation;
        if (!std::isfinite(q_msg.x) || !std::isfinite(q_msg.y) || !std::isfinite(q_msg.z) || !std::isfinite(q_msg.w))
        {
            if (error_message != nullptr)
            {
                std::ostringstream ss;
                ss << "invalid quaternion: orientation contains non-finite value, x=" << q_msg.x << " y=" << q_msg.y << " z=" << q_msg.z
                   << " w=" << q_msg.w;
                *error_message = ss.str();
            }
            return false;
        }

        const double norm2 = q_msg.x * q_msg.x + q_msg.y * q_msg.y + q_msg.z * q_msg.z + q_msg.w * q_msg.w;
        if (!std::isfinite(norm2) || norm2 <= 0.0)
        {
            if (error_message != nullptr)
            {
                std::ostringstream ss;
                ss << "invalid quaternion: orientation norm is invalid, norm2=" << norm2 << " x=" << q_msg.x << " y=" << q_msg.y
                   << " z=" << q_msg.z << " w=" << q_msg.w;
                *error_message = ss.str();
            }
            return false;
        }

        tf::Quaternion quat;
        tf::quaternionMsgToTF(pose.orientation, quat);
        double roll = 0.0;
        double pitch = 0.0;
        double yaw = 0.0;
        tf::Matrix3x3 matrix(quat);
        const double m20 = matrix[2][0];
        constexpr double kGimbalLockEpsilon = 1e-7;
        constexpr double kHalfPi = 1.57079632679489661923;
        if (std::abs(std::abs(m20) - 1.0) <= kGimbalLockEpsilon)
        {
            yaw = 0.0;
            if (m20 > 0.0)
            {
                pitch = -kHalfPi;
                roll = std::atan2(-matrix[0][1], -matrix[0][2]);
            }
            else
            {
                pitch = kHalfPi;
                roll = std::atan2(matrix[0][1], matrix[0][2]);
            }
            ROS_WARN_STREAM("pose_to_xyzypr | near gimbal lock, use stable yaw=0 branch. m20:" << std::setprecision(17) << m20
                                                                                              << " quaternion[x,y,z,w]:[" << q_msg.x << ", "
                                                                                              << q_msg.y << ", " << q_msg.z << ", "
                                                                                              << q_msg.w << "]");
        }
        else
        {
            matrix.getRPY(roll, pitch, yaw);
        }
        xyz_ypr = {pose.position.x, pose.position.y, pose.position.z, yaw, pitch, roll};
        return true;
    }

    inline geometry_msgs::Pose xyzypr_to_pose(const std::array<double, 6>& pose)
    {
        geometry_msgs::Pose msg;
        msg.position.x = pose[0];
        msg.position.y = pose[1];
        msg.position.z = pose[2];
        tf::Quaternion quat;
        quat.setRPY(pose[5], pose[4], pose[3]);
        tf::quaternionTFToMsg(quat, msg.orientation);
        return msg;
    }

    inline double rad_to_deg(const double rad)
    {
        return rad * 180.0 / M_PI;
    }

    inline void matrix_to_multi_array(const app::MatrixDTO& matrix, std_msgs::Float64MultiArray& msg)
    {
        const std::size_t rows = matrix.rows > 0 ? static_cast<std::size_t>(matrix.rows) : 0U;
        const std::size_t cols = matrix.cols > 0 ? static_cast<std::size_t>(matrix.cols) : 0U;

        msg.layout.dim.resize(2);
        msg.layout.dim[0].label  = "rows";
        msg.layout.dim[0].size   = rows;
        msg.layout.dim[0].stride = rows * cols;
        msg.layout.dim[1].label  = "cols";
        msg.layout.dim[1].size   = cols;
        msg.layout.dim[1].stride = cols;
        msg.data                 = matrix.data;
    }
}  // namespace zj_humanoid::upperlimb::ros1
