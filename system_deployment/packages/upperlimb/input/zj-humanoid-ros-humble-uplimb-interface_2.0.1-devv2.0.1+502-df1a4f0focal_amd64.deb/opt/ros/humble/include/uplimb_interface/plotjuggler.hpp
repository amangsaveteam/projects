#pragma once

#include <atomic>
#include <logging.hpp>
#include <string>
#include <thread>

#include "uplimb_interface/app/api.hpp"

namespace zj_humanoid::upperlimb
{
    struct ZmqPlotOptions
    {
        std::string endpoint{"tcp://*:9873"};
        std::string topic{"AlgoPlotData"};
        int         sleep_us{1000};
        int         realtime_priority{5};
        int         mdw_plot_arm_type{15};
    };

    class ZmqPlotPublisher
    {
    public:
        explicit ZmqPlotPublisher(app::AppFacade& app_facade, ZmqPlotOptions options = {});
        ~ZmqPlotPublisher();

        ZmqPlotPublisher(const ZmqPlotPublisher&)            = delete;
        ZmqPlotPublisher& operator=(const ZmqPlotPublisher&) = delete;
        ZmqPlotPublisher(ZmqPlotPublisher&&)                 = delete;
        ZmqPlotPublisher& operator=(ZmqPlotPublisher&&)      = delete;

        bool start();
        void stop();
        bool running() const;

    private:
        void loop();

        app::AppFacade&                app_facade_;
        ZmqPlotOptions                 options_{};
        zj_humanoid::log::ModuleLogger logger_;
        bool                           logger_valid_{false};
        std::atomic<bool>              running_{false};
        std::thread                    thread_;
        void*                          context_{nullptr};
        void*                          socket_{nullptr};
        unsigned long long int         last_up_time_{0};
    };

}  // namespace zj_humanoid::upperlimb
