#pragma once

#include "uplimb_interface/result.hpp"

namespace zj_humanoid::upperlimb::app
{
    template <typename T>
    using AppResult = Result<T>;

    using AppResultVoid = Status;

}  // namespace zj_humanoid::upperlimb::app
