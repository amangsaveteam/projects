#pragma once

#include <fmt/format.h>
#include <yaml-cpp/yaml.h>

#include <cmath>
#include <cstddef>
#include <exception>
#include <filesystem>
#include <optional>
#include <string>
#include <vector>

#include "uplimb_interface/config/joint_limit.hpp"

namespace zj_humanoid::upperlimb::config
{

    struct LimitConfig
    {
        double max;
        double min;
    };

    struct AlgoJointConfig
    {
        std::string name;
        int         algo_index = 0;
        double      home_pos = 0.0;
        std::optional<LimitConfig> limits;

        bool validate(const double value, std::string& message) const
        {
            if (!std::isfinite(value))
            {
                message = fmt::format("Joint {} value is not finite.", name);
                return false;
            }

            if (!limits.has_value())
            {
                return true;
            }

            if (!std::isfinite(limits->min) || !std::isfinite(limits->max) || limits->min > limits->max)
            {
                message = fmt::format("Joint {} limit [{:.6f}, {:.6f}] is invalid.", name, limits->min, limits->max);
                return false;
            }

            if (value < limits->min || value > limits->max)
            {
                message = fmt::format(
                    "Joint {} value {:.6f} is out of range [{:.6f}, {:.6f}].",
                    // DEFAULT_NAME,
                    name,
                    value,
                    limits->min,
                    limits->max);
                return false;
            }

            return true;
        }
    };

    struct ControllerParaConfig
    {
        std::vector<double> joint_collision_threshold;
    };

    struct AlgoConfig
    {
        std::string              define_path;
        std::string              robot_name;
        std::string              controller_params_path;
        std::string              urdf_file;
        bool                     collision_detection_on = false;
        std::size_t              total_joint_num = 0;
        std::vector<double>      joint_collision_threshold;
        std::string              hw_body_file;
        HardwareBodyConfig       hw_body_config;
        std::vector<AlgoJointConfig> joints_list;

        static AlgoConfig from_yaml(const std::string& define_path,
                                    std::string*       error_message = nullptr);
        void validate() const;
        void get_joints_name(std::vector<std::string>& joint_names) const;

        const AlgoJointConfig* get_joint_config_by_algo_index(const int algo_index) const;
        const JointConfig* get_hardware_joint_config_by_algo_index(const int algo_index) const;
        const JointConfig* get_hardware_joint_config_by_urdf_name(const std::string& urdf_name) const;
        const JointConfig* get_hardware_joint_config_by_name(const std::string& name) const;
    };

}  // namespace zj_humanoid::upperlimb::config

namespace YAML
{
    template <>
    struct convert<zj_humanoid::upperlimb::config::LimitConfig>
    {
        static bool decode(const Node& node, zj_humanoid::upperlimb::config::LimitConfig& rhs)
        {
            if (!node.IsSequence() || node.size() != 2)
            {
                if (!node.IsMap())
                {
                    return false;
                }

                rhs.min = node["min"].as<double>();
                rhs.max = node["max"].as<double>();
                return true;
            }

            rhs.min = node[0].as<double>();
            rhs.max = node[1].as<double>();
            return true;
        }
    };

    template <>
    struct convert<zj_humanoid::upperlimb::config::ControllerParaConfig>
    {
        static bool decode(const Node& node, zj_humanoid::upperlimb::config::ControllerParaConfig& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }

            const Node joint_collision_threshold = node["JOINT_COLLISION_THRESHOLD"];
            if (!joint_collision_threshold || !joint_collision_threshold.IsSequence())
            {
                return false;
            }

            rhs.joint_collision_threshold = joint_collision_threshold.as<std::vector<double>>();
            return true;
        }
    };

    template <>
    struct convert<zj_humanoid::upperlimb::config::AlgoJointConfig>
    {
        static bool decode(const Node& node, zj_humanoid::upperlimb::config::AlgoJointConfig& rhs)
        {
            if (!node.IsMap() || node.size() != 1)
            {
                return false;
            }

            const auto        it         = node.begin();
            const std::string joint_name = it->first.as<std::string>();
            const Node        joint_node = it->second;
            const Node        pos_limit  = joint_node["pos_limit"];
            const Node        alg_num    = joint_node["algNum"];
            if (!joint_node.IsMap() || !alg_num)
            {
                return false;
            }

            rhs.name       = joint_name;
            rhs.algo_index = alg_num.as<int>();
            rhs.home_pos   = joint_node["home"] ? joint_node["home"].as<double>() : 0.0;
            rhs.limits     = pos_limit ? std::make_optional(pos_limit.as<zj_humanoid::upperlimb::config::LimitConfig>()) : std::nullopt;
            return true;
        }
    };

    template <>
    struct convert<zj_humanoid::upperlimb::config::AlgoConfig>
    {
        static bool decode(const Node& node, zj_humanoid::upperlimb::config::AlgoConfig& rhs)
        {
            if (!node.IsMap())
            {
                return false;
            }

            const Node robot_name             = node["ROBOT_NAME"];
            const Node urdf_file              = node["URDF_FILE"];
            const Node hw_body_file           = node["HARDWARE_BODY_FILE"];
            const Node collision_detection_on = node["COLLISION_DETECTION_ON"];
            const Node joints                 = node["JOINTS_LIST"];
            if (!robot_name || !urdf_file || !hw_body_file || !collision_detection_on || !joints || !joints.IsSequence())
            {
                return false;
            }

            rhs.robot_name             = robot_name.as<std::string>();
            rhs.urdf_file              = urdf_file.as<std::string>();
            rhs.hw_body_file           = hw_body_file.as<std::string>();
            rhs.controller_params_path = node["CONTROLLER_PARA_PATH"] ? node["CONTROLLER_PARA_PATH"].as<std::string>() : std::string{};
            rhs.collision_detection_on = collision_detection_on.as<bool>();
            rhs.joints_list            = joints.as<std::vector<zj_humanoid::upperlimb::config::AlgoJointConfig>>();
            rhs.total_joint_num        = rhs.joints_list.size();

            // 验证配置的合法性
            for (const auto& joint : rhs.joints_list)
            {
                if (joint.algo_index < 0 || static_cast<std::size_t>(joint.algo_index) >= rhs.total_joint_num)
                {
                    return false;
                }

                std::string message;
                if (!joint.validate(joint.home_pos, message))
                {
                    return false;
                }
            }

            if (!rhs.controller_params_path.empty() && std::filesystem::exists(rhs.controller_params_path))
            {
                try
                {
                    const Node controller_para_root = LoadFile(rhs.controller_params_path);
                    rhs.joint_collision_threshold  = controller_para_root.as<zj_humanoid::upperlimb::config::ControllerParaConfig>().joint_collision_threshold;
                }
                catch (const std::exception&)
                {
                    return false;
                }
            }
            return true;
        }
    };
}  // namespace YAML
