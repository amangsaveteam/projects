

#pragma once
#include <string>
#include <vector>

#include "uplimb_interface/config/alog.hpp"
#include "uplimb_interface/config/profile.hpp"
namespace zj_humanoid::upperlimb::config
{


    struct ROSParamsDTO
    {
        struct HandLinkSideDTO
        {
            std::string           hand_model{"F5D6_P"};
            bool                  enable{false};
            double                mass_kg{0.5};
            std::vector<double>   cog_m{0.0, 0.0, 0.0};
        };

        struct HandLinksDTO
        {
            HandLinkSideDTO left;
            HandLinkSideDTO right;
        };

        struct PayloadSideDTO
        {
            double                mass_kg{0.0};
            std::vector<double>   cog_m{0.0, 0.0, 0.0};
        };

        struct DefaultPayloadsDTO
        {
            PayloadSideDTO left_arm;
            PayloadSideDTO right_arm;
        };

        std::string        robot_name{"zj_humanoid"};
        std::string        robot_type{""};
        std::string        controller{"Unknown"};
        int                pub_frequency{125};
        std::string        log_level{"DEBUG"};
        std::string        log_dir{"/home/nav01/zj_humanoid"};
        bool               zmq_plot{false};
        std::string        zmq_plot_endpoint{"tcp://*:9873"};
        bool               collision_detection{false};
        std::string        motions_folder{"/home/nav01/zj_humanoid/orin/motions/"};
        std::string        drag_teach_folder{"/home/nav01/zj_humanoid/orin/drag_teach_files/"};
        int                record_frequency{50};
        int                record_max_time{180};
        HandLinksDTO       hand_links{};
        DefaultPayloadsDTO default_payloads{};
    };


    struct DragTeachRecordDTO
    {
        static constexpr int MAX_RECORD_FREQUENCY = 125;  // 最大托拽示教记录频率
        static constexpr int MIN_RECORD_FREQUENCY = 25;   // 最小托拽示教记录频率
        static constexpr int MAX_RECORD_TIME      = 600;  // 最大托拽示教记录时间,单位秒, 10分钟
        static constexpr int MIN_RECORD_TIME      = 60;   // 最小托拽示教记录时间,单位秒
        int                  record_frequency     = 50;
        int                  record_max_time      = 180;
        std::string          default_folder       = "/home/nav01/zj_humanoid/orin/drag_teach_files/";
    };

    struct UpperlimbConfig
    {
        AlgoConfig    algo;
        MDWProfileDTO mdw;
        ROSParamsDTO  ros;
    };


}  // namespace zj_humanoid::upperlimb::config
