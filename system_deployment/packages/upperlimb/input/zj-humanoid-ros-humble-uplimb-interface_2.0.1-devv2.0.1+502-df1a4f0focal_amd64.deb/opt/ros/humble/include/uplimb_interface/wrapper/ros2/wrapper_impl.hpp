#pragma once

#include <logging.hpp>
#include <fmt/format.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <memory>
#include <string>
#include <string_view>
#include <type_traits>
#include <thread>
#include <vector>

#include "geometry_msgs/msg/wrench_stamped.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "rclcpp_lifecycle/lifecycle_publisher.hpp"
#include "sensor_msgs/msg/joint_state.hpp"
#include "std_msgs/msg/float64_multi_array.hpp"
#include "std_msgs/msg/int8.hpp"
#include "std_srvs/srv/set_bool.hpp"
#include "std_srvs/srv/trigger.hpp"
#include "uplimb_interface/utils.hpp"
#include "upperlimb_msgs/action/drag_teach_record.hpp"
#include "upperlimb_msgs/action/drag_teach_replay.hpp"
#include "upperlimb_msgs/action/motion_execute.hpp"
#include "upperlimb_msgs/msg/dual_pose.hpp"
#include "upperlimb_msgs/msg/joints.hpp"
#include "upperlimb_msgs/msg/pose.hpp"
#include "upperlimb_msgs/msg/speed_j.hpp"
#include "upperlimb_msgs/msg/speed_l.hpp"
#include "upperlimb_msgs/msg/tcp_speed.hpp"
#include "upperlimb_msgs/msg/uplimb_state.hpp"
#include "upperlimb_msgs/srv/arm_type.hpp"
#include "upperlimb_msgs/srv/basic_info_get.hpp"
#include "upperlimb_msgs/srv/cartesian_planning_params_get.hpp"
#include "upperlimb_msgs/srv/cartesian_planning_params_set.hpp"
#include "upperlimb_msgs/srv/files_lists.hpp"
#include "upperlimb_msgs/srv/fk.hpp"
#include "upperlimb_msgs/srv/ik.hpp"
#include "upperlimb_msgs/srv/is_singular.hpp"
#include "upperlimb_msgs/srv/jacobian_matrix_get.hpp"
#include "upperlimb_msgs/srv/motions_loaded_list.hpp"
#include "upperlimb_msgs/srv/motions_manage.hpp"
#include "upperlimb_msgs/srv/move_j.hpp"
#include "upperlimb_msgs/srv/move_j_by_path.hpp"
#include "upperlimb_msgs/srv/move_j_by_pose.hpp"
#include "upperlimb_msgs/srv/move_l.hpp"
#include "upperlimb_msgs/srv/servo.hpp"
// #include "upperlimb_msgs/srv/move_j_by_pose.hpp"
// #include "upperlimb_msgs/srv/move_l.hpp"
#include "uplimb_interface/app/api.hpp"
#include "uplimb_interface/config/params.hpp"
#include "uplimb_interface/controller.hpp"
#include "uplimb_interface/domain/model/profile.hpp"
#include "uplimb_interface/formatter/ros_message.hpp"
#include "uplimb_interface/logging_helpers.hpp"
#include "uplimb_interface/plotjuggler.hpp"
#include "uplimb_interface/wrapper/ros2/ros_helper.hpp"
#include "uplimb_interface/wrapper/ros2/wrapper.hpp"
#include "upperlimb_msgs/srv/move_l_by_path.hpp"
#include "upperlimb_msgs/srv/params_get.hpp"
#include "upperlimb_msgs/srv/params_set.hpp"
#include "upperlimb_msgs/srv/pay_load_get.hpp"
#include "upperlimb_msgs/srv/pay_load_set.hpp"

namespace zj_humanoid::upperlimb
{
    template <typename MessageT>
    inline void debug_log_service_message(zj_humanoid::log::ModuleLogger& logger, const char* func_name, std::string_view type, const MessageT& message)
    {
        std::string yaml_str = fmt::format("{}", message);
        std::replace(yaml_str.begin(), yaml_str.end(), '\r', ' ');
        std::replace(yaml_str.begin(), yaml_str.end(), '\n', ' ');
        LOGGING_DEBUG(&logger, "{} {} | {}", func_name, type, yaml_str);
    }

    class UplimbInterfaceWrapper::Impl
    {
    public:
        Impl(rclcpp_lifecycle::LifecycleNode* node, config::MDWProfileDTO profiles);
        ~Impl();

        UplimbInterfaceWrapper::CallbackReturn on_configure();
        UplimbInterfaceWrapper::CallbackReturn on_activate();
        UplimbInterfaceWrapper::CallbackReturn on_deactivate();
        UplimbInterfaceWrapper::CallbackReturn on_cleanup();
        UplimbInterfaceWrapper::CallbackReturn on_shutdown();

        void register_callback();
        void register_iddp_ready_callback(app::IddpReadyCallback callback);

    private:
        UplimbInterfaceWrapper::CallbackReturn init_ros_params();
        UplimbInterfaceWrapper::CallbackReturn init();
        void loop();
        void activate_publishers();
        void deactivate_publishers();
        void stop_publish_loop();
        void pre_configure();
        void post_configure();

        using MotionExecute             = ::upperlimb_msgs::action::MotionExecute;
        using DragTeachRecord           = ::upperlimb_msgs::action::DragTeachRecord;
        using DragTeachReplay           = ::upperlimb_msgs::action::DragTeachReplay;
        using MotionExecuteGoalHandle   = rclcpp_action::ServerGoalHandle<MotionExecute>;
        using DragTeachRecordGoalHandle = rclcpp_action::ServerGoalHandle<DragTeachRecord>;
        using DragTeachReplayGoalHandle = rclcpp_action::ServerGoalHandle<DragTeachReplay>;

        // publisher
        rclcpp_lifecycle::LifecyclePublisher<sensor_msgs::msg::JointState>::SharedPtr       puber_joint_states_;
        rclcpp_lifecycle::LifecyclePublisher<::upperlimb_msgs::msg::UplimbState>::SharedPtr puber_robot_cmd_state_;
        rclcpp_lifecycle::LifecyclePublisher<::upperlimb_msgs::msg::Pose>::SharedPtr        puber_left_arm_tcp_pose_;
        rclcpp_lifecycle::LifecyclePublisher<::upperlimb_msgs::msg::Pose>::SharedPtr        puber_right_arm_tcp_pose_;
        rclcpp_lifecycle::LifecyclePublisher<::upperlimb_msgs::msg::Pose>::SharedPtr        puber_head2base_pose_;
        rclcpp_lifecycle::LifecyclePublisher<::upperlimb_msgs::msg::TcpSpeed>::SharedPtr    puber_dual_arm_tcp_speed_;
        rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::Int8>::SharedPtr                puber_occupancy_state_;
        rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::Float64MultiArray>::SharedPtr   puber_left_jacobian_matrix_;
        rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::Float64MultiArray>::SharedPtr   puber_right_jacobian_matrix_;
        rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::Float64MultiArray>::SharedPtr   puber_external_torque_;
        rclcpp_lifecycle::LifecyclePublisher<geometry_msgs::msg::WrenchStamped>::SharedPtr  puber_waist_force_ext_;

        // subscriber
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedL>::SharedPtr   suber_dual_arm_speedl_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedL>::SharedPtr   suber_left_arm_speedl_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedL>::SharedPtr   suber_right_arm_speedl_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedL>::SharedPtr   suber_whole_body_speedl_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedJ>::SharedPtr   suber_left_arm_speedj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedJ>::SharedPtr   suber_right_arm_speedj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedJ>::SharedPtr   suber_dual_arm_speedj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedJ>::SharedPtr   suber_whole_body_speedj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedJ>::SharedPtr   suber_neck_speedj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedJ>::SharedPtr   suber_waist_speedj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::SpeedJ>::SharedPtr   suber_lifting_speedj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::Joints>::SharedPtr   suber_left_arm_servoj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::Joints>::SharedPtr   suber_right_arm_servoj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::Joints>::SharedPtr   suber_dual_arm_servoj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::Joints>::SharedPtr   suber_whole_body_servoj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::Joints>::SharedPtr   suber_neck_servoj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::Joints>::SharedPtr   suber_waist_servoj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::Joints>::SharedPtr   suber_lifting_servoj_;
        rclcpp::Subscription<::upperlimb_msgs::msg::DualPose>::SharedPtr suber_left_arm_servol_;
        rclcpp::Subscription<::upperlimb_msgs::msg::DualPose>::SharedPtr suber_right_arm_servol_;
        rclcpp::Subscription<::upperlimb_msgs::msg::DualPose>::SharedPtr suber_dual_arm_servol_;
        rclcpp::Subscription<::upperlimb_msgs::msg::DualPose>::SharedPtr suber_whole_body_servol_;
        rclcpp::Subscription<std_msgs::msg::Int8>::SharedPtr             suber_uplimb_occupation_;

        // service
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_stop_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_version_;
        rclcpp::Service<::upperlimb_msgs::srv::BasicInfoGet>::SharedPtr               service_basic_info_;
        rclcpp::Service<::upperlimb_msgs::srv::ArmType>::SharedPtr                    service_teach_mode_enter_;
        rclcpp::Service<::upperlimb_msgs::srv::ArmType>::SharedPtr                    service_teach_mode_exit_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_left_arm_go_home_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_right_arm_go_home_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_dual_arm_go_home_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_neck_go_home_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_waist_go_home_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_lifting_go_home_;
        rclcpp::Service<::upperlimb_msgs::srv::ArmType>::SharedPtr                    service_whole_body_go_home_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_left_arm_go_down_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_right_arm_go_down_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_dual_arm_go_down_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJ>::SharedPtr                      service_dual_arm_movj_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJ>::SharedPtr                      service_left_arm_movj_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJ>::SharedPtr                      service_right_arm_movj_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJ>::SharedPtr                      service_neck_movj_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJ>::SharedPtr                      service_waist_movj_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJ>::SharedPtr                      service_lifting_movj_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJ>::SharedPtr                      service_whole_body_movj_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPose>::SharedPtr                service_dual_arm_movj_by_pose_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPose>::SharedPtr                service_left_arm_movj_by_pose_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPose>::SharedPtr                service_right_arm_movj_by_pose_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPose>::SharedPtr                service_whole_body_movj_by_pose_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPath>::SharedPtr                service_left_arm_movj_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPath>::SharedPtr                service_right_arm_movj_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPath>::SharedPtr                service_dual_arm_movj_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPath>::SharedPtr                service_whole_body_movj_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPath>::SharedPtr                service_neck_movj_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPath>::SharedPtr                service_waist_movj_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveJByPath>::SharedPtr                service_lifting_movj_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveLByPath>::SharedPtr                service_left_arm_movl_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveLByPath>::SharedPtr                service_right_arm_movl_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveLByPath>::SharedPtr                service_dual_arm_movl_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveLByPath>::SharedPtr                service_whole_body_movl_by_path_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveL>::SharedPtr                      service_dual_arm_movl_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveL>::SharedPtr                      service_left_arm_movl_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveL>::SharedPtr                      service_right_arm_movl_;
        rclcpp::Service<::upperlimb_msgs::srv::MoveL>::SharedPtr                      service_whole_body_movl_;
        rclcpp::Service<::upperlimb_msgs::srv::FK>::SharedPtr                         service_whole_body_fk_;
        rclcpp::Service<::upperlimb_msgs::srv::FK>::SharedPtr                         service_left_arm_fk_;
        rclcpp::Service<::upperlimb_msgs::srv::FK>::SharedPtr                         service_right_arm_fk_;
        rclcpp::Service<::upperlimb_msgs::srv::IK>::SharedPtr                         service_whole_body_ik_;
        rclcpp::Service<::upperlimb_msgs::srv::IK>::SharedPtr                         service_right_arm_ik_;
        rclcpp::Service<::upperlimb_msgs::srv::IK>::SharedPtr                         service_left_arm_ik_;
        rclcpp::Service<::upperlimb_msgs::srv::Servo>::SharedPtr                      service_set_servo_params_;
        rclcpp::Service<::upperlimb_msgs::srv::Servo>::SharedPtr                      service_clear_servo_params_;
        rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr                            service_enable_speedj_;
        rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr                            service_enable_speedl_;
        rclcpp::Service<::upperlimb_msgs::srv::IsSingular>::SharedPtr                 service_whole_body_is_singular_;
        rclcpp::Service<::upperlimb_msgs::srv::IsSingular>::SharedPtr                 service_left_arm_is_singular_;
        rclcpp::Service<::upperlimb_msgs::srv::IsSingular>::SharedPtr                 service_right_arm_is_singular_;
        rclcpp::Service<::upperlimb_msgs::srv::JacobianMatrixGet>::SharedPtr          service_jacobian_matrix_;
        rclcpp::Service<::upperlimb_msgs::srv::FilesLists>::SharedPtr                 service_motion_lists_;
        rclcpp::Service<::upperlimb_msgs::srv::MotionsManage>::SharedPtr              service_load_motion_;
        rclcpp::Service<::upperlimb_msgs::srv::MotionsManage>::SharedPtr              service_unload_motion_;
        rclcpp::Service<::upperlimb_msgs::srv::MotionsLoadedList>::SharedPtr          service_loaded_motions_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_get_safety_lock_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_release_safety_lock_;
        rclcpp::Service<::upperlimb_msgs::srv::PayLoadGet>::SharedPtr                 service_get_payload_;
        rclcpp::Service<::upperlimb_msgs::srv::PayLoadSet>::SharedPtr                 service_set_payload_;
        rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr                            service_collision_detection_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_collision_detection_is_enable_;
        rclcpp::Service<::upperlimb_msgs::srv::ParamsSet>::SharedPtr                  service_collision_detection_set_params_;
        rclcpp::Service<::upperlimb_msgs::srv::ParamsGet>::SharedPtr                  service_collision_detection_get_params_;
        rclcpp::Service<::upperlimb_msgs::srv::CartesianPlanningParamsGet>::SharedPtr service_cartesian_planning_get_;
        rclcpp::Service<::upperlimb_msgs::srv::CartesianPlanningParamsSet>::SharedPtr service_cartesian_planning_set_;
        rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr                            service_teach_stop_record_;
        rclcpp::Service<::upperlimb_msgs::srv::FilesLists>::SharedPtr                 service_teach_lists_;
        rclcpp::CallbackGroup::SharedPtr                                              stop_callback_group_;

        // action
        rclcpp_action::Server<MotionExecute>::SharedPtr   aciton_execute_motion;
        rclcpp_action::Server<DragTeachRecord>::SharedPtr aciton_teach_record;
        rclcpp_action::Server<DragTeachReplay>::SharedPtr aciton_teach_replay;

        // TODO 在publish.cpp中实现下面4个函数,修改为使用this->controller-> 的方法进行实现
        void publish_joint_states(sensor_msgs::msg::JointState& msg);
        void publish_arm_tcp_pose(std::array<::upperlimb_msgs::msg::Pose, 2>& msgs, std::array<geometry_msgs::msg::Pose, 2>& geometry_poses);
        void publish_arm_tcp_speed(::upperlimb_msgs::msg::TcpSpeed& msg);
        void publish_robot_cmd_state(::upperlimb_msgs::msg::UplimbState& msg);
        void publish_jacobian_matrix(std::array<std_msgs::msg::Float64MultiArray, 2>& jacobian_matrixs);
        void publish_external_torque(std_msgs::msg::Float64MultiArray& msg);
        void publish_waist_force_ext(geometry_msgs::msg::WrenchStamped& msg);

        // subscriber callback
        void suber_for_speedj(const ::upperlimb_msgs::msg::SpeedJ::SharedPtr msg, MDWArmTypeMask arm_type);
        void suber_for_servoj(const ::upperlimb_msgs::msg::Joints::SharedPtr msg, MDWArmTypeMask arm_type);
        void suber_for_speedl(const ::upperlimb_msgs::msg::SpeedL::SharedPtr msg, MDWArmTypeMask arm_type);
        void suber_for_servol(const ::upperlimb_msgs::msg::DualPose::SharedPtr msg, MDWArmTypeMask arm_type);
        void suber_for_uplimb_occupation(const std_msgs::msg::Int8::SharedPtr msg);

        // service callback
        // TODO 单独MutuallyExclusive + SingleThreadedExecutor  处理
        void service_for_stop(std::shared_ptr<std_srvs::srv::Trigger::Request> request, std::shared_ptr<std_srvs::srv::Trigger::Response> response);
        void service_for_version(std::shared_ptr<std_srvs::srv::Trigger::Request> request, std::shared_ptr<std_srvs::srv::Trigger::Response> response);
        void service_for_basic_info(std::shared_ptr<::upperlimb_msgs::srv::BasicInfoGet::Request>  request,
                                    std::shared_ptr<::upperlimb_msgs::srv::BasicInfoGet::Response> response);

        void service_for_teach_mode(const std::shared_ptr<::upperlimb_msgs::srv::ArmType::Request> request,
                                    std::shared_ptr<::upperlimb_msgs::srv::ArmType::Response>      response,
                                    bool                                                           enable);
        template <typename RequestT, typename ResponseT>
        void service_for_go_home(std::shared_ptr<RequestT> request, std::shared_ptr<ResponseT> response, MDWArmTypeMask arm_type = MDWArmTypeMask::WholeBody);
        void service_for_go_down(std::shared_ptr<std_srvs::srv::Trigger::Request>  request,
                                 std::shared_ptr<std_srvs::srv::Trigger::Response> response,
                                 MDWArmTypeMask                                    arm_type);

        void service_for_movej(const std::shared_ptr<::upperlimb_msgs::srv::MoveJ::Request> request,
                               std::shared_ptr<::upperlimb_msgs::srv::MoveJ::Response>      response,
                               MDWArmTypeMask                                               arm_type = MDWArmTypeMask::WholeBody);
        void service_for_movej_by_pose(const std::shared_ptr<::upperlimb_msgs::srv::MoveJByPose::Request> request,
                                       std::shared_ptr<::upperlimb_msgs::srv::MoveJByPose::Response>      response,
                                       MDWArmTypeMask                                                     arm_type);
        void service_for_movej_by_path(const std::shared_ptr<::upperlimb_msgs::srv::MoveJByPath::Request> request,
                                       std::shared_ptr<::upperlimb_msgs::srv::MoveJByPath::Response>      response,
                                       MDWArmTypeMask                                                     arm_type);
        void service_for_movel_by_path(const std::shared_ptr<::upperlimb_msgs::srv::MoveLByPath::Request> request,
                                       std::shared_ptr<::upperlimb_msgs::srv::MoveLByPath::Response>      response,
                                       MDWArmTypeMask                                                     arm_type);
        void service_for_movel(const std::shared_ptr<::upperlimb_msgs::srv::MoveL::Request> request,
                               std::shared_ptr<::upperlimb_msgs::srv::MoveL::Response>      response,
                               MDWArmTypeMask                                               arm_type);
        void service_for_FK(const std::shared_ptr<::upperlimb_msgs::srv::FK::Request> request,
                            std::shared_ptr<::upperlimb_msgs::srv::FK::Response>      response,
                            MDWArmTypeMask                                            arm_type);
        void service_for_IK(const std::shared_ptr<::upperlimb_msgs::srv::IK::Request> request,
                            std::shared_ptr<::upperlimb_msgs::srv::IK::Response>      response,
                            MDWArmTypeMask                                            arm_type);
        void service_for_servo(const std::shared_ptr<::upperlimb_msgs::srv::Servo::Request> request,
                               std::shared_ptr<::upperlimb_msgs::srv::Servo::Response>      response,
                               bool                                                         enable);
        void service_for_enable_speedj(const std::shared_ptr<std_srvs::srv::SetBool::Request> request,
                                       std::shared_ptr<std_srvs::srv::SetBool::Response>      response);
        void service_for_enable_speedl(const std::shared_ptr<std_srvs::srv::SetBool::Request> request,
                                       std::shared_ptr<std_srvs::srv::SetBool::Response>      response);
        void service_for_is_singular(const std::shared_ptr<::upperlimb_msgs::srv::IsSingular::Request> request,
                                     std::shared_ptr<::upperlimb_msgs::srv::IsSingular::Response>      response,
                                     MDWArmTypeMask                                                    arm_type);
        void service_for_jacobian_matrix(const std::shared_ptr<::upperlimb_msgs::srv::JacobianMatrixGet::Request> request,
                                         std::shared_ptr<::upperlimb_msgs::srv::JacobianMatrixGet::Response>      response);
        void service_for_motion_lists(const std::shared_ptr<::upperlimb_msgs::srv::FilesLists::Request> request,
                                      std::shared_ptr<::upperlimb_msgs::srv::FilesLists::Response>      response);
        void service_for_load_motion(const std::shared_ptr<::upperlimb_msgs::srv::MotionsManage::Request> request,
                                     std::shared_ptr<::upperlimb_msgs::srv::MotionsManage::Response>      response);
        void service_for_unload_motion(const std::shared_ptr<::upperlimb_msgs::srv::MotionsManage::Request> request,
                                       std::shared_ptr<::upperlimb_msgs::srv::MotionsManage::Response>      response);
        void service_for_loaded_motions(const std::shared_ptr<::upperlimb_msgs::srv::MotionsLoadedList::Request> request,
                                        std::shared_ptr<::upperlimb_msgs::srv::MotionsLoadedList::Response>      response);
        void service_for_safety_lock(std::shared_ptr<std_srvs::srv::Trigger::Request>  request,
                                     std::shared_ptr<std_srvs::srv::Trigger::Response> response,
                                     bool                                              unlock);
        void service_for_get_payload(const std::shared_ptr<::upperlimb_msgs::srv::PayLoadGet::Request> request,
                                     std::shared_ptr<::upperlimb_msgs::srv::PayLoadGet::Response>      response);
        void service_for_set_payload(const std::shared_ptr<::upperlimb_msgs::srv::PayLoadSet::Request> request,
                                     std::shared_ptr<::upperlimb_msgs::srv::PayLoadSet::Response>      response);
        void service_for_collision_detection(const std::shared_ptr<std_srvs::srv::SetBool::Request> request,
                                             std::shared_ptr<std_srvs::srv::SetBool::Response>      response);
        void service_for_collision_detection_is_enable(std::shared_ptr<std_srvs::srv::Trigger::Request>  request,
                                                       std::shared_ptr<std_srvs::srv::Trigger::Response> response);
        void service_for_collision_detection_set_params(const std::shared_ptr<::upperlimb_msgs::srv::ParamsSet::Request> request,
                                                        std::shared_ptr<::upperlimb_msgs::srv::ParamsSet::Response>      response);
        void service_for_collision_detection_get_params(const std::shared_ptr<::upperlimb_msgs::srv::ParamsGet::Request> request,
                                                        std::shared_ptr<::upperlimb_msgs::srv::ParamsGet::Response>      response);
        void service_for_cartesian_planning_get(const std::shared_ptr<::upperlimb_msgs::srv::CartesianPlanningParamsGet::Request> request,
                                                std::shared_ptr<::upperlimb_msgs::srv::CartesianPlanningParamsGet::Response>      response);
        void service_for_cartesian_planning_set(const std::shared_ptr<::upperlimb_msgs::srv::CartesianPlanningParamsSet::Request> request,
                                                std::shared_ptr<::upperlimb_msgs::srv::CartesianPlanningParamsSet::Response>      response);
        void service_for_teach_stop_record(const std::shared_ptr<std_srvs::srv::Trigger::Request> request,
                                           std::shared_ptr<std_srvs::srv::Trigger::Response>      response);
        void service_for_teach_lists(const std::shared_ptr<::upperlimb_msgs::srv::FilesLists::Request> request,
                                     std::shared_ptr<::upperlimb_msgs::srv::FilesLists::Response>      response);

        // action callback
        rclcpp_action::GoalResponse   action_for_execute_motion_goal(const rclcpp_action::GoalUUID& uuid, std::shared_ptr<const MotionExecute::Goal> goal);
        rclcpp_action::CancelResponse action_for_execute_motion_cancel(const std::shared_ptr<MotionExecuteGoalHandle> goal_handle);
        void                          action_for_execute_motion_accepted(const std::shared_ptr<MotionExecuteGoalHandle> goal_handle);
        void                          action_for_execute_motion(const std::shared_ptr<MotionExecuteGoalHandle> goal_handle);

        rclcpp_action::GoalResponse   action_for_teach_record_goal(const rclcpp_action::GoalUUID& uuid, std::shared_ptr<const DragTeachRecord::Goal> goal);
        rclcpp_action::CancelResponse action_for_teach_record_cancel(const std::shared_ptr<DragTeachRecordGoalHandle> goal_handle);
        void                          action_for_teach_record_accepted(const std::shared_ptr<DragTeachRecordGoalHandle> goal_handle);
        void                          action_for_teach_record(const std::shared_ptr<DragTeachRecordGoalHandle> goal_handle);

        rclcpp_action::GoalResponse   action_for_teach_replay_goal(const rclcpp_action::GoalUUID& uuid, std::shared_ptr<const DragTeachReplay::Goal> goal);
        rclcpp_action::CancelResponse action_for_teach_replay_cancel(const std::shared_ptr<DragTeachReplayGoalHandle> goal_handle);
        void                          action_for_teach_replay_accepted(const std::shared_ptr<DragTeachReplayGoalHandle> goal_handle);
        void                          action_for_teach_replay(const std::shared_ptr<DragTeachReplayGoalHandle> goal_handle);

        std::unique_ptr<IController>      controller_{nullptr};
        std::unique_ptr<app::AppFacade>   app_facade_{nullptr};
        std::unique_ptr<ZmqPlotPublisher> zmq_plot_publisher_{nullptr};
        app::IddpReadyCallback            iddp_ready_callback_{};
        config::UpperlimbConfig           config_{};
        domain::RobotProfile              robot_profile_{};
        std::atomic<bool>                 publish_enabled_{false};
        std::atomic<bool>                 loop_running_{false};
        std::string                       package_version_;
        UplimbInterfaceWrapper*           wrapper_{nullptr};
        rclcpp_lifecycle::LifecycleNode*  node_{nullptr};
        std::thread                       pub_thread_;
        std::atomic<bool>                 teach_recording_{false};
        std::atomic<bool>                 teach_record_stop_requested_{false};
        bool                              dependencies_configured_{false};
        bool                              callback_registered_{false};
        zj_humanoid::log::ModuleLogger    logger_;
    };
}  // namespace zj_humanoid::upperlimb
