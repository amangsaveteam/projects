#pragma once

#include <string>

namespace zj_humanoid::upperlimb::domain
{
    class FileNameService
    {
    public:
        static std::string generate_date_string();
        static std::string generate_random_file_name(const std::string& prefix = "");
    };

}  // namespace zj_humanoid::upperlimb::domain
