#pragma once

#include <actionlib/server/simple_action_server.h>
#include <geometry_msgs/WrenchStamped.h>
#include <ros/advertise_service_options.h>
#include <ros/callback_queue.h>
#include <ros/node_handle.h>
#include <ros/publisher.h>
#include <ros/service_server.h>
#include <ros/subscriber.h>
#include <sensor_msgs/JointState.h>
#include <std_msgs/Float64MultiArray.h>
#include <std_msgs/Int8.h>
#include <std_srvs/SetBool.h>
#include <std_srvs/Trigger.h>
#include <upperlimb/ArmType.h>
#include <upperlimb/BasicInfoGet.h>
#include <upperlimb/CartesianPlanningParamsGet.h>
#include <upperlimb/CartesianPlanningParamsSet.h>
#include <upperlimb/DragTeachRecordAction.h>
#include <upperlimb/DragTeachReplayAction.h>
#include <upperlimb/DualPose.h>
#include <upperlimb/FK.h>
#include <upperlimb/FilesLists.h>
#include <upperlimb/IK.h>
#include <upperlimb/IsSingular.h>
#include <upperlimb/JacobianMatrixGet.h>
#include <upperlimb/Joints.h>
#include <upperlimb/MotionExecuteAction.h>
#include <upperlimb/MotionsLoadedList.h>
#include <upperlimb/MotionsManage.h>
#include <upperlimb/MoveJ.h>
#include <upperlimb/MoveJByPath.h>
#include <upperlimb/MoveJByPose.h>
#include <upperlimb/MoveL.h>
#include <upperlimb/MoveLByPath.h>
#include <upperlimb/ParamsGet.h>
#include <upperlimb/ParamsSet.h>
#include <upperlimb/PayLoadGet.h>
#include <upperlimb/PayLoadSet.h>
#include <upperlimb/Pose.h>
#include <upperlimb/Servo.h>
#include <upperlimb/SpeedJ.h>
#include <upperlimb/SpeedL.h>
#include <upperlimb/TcpSpeed.h>
#include <upperlimb/UplimbState.h>

#include <array>
#include <atomic>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#include "ros/spinner.h"
#include "uplimb_interface/app/api.hpp"
#include "uplimb_interface/config/params.hpp"
#include "uplimb_interface/definitions.hpp"
#include "uplimb_interface/domain/model/profile.hpp"
#include "uplimb_interface/logging_helpers.hpp"
#include "uplimb_interface/plotjuggler.hpp"
#include "uplimb_interface/utils.hpp"
#include "uplimb_interface/wrapper/ros1/wrapper.hpp"

namespace zj_humanoid::upperlimb
{
    class Ros1UplimbInterfaceWrapper::Impl : public Ros1LifecycleNode
    {
    public:
        explicit Impl(const config::MDWProfileDTO& profiles);
        ~Impl();
        void register_iddp_ready_callback(app::IddpReadyCallback callback);

    private:
        CallbackReturn on_configure(const State& state) override;
        CallbackReturn on_activate(const State& state) override;
        CallbackReturn on_deactivate(const State& state) override;
        CallbackReturn on_cleanup(const State& state) override;
        CallbackReturn on_shutdown(const State& state) override;

        void loop();
        void register_callback();
        void activate_publishers();
        void deactivate_publishers();
        void init_ros_params();
        void init();
        void pre_configure();
        void post_configure();

        using MotionExecuteServer   = actionlib::SimpleActionServer<::upperlimb::MotionExecuteAction>;
        using DragTeachRecordServer = actionlib::SimpleActionServer<::upperlimb::DragTeachRecordAction>;
        using DragTeachReplayServer = actionlib::SimpleActionServer<::upperlimb::DragTeachReplayAction>;

        void publish_joint_states(sensor_msgs::JointState& msg);
        void publish_arm_tcp_pose(std::array<::upperlimb::Pose, 2>& msgs);
        void publish_arm_tcp_speed(::upperlimb::TcpSpeed& msg);
        void publish_robot_cmd_state(::upperlimb::UplimbState& msg);
        void publish_jacobian_matrix(std::array<std_msgs::Float64MultiArray, 2>& msgs);
        void publish_external_torque(std_msgs::Float64MultiArray& msg);
        void publish_waist_force_ext(geometry_msgs::WrenchStamped& msg);

        bool service_for_stop(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);
        bool service_for_version(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);
        bool service_for_basic_info(::upperlimb::BasicInfoGet::Request& request, ::upperlimb::BasicInfoGet::Response& response);
        bool service_for_go_home(::upperlimb::ArmType::Request& request, ::upperlimb::ArmType::Response& response);
        bool service_for_go_home_with_mask(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response, int mdw_arm_type);
        bool service_for_go_down(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response, int mdw_arm_type);
        bool service_for_movej(::upperlimb::MoveJ::Request& request, ::upperlimb::MoveJ::Response& response, int mdw_arm_type);
        bool service_for_movej_by_path(::upperlimb::MoveJByPath::Request& request, ::upperlimb::MoveJByPath::Response& response, int mdw_arm_type);
        bool service_for_movej_by_pose(::upperlimb::MoveJByPose::Request& request, ::upperlimb::MoveJByPose::Response& response, int mdw_arm_type);
        bool service_for_movel(::upperlimb::MoveL::Request& request, ::upperlimb::MoveL::Response& response, int mdw_arm_type);
        bool service_for_movel_by_path(::upperlimb::MoveLByPath::Request& request, ::upperlimb::MoveLByPath::Response& response, int mdw_arm_type);
        bool service_for_FK(::upperlimb::FK::Request& request, ::upperlimb::FK::Response& response, int mdw_arm_type);
        bool service_for_IK(::upperlimb::IK::Request& request, ::upperlimb::IK::Response& response, int mdw_arm_type);
        bool service_for_is_singular(::upperlimb::IsSingular::Request& request, ::upperlimb::IsSingular::Response& response, int mdw_arm_type);
        bool service_for_servo(::upperlimb::Servo::Request& request, ::upperlimb::Servo::Response& response, bool enable);
        bool service_for_enable_speedj(std_srvs::SetBool::Request& request, std_srvs::SetBool::Response& response);
        bool service_for_enable_speedl(std_srvs::SetBool::Request& request, std_srvs::SetBool::Response& response);
        bool service_for_teach_mode(::upperlimb::ArmType::Request& request, ::upperlimb::ArmType::Response& response, bool enable);
        bool service_for_motion_lists(::upperlimb::FilesLists::Request& request, ::upperlimb::FilesLists::Response& response);
        bool service_for_load_motion(::upperlimb::MotionsManage::Request& request, ::upperlimb::MotionsManage::Response& response);
        bool service_for_unload_motion(::upperlimb::MotionsManage::Request& request, ::upperlimb::MotionsManage::Response& response);
        bool service_for_loaded_motions(::upperlimb::MotionsLoadedList::Request& request, ::upperlimb::MotionsLoadedList::Response& response);
        bool service_for_get_payload(::upperlimb::PayLoadGet::Request& request, ::upperlimb::PayLoadGet::Response& response);
        bool service_for_set_payload(::upperlimb::PayLoadSet::Request& request, ::upperlimb::PayLoadSet::Response& response);
        bool service_for_collision_detection(std_srvs::SetBool::Request& request, std_srvs::SetBool::Response& response);
        bool service_for_collision_detection_is_enable(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);
        bool service_for_safety_lock(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response, bool unlock);
        bool service_for_collision_detection_set_params(::upperlimb::ParamsSet::Request& request, ::upperlimb::ParamsSet::Response& response);
        bool service_for_collision_detection_get_params(::upperlimb::ParamsGet::Request& request, ::upperlimb::ParamsGet::Response& response);
        bool service_for_teach_stop_record(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);
        bool service_for_teach_lists(::upperlimb::FilesLists::Request& request, ::upperlimb::FilesLists::Response& response);
        bool service_for_cartesian_planning_get(::upperlimb::CartesianPlanningParamsGet::Request&  request,
                                                ::upperlimb::CartesianPlanningParamsGet::Response& response);
        bool service_for_cartesian_planning_set(::upperlimb::CartesianPlanningParamsSet::Request&  request,
                                                ::upperlimb::CartesianPlanningParamsSet::Response& response);
        bool service_for_jacobian_matrix(::upperlimb::JacobianMatrixGet::Request& request, ::upperlimb::JacobianMatrixGet::Response& response);

        void suber_for_servoj(const ::upperlimb::Joints::ConstPtr& msg, int mdw_arm_type);
        void suber_for_speedj(const ::upperlimb::SpeedJ::ConstPtr& msg, int mdw_arm_type);
        void suber_for_speedl(const ::upperlimb::SpeedL::ConstPtr& msg, int mdw_arm_type);
        void suber_for_servol(const ::upperlimb::DualPose::ConstPtr& msg, int mdw_arm_type);
        void suber_for_uplimb_occupation(const std_msgs::Int8::ConstPtr& msg);

        void action_for_execute_motion(const ::upperlimb::MotionExecuteGoalConstPtr& goal);
        void action_for_teach_record(const ::upperlimb::DragTeachRecordGoalConstPtr& goal);
        void action_for_teach_replay(const ::upperlimb::DragTeachReplayGoalConstPtr& goal);

        ros::NodeHandle nh_{"upperlimb"};

        ros::CallbackQueue queue_for_stop_;
        ros::AsyncSpinner  spinner_for_stop_{1, &queue_for_stop_};

        std::unique_ptr<IController>      controller_{nullptr};
        std::unique_ptr<app::AppFacade>   app_facade_{nullptr};
        std::unique_ptr<ZmqPlotPublisher> zmq_plot_publisher_{nullptr};
        app::IddpReadyCallback            iddp_ready_callback_{};
        config::UpperlimbConfig           config_{};
        domain::RobotProfile              robot_profile_{};

        ros::Publisher puber_joint_states_;
        ros::Publisher puber_robot_cmd_state_;
        ros::Publisher puber_left_arm_tcp_pose_;
        ros::Publisher puber_right_arm_tcp_pose_;
        ros::Publisher puber_head2base_pose_;
        ros::Publisher puber_dual_arm_tcp_speed_;
        ros::Publisher puber_occupancy_state_;
        ros::Publisher puber_left_jacobian_matrix_;
        ros::Publisher puber_right_jacobian_matrix_;
        ros::Publisher puber_external_torque_;
        ros::Publisher puber_waist_force_ext_;

        std::vector<ros::Subscriber>           subers_;
        std::vector<ros::ServiceServer>        services_;
        std::unique_ptr<MotionExecuteServer>   aciton_execute_motion_;
        std::unique_ptr<DragTeachRecordServer> aciton_teach_record_;
        std::unique_ptr<DragTeachReplayServer> aciton_teach_replay_;
        std::thread                            pub_thread_;
        std::atomic<bool>                      publish_enabled_{false};
        std::atomic<bool>                      publish_loop_running_{false};
        std::atomic<bool>                      loop_running_{false};
        std::atomic<bool>                      teach_recording_{false};
        std::atomic<bool>                      teach_record_stop_requested_{false};
        bool                                   dependencies_configured_{false};
        bool                                   callback_registered_{false};
        std::string                            package_version_;
        zj_humanoid::log::ModuleLogger         logger_;
    };
}  // namespace zj_humanoid::upperlimb
