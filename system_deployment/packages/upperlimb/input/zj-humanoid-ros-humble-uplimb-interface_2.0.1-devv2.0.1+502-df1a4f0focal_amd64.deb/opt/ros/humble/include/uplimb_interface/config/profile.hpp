#pragma once

#include <string>
#include <string_view>
#include <vector>

#include "uplimb_interface/definitions.hpp"


/*

    - 不变的配置放到TOML中
    - 变化的配置放到ROS中



*/


namespace zj_humanoid::upperlimb::config
{

    struct RobotPartIndexConfig
    {
        enum class ValidationResult
        {
            Valid,
            Empty,
            Invalid,
        };

        std::vector<int> left;
        std::vector<int> right;
        std::vector<int> neck;
        std::vector<int> waist;
        std::vector<int> lifting;

        [[nodiscard]] std::size_t size() const;

        [[nodiscard]] RobotPartConfig to_robot_part_config() const;

        [[nodiscard]] ValidationResult validate() const;
    };

    struct CountdownConfigDTO
    {
        int accuracy_ms = 10;
        int timeout_ms  = 1000;

        void validate() const;
    };

    struct PathConfigDTO
    {
        double max_running_time = 1800.0;
    };

    struct RobotProfileDTO
    {
        std::vector<std::string> alias;
        RobotPartConfig          algo_num;
        RobotPartConfig          mdw_num;
        RobotPartIndexConfig     algo_index;
        RobotPartIndexConfig     mdw_index;
        RobotPartConfig          algo_mask;
        RobotPartConfig          mdw_mask = {static_cast<int>(MDWArmTypeMask::LeftArm),
                                             static_cast<int>(MDWArmTypeMask::RightArm),
                                             static_cast<int>(MDWArmTypeMask::Neck),
                                             static_cast<int>(MDWArmTypeMask::Waist),
                                             static_cast<int>(MDWArmTypeMask::Lifting)};
        std::vector<double>      left_down_pos;
        std::vector<double>      right_down_pos;
        int                      rtipc_define = -1;
        double                   max_payload  = 4.0;
        double                   max_joint_velocity     = 3.5;
        double                   max_joint_acceleration = 50.0;
        double                   max_lift_velocity      = 0.062;
        double                   max_lift_acceleration  = 10.0;
        double                   max_linear_velocity    = 0.5;
        double                   max_linear_acceleration = 5.0;

        void validate();
    };

    struct ToolLoadDTO
    {
        std::string           model;
        double                mass = 0.0;
        std::vector<double>   cog{0.0, 0.0, 0.0};
    };

    struct MDWProfileDTO
    {
        // std::string                  motions_folder = "/home/nav01/zj_humanoid/orin/motions/";
        // DragTeachRecordDTO           drag_teach_record;
        CountdownConfigDTO           countdown;
        PathConfigDTO                path;
        std::vector<ToolLoadDTO>     tool_loads;
        std::vector<RobotProfileDTO> robots;

        static MDWProfileDTO                 from_toml(const std::string& toml_path);
        [[nodiscard]] const RobotProfileDTO* find_robot_by_alias(std::string_view alias) const;
        [[nodiscard]] bool                   has_robot_by_alias(std::string_view alias) const;
        [[nodiscard]] int                    get_rtipc_define_by_alias(std::string_view alias) const;
        [[nodiscard]] const ToolLoadDTO*     find_tool_load_by_model(std::string_view model) const;
    };

    inline const RobotProfileDTO* MDWProfileDTO::find_robot_by_alias(const std::string_view alias) const
    {
        for (const RobotProfileDTO& robot_profile : this->robots)
        {
            for (const std::string& alias_item : robot_profile.alias)
            {
                if (std::string_view(alias_item) == alias)
                {
                    return &robot_profile;
                }
            }
        }
        return nullptr;
    }

    inline bool MDWProfileDTO::has_robot_by_alias(const std::string_view alias) const
    {
        return this->find_robot_by_alias(alias) != nullptr;
    }

    inline int MDWProfileDTO::get_rtipc_define_by_alias(const std::string_view alias) const
    {
        const RobotProfileDTO* robot_profile = this->find_robot_by_alias(alias);
        return robot_profile == nullptr ? -1 : robot_profile->rtipc_define;
    }

    inline const ToolLoadDTO* MDWProfileDTO::find_tool_load_by_model(const std::string_view model) const
    {
        for (const ToolLoadDTO& tool_load : this->tool_loads)
        {
            if (std::string_view(tool_load.model) == model)
            {
                return &tool_load;
            }
        }
        return nullptr;
    }

}  // namespace zj_humanoid::upperlimb::config
