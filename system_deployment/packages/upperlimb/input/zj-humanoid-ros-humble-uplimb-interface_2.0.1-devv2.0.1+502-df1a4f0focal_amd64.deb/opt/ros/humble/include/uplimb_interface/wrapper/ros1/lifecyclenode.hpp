
#pragma once

#include <mutex>

namespace zj_humanoid::upperlimb
{
    class Ros1LifecycleNode
    {
    public:
        enum class CallbackReturn
        {
            SUCCESS,
            FAILURE,
            ERROR
        };

        enum class State
        {
            UNCONFIGURED,
            INACTIVE,
            ACTIVE,
            FINALIZED
        };

        Ros1LifecycleNode()          = default;
        virtual ~Ros1LifecycleNode() = default;

        Ros1LifecycleNode(const Ros1LifecycleNode&)            = delete;
        Ros1LifecycleNode& operator=(const Ros1LifecycleNode&) = delete;

        Ros1LifecycleNode(Ros1LifecycleNode&& other) noexcept
        {
            const std::lock_guard<std::mutex> lock(other.mutex_);
            this->state_ = other.state_;
        }

        Ros1LifecycleNode& operator=(Ros1LifecycleNode&& other) noexcept
        {
            if (this == &other)
            {
                return *this;
            }

            const std::scoped_lock lock(this->mutex_, other.mutex_);
            this->state_ = other.state_;
            return *this;
        }

        CallbackReturn configure()
        {
            return this->transition(State::UNCONFIGURED, &Ros1LifecycleNode::on_configure, State::INACTIVE);
        }

        CallbackReturn activate()
        {
            return this->transition(State::INACTIVE, &Ros1LifecycleNode::on_activate, State::ACTIVE);
        }

        CallbackReturn deactivate()
        {
            return this->transition(State::ACTIVE, &Ros1LifecycleNode::on_deactivate, State::INACTIVE);
        }

        CallbackReturn cleanup()
        {
            return this->transition(State::INACTIVE, &Ros1LifecycleNode::on_cleanup, State::UNCONFIGURED);
        }

        CallbackReturn shutdown()
        {
            return this->transition_to_finalized(&Ros1LifecycleNode::on_shutdown);
        }

        State get_current_state() const
        {
            const std::lock_guard<std::mutex> lock(this->mutex_);
            return this->state_;
        }

    protected:
        virtual CallbackReturn on_configure(const State&)
        {
            return CallbackReturn::SUCCESS;
        }

        virtual CallbackReturn on_activate(const State&)
        {
            return CallbackReturn::SUCCESS;
        }

        virtual CallbackReturn on_deactivate(const State&)
        {
            return CallbackReturn::SUCCESS;
        }

        virtual CallbackReturn on_cleanup(const State&)
        {
            return CallbackReturn::SUCCESS;
        }

        virtual CallbackReturn on_shutdown(const State&)
        {
            return CallbackReturn::SUCCESS;
        }

    private:
        using Callback = CallbackReturn (Ros1LifecycleNode::*)(const State&);

        static bool is_transition_allowed(const State previous_state, const State next_state)
        {
            switch (previous_state)
            {
                case State::UNCONFIGURED:
                    return next_state == State::INACTIVE || next_state == State::FINALIZED;
                case State::INACTIVE:
                    return next_state == State::ACTIVE || next_state == State::UNCONFIGURED || next_state == State::FINALIZED;
                case State::ACTIVE:
                    return next_state == State::INACTIVE || next_state == State::FINALIZED;
                case State::FINALIZED:
                    return false;
            }
            return false;
        }

        CallbackReturn transition(const State expected_state, Callback callback, const State next_state)
        {
            {
                const std::lock_guard<std::mutex> lock(this->mutex_);
                if (this->state_ != expected_state || !is_transition_allowed(this->state_, next_state))
                {
                    return CallbackReturn::FAILURE;
                }
            }

            const CallbackReturn result = (this->*callback)(expected_state);
            if (result != CallbackReturn::SUCCESS)
            {
                return result;
            }

            const std::lock_guard<std::mutex> lock(this->mutex_);
            if (this->state_ != expected_state || !is_transition_allowed(this->state_, next_state))
            {
                return CallbackReturn::FAILURE;
            }
            this->state_ = next_state;
            return result;
        }

        CallbackReturn transition_to_finalized(Callback callback)
        {
            State previous_state;
            {
                const std::lock_guard<std::mutex> lock(this->mutex_);
                previous_state = this->state_;
                if (!is_transition_allowed(previous_state, State::FINALIZED))
                {
                    return CallbackReturn::FAILURE;
                }
            }

            const CallbackReturn result = (this->*callback)(previous_state);
            if (result != CallbackReturn::SUCCESS)
            {
                return result;
            }

            const std::lock_guard<std::mutex> lock(this->mutex_);
            if (this->state_ != previous_state || !is_transition_allowed(this->state_, State::FINALIZED))
            {
                return CallbackReturn::FAILURE;
            }
            this->state_ = State::FINALIZED;
            return result;
        }

        mutable std::mutex mutex_;
        State              state_{State::UNCONFIGURED};
    };
}  // namespace zj_humanoid::upperlimb
