#pragma once

#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <thread>

namespace zj_humanoid::upperlimb
{
    class ResettableTimer
    {
    public:
        using Callback = std::function<void()>;

        ResettableTimer(std::chrono::milliseconds accuracy, Callback callback, std::string thread_name = {});
        ~ResettableTimer();

        ResettableTimer(const ResettableTimer&)            = delete;
        ResettableTimer& operator=(const ResettableTimer&) = delete;
        ResettableTimer(ResettableTimer&&)                 = delete;
        ResettableTimer& operator=(ResettableTimer&&)      = delete;

        void start();
        void reset();
        void stop();

        [[nodiscard]] bool running() const;

    private:
        void run();

        std::chrono::milliseconds              accuracy_;
        Callback                               callback_;
        mutable std::mutex                     mutex_;
        std::condition_variable                cv_;
        std::thread                            thread_;
        std::chrono::steady_clock::time_point  deadline_{};
        std::uint64_t                          generation_{0};
        bool                                   running_{false};
        bool                                   shutdown_{false};
    };
}  // namespace zj_humanoid::upperlimb
