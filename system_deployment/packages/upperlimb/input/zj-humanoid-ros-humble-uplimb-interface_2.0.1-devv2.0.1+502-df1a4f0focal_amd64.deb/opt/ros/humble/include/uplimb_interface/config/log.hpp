#pragma once

#include <string>
#include <vector>

namespace zj_humanoid::upperlimb::config::log
{
    struct LoggingConfig
    {
        std::string name;
        std::vector<std::string> modules;
        std::string content;
    };

    LoggingConfig load_logging_config(const std::string& toml_path);
    LoggingConfig load_logging_config(const std::string& toml_path, const std::string& log_dir_parent);
}  // namespace zj_humanoid::upperlimb::config::log
