#pragma once

#include <string>
#include <vector>

#include "uplimb_interface/domain/model/h5_file.hpp"

namespace zj_humanoid::upperlimb::domain
{
    struct MotionFileData
    {
        std::string                      filename{};
        std::string                      alias{};
        int                              arm_type{0};
        std::vector<double>              first_joints{};
        long                             number{0};
        std::vector<int>                 dataset_lengths{};
        std::vector<std::vector<double>> data{};
    };

    class MotionFile : public H5File
    {
    public:
        explicit MotionFile(const std::string& file_path);

        DomainResultVoid           is_valid() const;
        DomainResult<MotionFileData> read_data(const std::string& alias = "") const;

        static const std::vector<std::string> dataset_paths;
    };

}  // namespace zj_humanoid::upperlimb::domain
