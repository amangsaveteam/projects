#pragma once

#include <logging.hpp>
#include <string_view>

#include "uplimb_interface/definitions.hpp"

namespace zj_humanoid::upperlimb::log_helper
{
    inline zj_humanoid::log::ModuleLogger module_logger(const std::string_view module_name)
    {
        const auto root_logger = zj_humanoid::log::Logging::get_logger(kUplimbLogName);
        if (root_logger == nullptr || !root_logger->is_valid() || root_logger->find_module_index(module_name) == root_logger->module_count())
        {
            return {};
        }
        return root_logger->module(module_name);
    }
}  // namespace zj_humanoid::upperlimb::log_helper
