#pragma once

#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "uplimb_interface/app/dto.hpp"
#include "uplimb_interface/app/result.hpp"
#include "uplimb_interface/config/profile.hpp"
#include "uplimb_interface/controller.hpp"
#include "uplimb_interface/domain/model/profile.hpp"

namespace zj_humanoid::upperlimb::config
{
    struct AlgoConfig;
}

namespace zj_humanoid::upperlimb::app
{
    using IddpReadyCallback = std::function<bool()>;

    class AppFacade
    {
    public:
        AppFacade(IController& controller, const domain::RobotProfile& robot_profile, const config::AlgoConfig& algo_config);
        ~AppFacade();

        AppFacade(const AppFacade&)            = delete;
        AppFacade& operator=(const AppFacade&) = delete;
        AppFacade(AppFacade&&) noexcept;
        AppFacade& operator=(AppFacade&&) noexcept;

        void          print_algo_version() const;
        void          register_iddp_ready_callback(IddpReadyCallback callback);
        AppResultVoid require_control_available(const std::string& operation) const;
        AppResultVoid require_high_frequency_idle(const std::string& operation) const;

        AppResultVoid go_home(int mdw_arm_type) const;
        AppResultVoid go_down(int mdw_arm_type) const;
        AppResultVoid movej_for_t(const MoveJRequest& request) const;
        AppResultVoid movej_for_v_acc(const MoveJRequest& request) const;
        AppResultVoid movej_by_path_for_total_time(const MoveJByPathRequest& request) const;
        AppResultVoid movej_by_path_for_timestamp(const MoveJByPathRequest& request) const;
        AppResultVoid movej_by_pose(const MoveJByPoseRequest& request) const;


        //
        AppResultVoid movel(const MoveLRequest& request) const;
        AppResultVoid movel_by_path(const MoveLByPathRequest& request) const;
        AppResultVoid servoj(const std::vector<double>& joints, int mdw_arm_type) const;
        AppResultVoid servol(const ServoLRequest& request) const;
        AppResultVoid speedj(const SpeedJRequest& request) const;
        AppResultVoid speedl(const SpeedLRequest& request) const;

        AppResultVoid enable_servo(int mdw_arm_type, int gain, double velocity, double acceleration, double time, double lookahead_time);
        AppResultVoid disable_servo();
        AppResultVoid enable_speedj(bool enable);
        AppResultVoid enable_speedl(bool enable);
        AppResultVoid stop();
        [[nodiscard]] const ServoSessionState& servo_state() const;
        [[nodiscard]] SpeedSessionState        speedj_state() const;
        [[nodiscard]] SpeedSessionState        speedl_state() const;
        [[nodiscard]] int8_t                   uplimb_occupation() const;
        void                                   timer_callback();

        AppResultVoid                  teach_mode(int mdw_arm_type, bool enable) const;
        AppResultVoid                  safety_lock(bool unlock) const;
        AppResult<PayloadDTO>          get_payload(int mdw_arm_type) const;
        AppResultVoid                  set_payload(const PayloadSetRequest& request);
        AppResultVoid                  set_hand_params(const HandParamsRequest& request);
        AppResultVoid                  set_collision_detection_state(bool enable);
        AppResult<bool>                get_collision_detection_state() const;
        AppResultVoid                  set_collision_detection_params(const ControllerParamsRequest& request) const;
        AppResult<std::vector<double>> get_collision_detection_params(int mdw_arm_type) const;
        AppResultVoid                  set_cartesian_planning_params(const CartesianPlanningParamsRequest& request);
        AppResult<std::vector<bool>>   get_cartesian_planning_params(int mdw_arm_type) const;
        AppResult<FKResponseDTO>       FK(const FKRequest& request) const;
        AppResult<IKResponseDTO>       IK(const IKRequest& request) const;
        AppResult<bool>                is_singular(const IsSingularRequest& request) const;

        AppResult<std::vector<std::string>>   motion_lists(const std::string& folder) const;
        AppResult<MotionInfoDTO>              load_motion(const MotionManageRequest& request);
        AppResultVoid                         unload_motion(const MotionManageRequest& request);
        AppResult<std::vector<MotionInfoDTO>> loaded_motions() const;
        AppResult<MotionInfoDTO>              loaded_motion(const std::string& name) const;
        AppResultVoid                         execute_loaded_motion(const std::string& name, bool asynchronous);
        AppResult<MotionExecutionStateDTO>    motion_execution_state() const;
        AppResult<std::vector<std::string>>   teach_lists(const TeachFileRequest& request) const;
        AppResult<TeachFileDataDTO>           read_teach_file(const TeachFileRequest& request) const;
        AppResultVoid                         write_teach_file(const TeachWriteFileRequest& request) const;
        AppResultVoid                         teach_stop_record();
        AppResult<ActionResultDTO>            teach_record(const TeachRecordRequest&          request,
                                                           const ActionCancelCallback&        cancel_requested,
                                                           const TeachRecordFeedbackCallback& feedback);
        AppResult<ActionResultDTO>            teach_replay(const TeachReplayRequest&            request,
                                                           const ActionCancelCallback&          cancel_requested,
                                                           const MotionExecuteFeedbackCallback& feedback);

        AppResult<PublishJointStateDTO> build_joint_state(const std::vector<std::string>& algo_joint_names) const;
        void                            get_snapshot(ArmState* state, ArmCMD* cmd, ArmVar* var) const;
        AppResult<ArmTcpPoseDTO>        get_arm_tcp_pose() const;
        AppResult<TcpSpeedDTO>          get_arm_tcp_speed() const;
        AppResult<RobotCmdStateDTO>     get_robot_cmd_state() const;
        AppResult<JacobianMatricesDTO>  get_jacobian_matrices() const;
        AppResult<JacobianMatricesDTO>  get_jacobian_matrices(int mdw_arm_type) const;
        AppResult<ExternalTorqueDTO>    get_external_torque(int mdw_arm_type) const;
        AppResult<WaistForceExtDTO>     get_waist_force_ext() const;
        AppResultVoid                   set_uplimb_occupation(int8_t status);

    private:
        class Impl;
        std::unique_ptr<Impl> impl_;
    };

}  // namespace zj_humanoid::upperlimb::app
