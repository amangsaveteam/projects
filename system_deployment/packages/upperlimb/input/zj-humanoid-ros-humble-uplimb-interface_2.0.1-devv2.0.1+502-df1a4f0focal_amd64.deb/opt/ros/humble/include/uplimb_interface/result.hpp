#pragma once

#include <string>
#include <utility>

namespace zj_humanoid::upperlimb
{
    template <typename T>
    struct [[nodiscard]] Result
    {
        bool        ok{false};
        std::string message{};
        T           value{};

        static Result<T> success(T value, std::string message = "ok")
        {
            return Result<T>{true, std::move(message), std::move(value)};
        }

        static Result<T> failure(std::string message)
        {
            return Result<T>{false, std::move(message), T{}};
        }
    };

    struct [[nodiscard]] Status
    {
        bool        ok{false};
        std::string message{};

        static Status success(std::string message = "ok")
        {
            return Status{true, std::move(message)};
        }

        static Status failure(std::string message)
        {
            return Status{false, std::move(message)};
        }
    };

}  // namespace zj_humanoid::upperlimb
