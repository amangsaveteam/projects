#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace zj_humanoid::upperlimb::config
{
    struct ScriptConfig;

    using LuaNumberTable = std::unordered_map<std::string, double>;

    class LuaRuntime
    {
    public:
        LuaRuntime();
        ~LuaRuntime();

        LuaRuntime(const LuaRuntime&)            = delete;
        LuaRuntime& operator=(const LuaRuntime&) = delete;

        void register_script(const ScriptConfig& script);

        LuaNumberTable evaluate(const std::string& script_id, const std::vector<double>& args);

    private:
        class Impl;
        std::unique_ptr<Impl> impl_;
    };
}  // namespace zj_humanoid::upperlimb::config
