/*
 * @Author       : Jay junjie.zhang@zj-humanoid.com
 * @Date         : 2026-03-21 13:48:28
 * @LastEditTime : 2026-03-22 19:17:12
 * @LastEditors  : Jay junjie.zhang@zj-humanoid.com
 * @Description  :
 */

#pragma once

#include <fmt/format.h>
#include <fmt/ranges.h>

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <magic_enum.hpp>
#include <pthread.h>
#include <pwd.h>
#include <sched.h>
#include <sstream>
#include <string>
#include <string_view>
#include <type_traits>
#include <unistd.h>
#include <stdexcept>
#include <vector>


namespace zj_humanoid::upperlimb::utils
{

    static constexpr double PI      = 3.14159265358979323846;
    static constexpr double DEG2RAD = PI / 180.0;
    static constexpr double RAD2DEG = 180.0 / PI;

    inline double deg_to_rad(double degress)
    {
        return degress * DEG2RAD;
    }

    inline double rad_to_deg(double radius)
    {
        return radius * RAD2DEG;
    }


    template <typename T>
    std::string value_to_string(const T& value)
    {
        if constexpr (std::is_same_v<std::decay_t<T>, const char*> ||
                      std::is_same_v<std::decay_t<T>, char*>)
        {
            return value == nullptr ? "null" : std::string(value);
        }
        else if constexpr (std::is_enum_v<std::decay_t<T>>)
        {
            const auto name = magic_enum::enum_name(value);
            if (!name.empty())
            {
                return std::string(name);
            }

            using Underlying = std::underlying_type_t<std::decay_t<T>>;
            return fmt::format("{}", static_cast<Underlying>(value));
        }
        else if constexpr (std::is_floating_point_v<std::decay_t<T>>)
        {
            return fmt::format("{:.6f}", value);
        }
        else
        {
            return fmt::format("{}", value);
        }
    }



    /**
     * @brief 倒计时
     * 
     */
    class Countdown
    {
    public:
        
        /**
         * @brief 倒计时时间 = 倒计时计数
         * 
         * @param count_down_time 倒计时计数 单位:ms 
         * @param accuracy        精度/刷新频率 单位:ms 
         */
        Countdown(int count_down_time, int accuracy, std::string name)
        {
            this->counter_ = count_down_time;
            this->accuracy_ = accuracy;
            this->name_ = name;
        };

        /**
         * @brief 每个周期进行触发
         * 
         */
        void trigger(int &value)
        {
            // std::lock_guard<std::mutex> lock(mutex_);
            if(this->current_t_ > 0)
            {
                this->current_t_ -= this->accuracy_;
                if (this->current_t_ <= 0)
                {
                    fmt::print(
                        "[DEBUG] Countdown trigger | {} is not refreshed within {} ms, It will be automatically set to 0\n",
                        this->name_,
                        this->counter_);
                    value = 0;
                }
            }
        };

        /**
         * @brief 重置倒计时
         * 
         */
        void set()
        {
            // std::lock_guard<std::mutex> lock(mutex_);
            // ROS_DEBUG_STREAM("Countdown set | " << this->name_);
            
            this->current_t_ = this->counter_;
            
        };

    
    private:
        int counter_;
        int accuracy_;
        int current_t_ = 0;
        std::string name_;
        // std::mutex mutex_;
    };




    struct Result
    {
        bool ok = false;
        std::string message;
    };




    // 服务回调包装器类 - 每个实例可以有自己的预检查函数
    template<typename RequestType, typename ResponseType>
    class ServiceCallbackWrapper {
    public:
        typedef std::function<bool(RequestType&, ResponseType&)> OriginalCallback;

    private:
        OriginalCallback original_callback_;
        std::string service_name_;
        std::function<Result()> precheck_function_;  // 每个包装器实例自己的预检查函数

    public:
        // 构造函数：传入服务名、原始回调和预检查函数
        ServiceCallbackWrapper(const std::string& service_name, OriginalCallback callback, std::function<Result()> precheck_func = nullptr)
                              : service_name_(service_name), original_callback_(callback), precheck_function_(precheck_func) {}

        // 重载函数调用操作符 - 让对象可以像函数一样被调用
        bool operator()(RequestType& req, ResponseType& resp) {
            // 执行预检查（如果设置了预检查函数）
            if (precheck_function_ ) {

                auto result = precheck_function_();
                if (!result.ok)
                {
                    // 将检查结果直接返回
                    resp.success = false;
                    resp.message = result.message;
                    fmt::println(stderr, "Pre-check failed for service : {} | {}", service_name_, resp.message);
                    return true; // 返回true表示服务调用成功处理了请求
                }
            }

            // 预检查通过，执行原始回调
            return original_callback_(req, resp);
        }

    };


    inline void zprint(const std::string &str, const std::string &delimiter = "\n")
    {
        if (delimiter.empty()) {
            throw std::invalid_argument("Delimiter cannot be an empty string.");
        }

        std::vector<std::string> tokens;
        size_t start = 0;
        size_t end = str.find(delimiter);
        while (end != std::string::npos) {
            tokens.push_back(str.substr(start, end - start));
            start = end + delimiter.length();
            end = str.find(delimiter, start);
        }
        // 添加最后一部分（如果有的话）
        if (!str.empty()) {
            tokens.push_back(str.substr(start));
        }

        size_t max_length = 0;
        for (size_t i = 0; i < tokens.size(); i++)
        {
            if (max_length < tokens[i].size())
            {
                max_length = tokens[i].size();
            }
        }

        fmt::println("{}", std::string(max_length + 6, '='));
        for (size_t i = 0; i < tokens.size(); i++)
        {
            fmt::println("|  {:<{}}  |", tokens[i], max_length);
        }
        fmt::println("{}", std::string(max_length + 6, '='));
    }

    inline std::string get_package_xml_version(const std::string& xml_path)
    {
        std::ifstream file(xml_path);
        if (!file.is_open())
        {
            return "Unknown";
        }

        std::stringstream buffer;
        buffer << file.rdbuf();
        file.close();

        const std::string xml_content = buffer.str();
        const std::string start_tag = "<version>";
        const std::string end_tag = "</version>";
        const size_t      start = xml_content.find(start_tag);
        if (start == std::string::npos)
        {
            return "Unknown";
        }
        const size_t version_start = start + start_tag.size();
        const size_t end = xml_content.find(end_tag, version_start);
        if (end == std::string::npos)
        {
            return "Unknown";
        }
        return xml_content.substr(version_start, end - version_start);
    }

    inline void set_thread_priority(pthread_t thread, int policy, int priority) {
        struct sched_param sch_params;
        sch_params.sched_priority = priority;

        if (pthread_setschedparam(thread, policy, &sch_params)) {
            fmt::println(stderr, "Failed to set thread scheduling: {}", std::strerror(errno));
        }
    }

    
    inline bool zchown(const char* filepath, const char* username="nav01")
    {
        // 1. 查找用户信息
        struct passwd* pw = getpwnam(username);
        if (!pw) {
            fmt::println(stderr, "User not found: {}", username);
            return false;
        }

        uid_t uid = pw->pw_uid;
        gid_t gid = pw->pw_gid;

        // 2. 修改归属
        if (chown(filepath, uid, gid) != 0) {
            fmt::println(stderr, "chown failed: {}", std::strerror(errno));
            return false;
        }

        return true;
    }

    // 使用示例
    // auto mode = Env::get<std::string>("MY_VAR", "default_value");
    // auto count = Env::get<int>("MY_COUNT", 10);
    // auto is_open = Env::get<bool>("IS_OPEN", false);
    class Env {
    public:
        template <typename T = std::string_view>
        static T get(const std::string& key, const T& default_value = T{})
        {
            const char* val = std::getenv(key.c_str());
            if (!val) {
                return default_value;
            }

            if constexpr (std::is_same_v<T, std::string_view> || std::is_same_v<T, std::string>) {
                return T{val};
            } else if constexpr (std::is_integral_v<T> && !std::is_same_v<T, bool>) {
                try { return static_cast<T>(std::stoll(val)); } catch(...) { return default_value; }
            } else if constexpr (std::is_floating_point_v<T>) {
                try { return static_cast<T>(std::stod(val)); } catch(...) { return default_value; }
            } else if constexpr (std::is_same_v<T, bool>) {
                std::string_view s{val};
                return (s == "1" || s == "true" || s == "TRUE" || s == "ON" || s == "on");
            } else {
                return T{val};
            }
        }
    };




}  // namespace zj_humanoid::upperlimb::utils
