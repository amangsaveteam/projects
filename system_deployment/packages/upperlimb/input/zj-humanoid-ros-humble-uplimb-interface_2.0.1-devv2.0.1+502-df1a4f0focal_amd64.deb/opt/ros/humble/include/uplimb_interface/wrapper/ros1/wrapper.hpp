#pragma once

#include <memory>
#include <string>

#include "uplimb_interface/app/api.hpp"
#include "uplimb_interface/config/profile.hpp"
#include "uplimb_interface/wrapper/ros1/lifecyclenode.hpp"

namespace zj_humanoid::upperlimb
{
    class Ros1UplimbInterfaceWrapper
    {
    public:
        using CallbackReturn = Ros1LifecycleNode::CallbackReturn;
        using State          = Ros1LifecycleNode::State;

        explicit Ros1UplimbInterfaceWrapper(const config::MDWProfileDTO& profiles);
        ~Ros1UplimbInterfaceWrapper();

        Ros1UplimbInterfaceWrapper(const Ros1UplimbInterfaceWrapper&)            = delete;
        Ros1UplimbInterfaceWrapper& operator=(const Ros1UplimbInterfaceWrapper&) = delete;
        Ros1UplimbInterfaceWrapper(Ros1UplimbInterfaceWrapper&&) noexcept;
        Ros1UplimbInterfaceWrapper& operator=(Ros1UplimbInterfaceWrapper&&) noexcept;

        CallbackReturn configure();
        CallbackReturn activate();
        CallbackReturn deactivate();
        CallbackReturn cleanup();
        CallbackReturn shutdown();
        void register_iddp_ready_callback(app::IddpReadyCallback callback);

    private:
        class Impl;
        std::unique_ptr<Impl> impl_;
    };
}  // namespace zj_humanoid::upperlimb
