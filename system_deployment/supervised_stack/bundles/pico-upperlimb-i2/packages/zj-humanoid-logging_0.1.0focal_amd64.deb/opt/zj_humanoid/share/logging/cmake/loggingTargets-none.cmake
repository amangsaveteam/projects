#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "log::logging" for configuration "None"
set_property(TARGET log::logging APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(log::logging PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/logging/liblogging.so"
  IMPORTED_SONAME_NONE "liblogging.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS log::logging )
list(APPEND _IMPORT_CHECK_FILES_FOR_log::logging "${_IMPORT_PREFIX}/lib/logging/liblogging.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
