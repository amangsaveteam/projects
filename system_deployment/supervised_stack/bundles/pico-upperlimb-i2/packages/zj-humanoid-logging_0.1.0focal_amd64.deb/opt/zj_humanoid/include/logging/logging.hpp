#pragma once

#include <bq_log/bq_log.h>

#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <experimental/source_location>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace zj_humanoid::log
{
    using source_location = std::experimental::source_location;

    enum class Level : int
    {
        Verbose = 0,
        Debug   = 10,
        Info    = 20,
        Warning = 30,
        Error   = 40,
        Fatal   = 50,
        Off     = 60
    };

    namespace detail
    {
        constexpr const char* source_file_basename(const char* path) noexcept
        {
            if (path == nullptr || path[0] == '\0')
            {
                return "-";
            }

            const char* file_name = path;
            for (const char* cursor = path; *cursor != '\0'; ++cursor)
            {
                if (*cursor == '/' || *cursor == '\\')
                {
                    file_name = cursor + 1;
                }
            }
            return file_name[0] == '\0' ? "-" : file_name;
        }

        class NativeCategoryLog : public bq::category_log
        {
        public:
            NativeCategoryLog();

            static NativeCategoryLog create(const std::string& log_name, const std::string& config);
            static NativeCategoryLog create(const std::string& log_name, const std::string& config, const std::vector<std::string>& module_names);

            template <typename STR>
            bool write(uint32_t category_index, bq::log_level level, const STR& content) const
            {
                return do_log(category_index, level, content);
            }

            template <typename STR, typename... Args>
            bool write(uint32_t category_index, bq::log_level level, const STR& format, const Args&... args) const
            {
                return do_log(category_index, level, format, args...);
            }

        private:
            explicit NativeCategoryLog(const bq::log& log);
        };

        constexpr bq::log_level to_native_level(Level level)
        {
            switch (level)
            {
                case Level::Verbose:
                    return bq::log_level::verbose;
                case Level::Debug:
                    return bq::log_level::debug;
                case Level::Info:
                    return bq::log_level::info;
                case Level::Warning:
                    return bq::log_level::warning;
                case Level::Error:
                    return bq::log_level::error;
                case Level::Fatal:
                    return bq::log_level::fatal;
                case Level::Off:
                    return bq::log_level::fatal;
            }
            return bq::log_level::fatal;
        }
    }  // namespace detail

    struct LogContext
    {
        std::string_view fmt_str;
        source_location  loc;

        LogContext(const char* format_string, source_location location = source_location::current()) : fmt_str(format_string), loc(location)
        {
        }

        LogContext(std::string_view format_string, source_location location = source_location::current()) : fmt_str(format_string), loc(location)
        {
        }

        LogContext(const std::string& format_string, source_location location = source_location::current()) : fmt_str(format_string), loc(location)
        {
        }
    };

    class LogOnceScope
    {
    public:
        LogOnceScope()
        {
            ++epoch();
            ++depth();
        }

        ~LogOnceScope()
        {
            --depth();
        }

        LogOnceScope(const LogOnceScope&)            = delete;
        LogOnceScope& operator=(const LogOnceScope&) = delete;

        static bool should_log(uint64_t& call_site_epoch)
        {
            if (depth() == 0)
            {
                return false;
            }

            const auto current_epoch = epoch();
            if (call_site_epoch == current_epoch)
            {
                return false;
            }
            call_site_epoch = current_epoch;
            return true;
        }

    private:
        static uint64_t& epoch()
        {
            static thread_local uint64_t value = 0;
            return value;
        }

        static uint64_t& depth()
        {
            static thread_local uint64_t value = 0;
            return value;
        }
    };

    class ModuleLogger;

    class Logging
    {
    public:
        explicit Logging(std::string name, std::string config = default_config());
        Logging(std::string name, std::string config, std::vector<std::string> module_names);
        ~Logging();

        Logging(const Logging&)            = delete;
        Logging& operator=(const Logging&) = delete;
        Logging(Logging&&) noexcept;
        Logging& operator=(Logging&&) noexcept;

        static std::shared_ptr<Logging> create(std::string name, std::string config = default_config());
        static std::shared_ptr<Logging> create(std::string name, std::string config, std::vector<std::string> module_names);
        static std::shared_ptr<Logging> get_logger(std::string name, std::string config = default_config());
        static std::shared_ptr<Logging> get_logger(std::string name, std::string config, std::vector<std::string> module_names);
        static std::string               default_config();
        static void                      force_flush_all();

        const std::string& name() const;
        bool               is_valid() const;
        size_t             module_count() const;
        std::string        module_name(size_t index) const;
        size_t             find_module_index(std::string_view name) const;

        void  set_level(Level level);
        Level level() const;
        bool  should_log(Level level) const;

        void force_flush();

        template <typename... Args>
        void log(Level level, LogContext context, Args&&... args)
        {
            log_native(level, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void log_with_location_prefix(Level level, std::string_view format, const char* file, uint32_t line, Args&&... args)
        {
            log_native_with_location_prefix(0, level, format, file, line, std::forward<Args>(args)...);
        }

        ModuleLogger module(std::string_view name);

        template <typename... Args>
        void verbose(LogContext context, Args&&... args)
        {
            log_native(Level::Verbose, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void debug(LogContext context, Args&&... args)
        {
            log_native(Level::Debug, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void info(LogContext context, Args&&... args)
        {
            log_native(Level::Info, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void warning(LogContext context, Args&&... args)
        {
            log_native(Level::Warning, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void error(LogContext context, Args&&... args)
        {
            log_native(Level::Error, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void fatal(LogContext context, Args&&... args)
        {
            log_native(Level::Fatal, context, std::forward<Args>(args)...);
        }

    private:
        friend class ModuleLogger;

        const detail::NativeCategoryLog& native_logger() const;
        bool                             has_module_index(uint32_t module_index) const;
        uint32_t                         to_category_index(uint32_t module_index) const;

        template <typename... Args>
        void write_native(uint32_t module_index, Level level, std::string_view format, Args&&... args)
        {
            if (level == Level::Off)
            {
                return;
            }
            native_logger().write(module_index, detail::to_native_level(level), format, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void write_native(Level level, std::string_view format, Args&&... args)
        {
            write_native(0, level, format, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void log_native(uint32_t module_index, Level level, LogContext context, Args&&... args)
        {
            if (!should_log(level) || !is_valid())
            {
                return;
            }
            std::string format;
            format.reserve(context.fmt_str.size() + 10);
            format.append("{}:{} | ");
            format.append(context.fmt_str.data(), context.fmt_str.size());
            write_native(
                module_index,
                level,
                format,
                detail::source_file_basename(context.loc.file_name()),
                context.loc.line(),
                std::forward<Args>(args)...);
        }

        template <typename... Args>
        void log_native_with_location_prefix(uint32_t module_index, Level level, std::string_view format, const char* file, uint32_t line, Args&&... args)
        {
            if (!should_log(level) || !is_valid())
            {
                return;
            }
            write_native(module_index, level, format, detail::source_file_basename(file), line, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void log_native(Level level, LogContext context, Args&&... args)
        {
            log_native(0, level, context, std::forward<Args>(args)...);
        }

        class Impl;
        std::unique_ptr<Impl> impl_;
    };

    class ModuleLogger
    {
    public:
        ModuleLogger() = default;

        uint32_t module_index() const
        {
            return module_index_;
        }

        template <typename... Args>
        void verbose(LogContext context, Args&&... args)
        {
            log(Level::Verbose, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void debug(LogContext context, Args&&... args)
        {
            log(Level::Debug, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void info(LogContext context, Args&&... args)
        {
            log(Level::Info, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void warning(LogContext context, Args&&... args)
        {
            log(Level::Warning, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void error(LogContext context, Args&&... args)
        {
            log(Level::Error, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void fatal(LogContext context, Args&&... args)
        {
            log(Level::Fatal, context, std::forward<Args>(args)...);
        }

        template <typename... Args>
        void log_with_location_prefix(Level level, std::string_view format, const char* file, uint32_t line, Args&&... args)
        {
            if (logger_ == nullptr)
            {
                return;
            }
            logger_->log_native_with_location_prefix(module_index_, level, format, file, line, std::forward<Args>(args)...);
        }

    private:
        friend class Logging;

        ModuleLogger(Logging* logger, uint32_t module_index) : logger_(logger), module_index_(module_index)
        {
        }

        template <typename... Args>
        void log(Level level, LogContext context, Args&&... args)
        {
            if (logger_ == nullptr)
            {
                return;
            }
            logger_->log_native(module_index_, level, context, std::forward<Args>(args)...);
        }

        Logging* logger_ = nullptr;
        uint32_t  module_index_ = 0;
    };

}  // namespace zj_humanoid::log

#define LOGGING_LOCATION_FORMAT(format_string) "{}:{} | " format_string

#define LOGGING_LOG(logger, method, format_string, ...) \
    do \
    { \
        (logger)->log_with_location_prefix(method, LOGGING_LOCATION_FORMAT(format_string), __FILE__, __LINE__, ##__VA_ARGS__); \
    } while (false)

#define LOGGING_LOG_COND(logger, method, condition, format_string, ...) \
    do \
    { \
        if (condition) \
        { \
            LOGGING_LOG(logger, method, format_string, ##__VA_ARGS__); \
        } \
    } while (false)

#define LOGGING_LOG_ONCE(logger, method, format_string, ...) \
    do \
    { \
        static std::atomic_bool logging_once_logged{false}; \
        bool                    logging_once_expected = false; \
        if (logging_once_logged.compare_exchange_strong(logging_once_expected, true, std::memory_order_relaxed)) \
        { \
            LOGGING_LOG(logger, method, format_string, ##__VA_ARGS__); \
        } \
    } while (false)

#define LOGGING_LOG_SCOPE_ONCE(logger, method, format_string, ...) \
    do \
    { \
        static thread_local uint64_t logging_scope_once_epoch = 0; \
        if (zj_humanoid::log::LogOnceScope::should_log(logging_scope_once_epoch)) \
        { \
            LOGGING_LOG(logger, method, format_string, ##__VA_ARGS__); \
        } \
    } while (false)

#define LOGGING_LOG_THROTTLE(logger, method, period, format_string, ...) \
    do \
    { \
        using logging_throttle_clock = std::chrono::steady_clock; \
        static std::atomic<int64_t> logging_throttle_last_ns{0}; \
        const auto                  logging_throttle_period_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(period).count(); \
        if (logging_throttle_period_ns <= 0) \
        { \
            LOGGING_LOG(logger, method, format_string, ##__VA_ARGS__); \
        } \
        else \
        { \
            const auto logging_throttle_now_ns = \
                std::chrono::duration_cast<std::chrono::nanoseconds>(logging_throttle_clock::now().time_since_epoch()).count(); \
            auto logging_throttle_last_ns_value = logging_throttle_last_ns.load(std::memory_order_relaxed); \
            if (logging_throttle_now_ns - logging_throttle_last_ns_value >= logging_throttle_period_ns && \
                logging_throttle_last_ns.compare_exchange_strong( \
                    logging_throttle_last_ns_value, logging_throttle_now_ns, std::memory_order_relaxed)) \
            { \
                LOGGING_LOG(logger, method, format_string, ##__VA_ARGS__); \
            } \
        } \
    } while (false)

#define LOGGING_ONCE_SCOPE(name) [[maybe_unused]] zj_humanoid::log::LogOnceScope name

#define LOGGING_VERBOSE(logger, format_string, ...) LOGGING_LOG(logger, zj_humanoid::log::Level::Verbose, format_string, ##__VA_ARGS__)
#define LOGGING_DEBUG(logger, format_string, ...) LOGGING_LOG(logger, zj_humanoid::log::Level::Debug, format_string, ##__VA_ARGS__)
#define LOGGING_INFO(logger, format_string, ...) LOGGING_LOG(logger, zj_humanoid::log::Level::Info, format_string, ##__VA_ARGS__)
#define LOGGING_WARNING(logger, format_string, ...) LOGGING_LOG(logger, zj_humanoid::log::Level::Warning, format_string, ##__VA_ARGS__)
#define LOGGING_ERROR(logger, format_string, ...) LOGGING_LOG(logger, zj_humanoid::log::Level::Error, format_string, ##__VA_ARGS__)
#define LOGGING_FATAL(logger, format_string, ...) LOGGING_LOG(logger, zj_humanoid::log::Level::Fatal, format_string, ##__VA_ARGS__)

#define LOGGING_VERBOSE_COND(logger, condition, format_string, ...) LOGGING_LOG_COND(logger, zj_humanoid::log::Level::Verbose, condition, format_string, ##__VA_ARGS__)
#define LOGGING_DEBUG_COND(logger, condition, format_string, ...) LOGGING_LOG_COND(logger, zj_humanoid::log::Level::Debug, condition, format_string, ##__VA_ARGS__)
#define LOGGING_INFO_COND(logger, condition, format_string, ...) LOGGING_LOG_COND(logger, zj_humanoid::log::Level::Info, condition, format_string, ##__VA_ARGS__)
#define LOGGING_WARNING_COND(logger, condition, format_string, ...) LOGGING_LOG_COND(logger, zj_humanoid::log::Level::Warning, condition, format_string, ##__VA_ARGS__)
#define LOGGING_ERROR_COND(logger, condition, format_string, ...) LOGGING_LOG_COND(logger, zj_humanoid::log::Level::Error, condition, format_string, ##__VA_ARGS__)
#define LOGGING_FATAL_COND(logger, condition, format_string, ...) LOGGING_LOG_COND(logger, zj_humanoid::log::Level::Fatal, condition, format_string, ##__VA_ARGS__)

#define LOGGING_VERBOSE_ONCE(logger, format_string, ...) LOGGING_LOG_ONCE(logger, zj_humanoid::log::Level::Verbose, format_string, ##__VA_ARGS__)
#define LOGGING_DEBUG_ONCE(logger, format_string, ...) LOGGING_LOG_ONCE(logger, zj_humanoid::log::Level::Debug, format_string, ##__VA_ARGS__)
#define LOGGING_INFO_ONCE(logger, format_string, ...) LOGGING_LOG_ONCE(logger, zj_humanoid::log::Level::Info, format_string, ##__VA_ARGS__)
#define LOGGING_WARNING_ONCE(logger, format_string, ...) LOGGING_LOG_ONCE(logger, zj_humanoid::log::Level::Warning, format_string, ##__VA_ARGS__)
#define LOGGING_ERROR_ONCE(logger, format_string, ...) LOGGING_LOG_ONCE(logger, zj_humanoid::log::Level::Error, format_string, ##__VA_ARGS__)
#define LOGGING_FATAL_ONCE(logger, format_string, ...) LOGGING_LOG_ONCE(logger, zj_humanoid::log::Level::Fatal, format_string, ##__VA_ARGS__)

#define LOGGING_VERBOSE_SCOPE_ONCE(logger, format_string, ...) LOGGING_LOG_SCOPE_ONCE(logger, zj_humanoid::log::Level::Verbose, format_string, ##__VA_ARGS__)
#define LOGGING_DEBUG_SCOPE_ONCE(logger, format_string, ...) LOGGING_LOG_SCOPE_ONCE(logger, zj_humanoid::log::Level::Debug, format_string, ##__VA_ARGS__)
#define LOGGING_INFO_SCOPE_ONCE(logger, format_string, ...) LOGGING_LOG_SCOPE_ONCE(logger, zj_humanoid::log::Level::Info, format_string, ##__VA_ARGS__)
#define LOGGING_WARNING_SCOPE_ONCE(logger, format_string, ...) LOGGING_LOG_SCOPE_ONCE(logger, zj_humanoid::log::Level::Warning, format_string, ##__VA_ARGS__)
#define LOGGING_ERROR_SCOPE_ONCE(logger, format_string, ...) LOGGING_LOG_SCOPE_ONCE(logger, zj_humanoid::log::Level::Error, format_string, ##__VA_ARGS__)
#define LOGGING_FATAL_SCOPE_ONCE(logger, format_string, ...) LOGGING_LOG_SCOPE_ONCE(logger, zj_humanoid::log::Level::Fatal, format_string, ##__VA_ARGS__)

#define LOGGING_VERBOSE_THROTTLE(logger, period, format_string, ...) LOGGING_LOG_THROTTLE(logger, zj_humanoid::log::Level::Verbose, period, format_string, ##__VA_ARGS__)
#define LOGGING_DEBUG_THROTTLE(logger, period, format_string, ...) LOGGING_LOG_THROTTLE(logger, zj_humanoid::log::Level::Debug, period, format_string, ##__VA_ARGS__)
#define LOGGING_INFO_THROTTLE(logger, period, format_string, ...) LOGGING_LOG_THROTTLE(logger, zj_humanoid::log::Level::Info, period, format_string, ##__VA_ARGS__)
#define LOGGING_WARNING_THROTTLE(logger, period, format_string, ...) LOGGING_LOG_THROTTLE(logger, zj_humanoid::log::Level::Warning, period, format_string, ##__VA_ARGS__)
#define LOGGING_ERROR_THROTTLE(logger, period, format_string, ...) LOGGING_LOG_THROTTLE(logger, zj_humanoid::log::Level::Error, period, format_string, ##__VA_ARGS__)
#define LOGGING_FATAL_THROTTLE(logger, period, format_string, ...) LOGGING_LOG_THROTTLE(logger, zj_humanoid::log::Level::Fatal, period, format_string, ##__VA_ARGS__)
