#ifndef _RTIPC_COMMON_H_
#define _RTIPC_COMMON_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>
/**
 * @brief 机器人类型
 */
// typedef enum
// {
//     ROBOT_TYPE_ARM,
//     ROBOT_TYPE_HAND
// } ROBOT_TYPE_ENUM;
#define IDDP_TYPE_ARM 0
#define IDDP_TYPE_LEG 1
#define XDDP_TYPE_CMD 2
#define XDDP_TYPE_HAND 3
#define IDDP_TYPE_FULL 4
#define IDDP_TYPE_NONE 5
#define IDDP_TYPE_WHOLE 6
#define XDDP_TYPE_CLAMP 7
#define XDDP_TYPE_F5D6_PRO_HAND 8
#define ROBOT_TYPE ROBOT_TYPE_VALUE

#define MAX_BUFFER_SIZE 4096 ///< 宏定义，协议最大缓冲区大小
  /**
   * @brief  枚举,机器人关节CIA402模式类型
   */
  typedef enum
  {
    JOINT_COE_MODE_PP = 0x01,  ///< PP位控模式
    JOINT_COE_MODE_PV = 0x03,  ///< PV速控模式
    JOINT_COE_MODE_PT = 0x04,  ///< PT力控模式
    JOINT_COE_MODE_CSP = 0x08, ///< CSP位控模式
    JOINT_COE_MODE_CSV = 0x09, ///< CSV速控模式
    JOINT_COE_MODE_CST = 0x0A, ///< CST力控模式
  } AL_COMMON_JOINT_COE_MODE_ENUM;

///////////////////////////////////////////////////////////////////////
#if (ROBOT_TYPE == XDDP_TYPE_HAND)
#define PD_HAND_SENSOR_FINGER_MAX_NUM 6 ///< 宏定义，手爪手指关节总数量
#define PD_HAND_SENSOR_SENSOR_MAX_NUM 6 ///< 宏定义，手爪手指关节总数量

#define PD_HAND_SENSOR_MAX_NUM 2  ///< 宏定义，手爪从站总数量
#define PD_FORCE_SENSOR_MAX_NUM 2 ///< 宏定义，力传感器总数量

#pragma pack(2)
  /**
   * @brief  结构体，机器人手爪网络下发数据结构体定义
   */
  typedef struct
  {
    float uploadPos[PD_HAND_SENSOR_FINGER_MAX_NUM];
    float uploadCur[PD_HAND_SENSOR_FINGER_MAX_NUM];
    float uploadPres[PD_HAND_SENSOR_SENSOR_MAX_NUM];
  } AL_ROBOT_HAND_UPLOAD_DATA_STRUCT;

  /**
   * @brief  结构体，机器人手爪网络下发数据结构体定义
   */
  typedef struct
  {
    float downloadPos[PD_HAND_SENSOR_FINGER_MAX_NUM];
    unsigned short downloadTime[PD_HAND_SENSOR_FINGER_MAX_NUM];
    float downloadVol[PD_HAND_SENSOR_FINGER_MAX_NUM];
  } AL_ROBOT_HAND_DOWNLOAD_DATA_STRUCT;

  /**
   * @brief  结构体，机器人力传感器上传数据结构体定义
   */
  typedef struct
  {
    unsigned short dataNum; ///< 实际位置值
    float fx;               ///< X轴方向的力
    float fy;               ///< Y轴方向的力
    float fz;               ///< Z轴方向的力
    float mx;               ///< X轴方向的扭矩
    float my;               ///< Y轴方向的扭矩
    float mz;               ///< Z轴方向的扭矩
  } AL_ROBOT_HAND_FORCE_INFO_STRUCT;

  /**
   * @brief  结构体，机器人力传感器下发数据结构体定义
   */
  typedef struct
  {
    unsigned short para1; ///< 力传感器参数1
    short para2;          ///< 力传感器参数2
    short para3;          ///< 力传感器参数3
  } AL_ROBOT_HAND_FORCE_CONTROL_STRUCT;
#pragma pack()

  /**
   * @brief  结构体，机器人手爪网络上传数据信息结构体定义
   */

  typedef struct
  {
    AL_ROBOT_HAND_UPLOAD_DATA_STRUCT uploadDataStruct[PD_HAND_SENSOR_MAX_NUM];
    AL_ROBOT_HAND_FORCE_INFO_STRUCT forceInfoStruct[PD_FORCE_SENSOR_MAX_NUM];
  } AL_ROBOT_HAND_UPLOAD_DATA_INFO_STRUCT;

  /**
   * @brief  结构体，机器人手爪网络下发数据信息结构体定义
   */
  typedef struct
  {
    AL_ROBOT_HAND_DOWNLOAD_DATA_STRUCT downloadDataStruct[PD_HAND_SENSOR_MAX_NUM];
    AL_ROBOT_HAND_FORCE_CONTROL_STRUCT
    forceControlStruct[PD_FORCE_SENSOR_MAX_NUM];
  } AL_ROBOT_HAND_DOWNLOAD_DATA_INFO_STRUCT;

  typedef struct
  {
    AL_ROBOT_HAND_UPLOAD_DATA_STRUCT uploadDataStruct[PD_HAND_SENSOR_MAX_NUM];
  } PD_ROBOT_HAND_UPLOAD_DATA_INFO_STRUCT;
  typedef struct
  {
    AL_ROBOT_HAND_DOWNLOAD_DATA_STRUCT downloadDataStruct[PD_HAND_SENSOR_MAX_NUM];
  } PD_ROBOT_HAND_DOWNLOAD_DATA_INFO_STRUCT;
  typedef struct
  {
    AL_ROBOT_HAND_FORCE_INFO_STRUCT forceInfoStruct[PD_FORCE_SENSOR_MAX_NUM];
  } PD_ROBOT_HAND_FORCE_INFO_STRUCT;
  typedef struct
  {
    AL_ROBOT_HAND_FORCE_CONTROL_STRUCT
    forceControlStruct[PD_FORCE_SENSOR_MAX_NUM];
  } PD_ROBOT_HAND_FORCE_CONTROL_STRUCT;

#elif (ROBOT_TYPE == XDDP_TYPE_F5D6_PRO_HAND)

#define PD_F5D6_HAND_FINGER_MAX_NUM 6
#define PD_F5D6_HAND_SENSOR_MAX_NUM 5
#define PD_F5D6_HAND_MAX_NUM 2
#define PD_FORCE_SENSOR_MAX_NUM 2

#pragma pack(2)

/**
 * @brief F5D6 手指上传数据
 */
typedef struct
{
    unsigned short statusWord[PD_F5D6_HAND_FINGER_MAX_NUM];
    float uploadPos[PD_F5D6_HAND_FINGER_MAX_NUM];
    float uploadVel[PD_F5D6_HAND_FINGER_MAX_NUM];
    float uploadTorque[PD_F5D6_HAND_FINGER_MAX_NUM];
    unsigned short uploadErr[PD_F5D6_HAND_FINGER_MAX_NUM];
    char uploadMode[PD_F5D6_HAND_FINGER_MAX_NUM];

} PD_ROBOT_F5D6_HAND_UPLOAD_FINGER_DATA_STRUCT;

/**
 * @brief F5D6 手指下发数据
 */
typedef struct
{
    unsigned short ctrlWord[PD_F5D6_HAND_FINGER_MAX_NUM];
    float downloadPos[PD_F5D6_HAND_FINGER_MAX_NUM];
    float downloadVel[PD_F5D6_HAND_FINGER_MAX_NUM];
    float downloadTorque[PD_F5D6_HAND_FINGER_MAX_NUM];
    char downloadMode[PD_F5D6_HAND_FINGER_MAX_NUM];

} PD_ROBOT_F5D6_HAND_DOWNLOAD_FINGER_DATA_STRUCT;

/**
 * @brief F5D6 压力传感器上传数据
 */
typedef struct
{
    float uploadPress[PD_F5D6_HAND_SENSOR_MAX_NUM];

} PD_ROBOT_F5D6_HAND_UPLOAD_SENSOR_DATA_STRUCT;

/**
 * @brief 六维力上传数据
 */
typedef struct
{
    unsigned short dataNum;
    float fx;
    float fy;
    float fz;
    float mx;
    float my;
    float mz;

} AL_ROBOT_F5D6_HAND_FORCE_INFO_STRUCT;

/**
 * @brief 六维力控制数据
 */
typedef struct
{
    unsigned short para1;
    short para2;
    short para3;

} AL_ROBOT_F5D6_HAND_FORCE_CONTROL_STRUCT;

#pragma pack()

/**
 * @brief F5D6 手爪上传总数据
 */
typedef struct
{
    PD_ROBOT_F5D6_HAND_UPLOAD_FINGER_DATA_STRUCT fingerData[PD_F5D6_HAND_MAX_NUM];
    PD_ROBOT_F5D6_HAND_UPLOAD_SENSOR_DATA_STRUCT sensorData[PD_F5D6_HAND_MAX_NUM];

} PD_ROBOT_F5D6_HAND_UPLOAD_DATA_INFO_STRUCT;

/**
 * @brief F5D6 手爪下发总数据
 */
typedef struct
{
    PD_ROBOT_F5D6_HAND_DOWNLOAD_FINGER_DATA_STRUCT fingerData[PD_F5D6_HAND_MAX_NUM];

} PD_ROBOT_F5D6_HAND_DOWNLOAD_DATA_INFO_STRUCT;

/**
 * @brief 六维力上传总数据
 */
typedef struct
{
    AL_ROBOT_F5D6_HAND_FORCE_INFO_STRUCT forceInfoStruct[PD_FORCE_SENSOR_MAX_NUM];

} PD_ROBOT_F5D6_HAND_FORCE_INFO_STRUCT;

/**
 * @brief 六维力控制总数据
 */
typedef struct
{
    AL_ROBOT_F5D6_HAND_FORCE_CONTROL_STRUCT forceControlStruct[PD_FORCE_SENSOR_MAX_NUM];

} PD_ROBOT_F5D6_HAND_FORCE_CONTROL_STRUCT;

/**
 * @brief F5D6 + 六维力 上传数据
 */
typedef struct
{
    PD_ROBOT_F5D6_HAND_UPLOAD_FINGER_DATA_STRUCT fingerData[PD_F5D6_HAND_MAX_NUM];
    PD_ROBOT_F5D6_HAND_UPLOAD_SENSOR_DATA_STRUCT sensorData[PD_F5D6_HAND_MAX_NUM];
    AL_ROBOT_F5D6_HAND_FORCE_INFO_STRUCT forceInfoStruct[PD_FORCE_SENSOR_MAX_NUM];

} AL_ROBOT_F5D6_HAND_WITH_FORCE_UPLOAD_DATA_INFO_STRUCT;

/**
 * @brief F5D6 + 六维力 下发数据
 */
typedef struct
{
    PD_ROBOT_F5D6_HAND_DOWNLOAD_FINGER_DATA_STRUCT fingerData[PD_F5D6_HAND_MAX_NUM];
    AL_ROBOT_F5D6_HAND_FORCE_CONTROL_STRUCT forceControlStruct[PD_FORCE_SENSOR_MAX_NUM];

} AL_ROBOT_F5D6_HAND_WITH_FORCE_DOWNLOAD_DATA_INFO_STRUCT;

///////////////////////////////////////////////////////////////////////
#elif (ROBOT_TYPE == XDDP_TYPE_CMD)
/**
 * @brief  枚举，用于标识用户输入命令的类型
 */
typedef enum
{
  STATE_ROBOT_NULL = 0,   ///< 机器人状态机空状态
  STATE_ROBOT_CONFIG = 1, ///< 机器人状态机配置状态
  STATE_ROBOT_ON = 2,     ///< 机器人状态机启动状态
  STATE_ROBOT_START = 3,  ///< 机器人状态机开始状态
  STATE_ROBOT_INIT = 4,   ///< 机器人状态机初始化状态
  STATE_ROBOT_RUN = 5,    ///< 机器人状态机运行状态
  STATE_ROBOT_HALT = 6,   ///< 机器人状态机暂停状态
  STATE_ROBOT_STOP = 7,   ///< 机器人状态机停止状态
  STATE_ROBOT_OFF = 8,    ///< 机器人状态机关闭状态
  STATE_ROBOT_ERR = 9     ///< 机器人状态机错误状态
} PD_SC_ROBOT_STATE_ENUM;

typedef enum
{
  RSCP_NULL = 0,                             ///< 无效命令
  RSCP_STATE_SET = 1,                        ///< 状态机切换
  RSCP_STATE_GET = 2,                        ///< 状态机查询
  RSCP_BATTERY_GET = 3,                      ///< 电池信息查询
  RSCP_JOINTS_TEMPERATURE_GET = 4,           ///< 关节温度查询
  RSCP_JOINTS_ERRORCODE_GET = 5,             ///< 关节错误码查询
  RSCP_WA2_INFO_GET = 6,                     ///< WA2信息查询
  RSCP_WA2_INFO_SET = 7,                     ///< WA2命令设置
  RSCP_TEST_CMD = 8,                         ///< 测试命令
  RSCP_WA2_LED_STATE_GET = 9,                ///< WA2 LED状态查询
  RSCP_WA2_LED_STATE_SET = 10,               ///< WA2 LED状态设置
  RSCP_DL2015_BMS_GET = 11,                  ///< DL2015 BMS信息查询
  RSCP_DL2015_BMS_STATE_GET = RSCP_DL2015_BMS_GET, ///< 兼容旧名称
  RSCP_HAND8_PARAM_GET = 12,                 ///< F5D6 POR 手参数查询
  RSCP_HAND8_EXCUTE_CALIBRATION_SET = 13,    ///< F5D6 POR 回零触发
  RSCP_HAND8_POS_PI_SET = 14,                ///< F5D6 POR 手位置PI参数查询
  RSCP_HAND8_VEL_PI_SET = 15,                ///< F5D6 POR 手速度PI参数查询
  RSCP_HAND8_TOR_PI_SET = 16,                ///< F5D6 POR 手力矩PI参数查询
  RSCP_HAND8_STALLCURRENT_SET = 17,          ///< F5D6 POR 手堵转电流设置
  RSCP_HAND8_MAXDUTY_SET = 18,               ///< F5D6 POR 手最大占空比设置
} PD_SC_ROBOT_COMMOND_TYPE_ENUM;

/**
 * @brief  结构体，命令信息
 */
typedef struct
{
  unsigned long long int timestamp; ///< 时间戳
  unsigned int index;               ///< 索引
  unsigned short cmdType;           ///< 命令类型
  unsigned short dataLen;           ///< 数据长度
  char *data;                       ///< 数据指针
} PD_SC_ROBOT_COMMOND_STRUCT;

#pragma pack(2)
typedef struct
{
  short powerEanble;
  short chestLightMode;         // 0 熄灭;1 reserve;2 呼吸;3 常亮
  short leftShoulderLightMode;  // 0 熄灭;1 流水;2 reserve;3 常亮
  short rightShoulderLightMode; // 0 熄灭;1 流水;2 reserve;3 常亮
  short fan1Duty;
  short fan2Duty;
} PD_ECAT_WA2_COMMAND_STRUCT;

typedef struct
{
  float temperature1;
  float temperature2;
  float temperature3;
  float temperatureNtc;
  float powerInVoltage;
  float powerOutVoltage;
  float ImoCurrent;
  unsigned char leftTouchStatus;  // 0 未触发;1 触发
  unsigned char rightTouchStatus; // 0 未触发;1 触发
} PD_ECAT_WA2_STATUS_STRUCT;
#pragma pack()

typedef struct
{
  uint8_t type; // 电池类型  1 - 鼎力2014b, 2 - 鼎力2015型, 3 - 云帆
  char led1;    // 0x01 - 绿灯常亮，0x02 - 红灯常亮，0x03 - 绿灯闪烁，0x04 -
                // 红灯闪烁, 0x05 - 红绿闪烁，其他 - 灭
  char led2;
  float voltage;            // 电池组总电压，单位V
  float current;            // 电池组总电流，单位A
  uint16_t soc;             // 剩余容量 0-100表示0%-100%
  float remainCap;          // 剩余容量，单位Ah
  float maxCelVolt;         // 最高单体电压, 单位V
  float minCelVolt;         // 最低单体电压, 单位V
  uint8_t maxCvNum;         // 最高单体电压电池位置
  uint8_t minCvNum;         // 最低单体电压电池位置
  int16_t maxCellTemp;      // 最高电芯温度，单位摄氏度
  int16_t minCellTemp;      // 最低电芯温度，单位摄氏度
  float maxMinCellVoltDiff; // 单体最高最低电芯压差，单位V
  uint8_t maxTempNum;       // 最高温度电池位置
  uint8_t minTempNum;       // 最低温度电池位置
  float maxMinCellTempDiff; // 单体最高最低温度差，单位社制度
  int16_t avrgCellTemp;     // 电芯平均温度，单位摄氏度
  uint32_t warning[16];     // 报警信息位。
  uint8_t status;           // 状态信息位: 充放电状态： 0 - 精致， 1 - 充电， 2 - 放电
  uint16_t cycleTime;       // 电池循环次数
  uint32_t etr;             // 剩余充电时间, 单位分钟
  char version[32];         // 版本号
} PD_ROBOT_BATTERY_STATUS_STRUCT;

typedef enum
{
  PD_BMS_DL2015_DISABLE = 0,    ///< 禁止状态
  PD_BMS_DL2015_CHARGING = 1,   ///< 充电状态
  PD_BMS_DL2015_DISCHARGING = 2 ///< 放电状态
} PD_BMS_DL2015_STATUS_ENUM;

/**
 * @brief DL2015 BMS对外输出信息
 * @details 字段顺序和2字节对齐方式与实时端XDDP响应保持一致。
 */
#pragma pack(2)
typedef struct
{
  float singleVolt[48];             ///< 各单体电压，单位mV
  uint16_t temperature;             ///< 电池温度，单位摄氏度
  float voltage;                    ///< 电池组总电压，单位V
  float current;                    ///< 电池组总电流，单位A
  uint16_t soc;                     ///< 剩余容量，0-1000表示0%-100%
  float maxCelVolt;                 ///< 最高单体电压，单位V
  uint16_t maxCvNum;                ///< 最高单体电压电池位置
  float minCelVolt;                 ///< 最低单体电压，单位V
  uint16_t minCvNum;                ///< 最低单体电压电池位置
  float maxMinCellVoltDiff;         ///< 单体最高最低电压差，单位V
  int16_t maxCellTemp;              ///< 最高电芯温度，单位摄氏度
  uint16_t maxTempNum;              ///< 最高温度电池位置
  int16_t minCellTemp;              ///< 最低电芯温度，单位摄氏度
  uint16_t minTempNum;              ///< 最低温度电池位置
  uint16_t maxMinCellTempDiff;      ///< 单体最高最低温度差，单位摄氏度
  PD_BMS_DL2015_STATUS_ENUM status; ///< 充放电状态
  float remainCap;                  ///< 剩余容量，单位Ah
  uint16_t cycleTime;               ///< 电池循环次数
  uint16_t etr;                     ///< 剩余充电时间，单位分钟
  uint16_t warning[16];             ///< 报警信息位
  uint16_t version[8];              ///< 版本号
} PD_PROTOCOL_DL2015_BMS_STRUCT;
#pragma pack()
// LED灯带结构体
#pragma pack(push, 1)
    typedef struct
    {
        uint8_t rightMode;
        uint8_t rightFreq;
        uint8_t rightRed;
        uint8_t rightGreen;
        uint8_t rightBlue;
        uint8_t leftMode;
        uint8_t leftFreq;
        uint8_t leftRed;
        uint8_t leftGreen;
        uint8_t leftBlue;
        uint8_t frontMode;
        uint8_t frontFreq;
    } PD_PROTOCOL_WA2_STOP_UPLOAD_STRUCT;
#pragma pack(pop)

#pragma pack(push, 1)
    typedef struct
    {
        uint8_t rightMode;
        uint8_t rightFreq;
        uint8_t rightRed;
        uint8_t rightGreen;
        uint8_t rightBlue;
        uint8_t leftMode;
        uint8_t leftFreq;
        uint8_t leftRed;
        uint8_t leftGreen;
        uint8_t leftBlue;
        uint8_t frontMode;
        uint8_t frontFreq;
    } PD_PROTOCOL_WA2_STOP_DOWNLOAD_STRUCT;
#pragma pack(pop)


/* 报警信息详解
不同电池类型错误码存在差异

### 鼎力2014b报警信息详解
4字节报警信息位说明（bit0~bit31）：每两位表示一种报警状态，00-无告警警，01-严重告警，10-重要告警，11-一般告警
warning[0]:
bit0-bit1: 单体过压
bit2-bit3: 单体欠压
bit4-bit5: 保留
bit6-bit7: 保留
bit8-bit9: 单体压差过大
bit10-bit11: 放电过流
bit12-bit13: 充电过流
bit14-bit15: 温度过高
bit16-bit17: 温度过低
bit18-bit19: 保留
bit20-bit21: SOC过低
bit22-bit23: 保留
bit24-bit25: 保留
bit26-bit27: 保留
bit28-bit29: 内部通信故障
bit30-bit31: 保留

### 鼎力2015报警信息详解

- warning[1]:
低字节：
bit2:0，单体过压告警等级
bit5:3，单体欠压告警等级
bit6,智能充电器连接
bit7，智能充电器连接失败

高字节
bit2:0，压差过大告警等级
bit5:3，充电高温告警等级
bit6，智能放电设备连接
bit7，智能放电设备连接失败

- warning[2]
低字节
bit2:0，充电低温告警等级
bit5:3，放电高温告警等级
bit6，充电mos温度过高
bit7，充电mos温度检测故障

高字节
bit2:0，放电低温告警等级
bit5:3，温差过大告警等级
bit6，放电mos温度过高
bit7，放电mos温度检测故障

- warning[3]
低字节
bit2:0，总压过高告警等级
bit5:3，总压过低告警等级
bit6，短路保护
bit7,预留

高字节
bit2:0，充电过流告警等级
bit5:3，放电过流告警等级
bit6，低压禁止充电
bit7高压禁止放电

- warning[4]
低字节
bit2:0，soc过低告警等级
bit5:3，soh过低告警等级
bit6，并联通信成功
bit7，并联通信失败

高字节
bit2:0，MOS温度过高告警等级
bit5:3，热失控告警等级
bit6,预留
bit7,预留

- warning[5]
低字节
bit2:0，预留
bit5:3，预留
bit6，预留
bit7，预留

高字节
bit2:0，预留
bit5:3，预留
bit6，预留
bit7，预留

- warning[6]
低字节
bit2:0，预留
bit5:3，预留
bit6，预留
bit7，预留

高字节
bit0，afe芯片故障
bit1，afe通信故障
bit2，afe采样故障
bit3，电压检测故障
bit4，电压采集线掉线
bit5，总压检测故障
bit6，电流检测故障
bit7，温度检测故障

- warning[7]
低字节
bit,0，温度采集线掉线
bit1，eeprom故障
bit2，flash故障
bit3，rtc故障
bit4，充电mos故障
bit5，放电mos故障
bit6，预充mos故障
bit7，预充失败

高字节
bit0，通信指令控制充电mos off
bit1，通信指令控制放电mos off
bit2，开关控制充电mos off
bit3，开关控制放电mos off
bit4，风扇工作
bit5，加热工作
bit6，限流模块工作
bit7，加热故障
*/
#pragma pack(push, 1)
    typedef struct
    {
        float poskp;
        float poski;
        float velKp;
        float velKi;
        float torKp;
        float torKi;
        uint16_t stallCurrent;
        uint16_t maxDuty;
    } PD_PROTOCOL_HAND_SENSOR8_UPLOAD_STRUCT;
#pragma pack(pop)

#pragma pack(push, 1)
    typedef struct
    {
        uint16_t excuteCalibration;
        float poskp;
        float poski;
        float velKp;
        float velKi;
        float torKp;
        float torKi;
        uint16_t stallCurrent;
        uint16_t maxDuty;
    } PD_PROTOCOL_HAND_SENSOR8_DOWNLOAD_STRUCT;
#pragma pack(pop)
////////////////////////////////////////////////////////////////////////
#elif (ROBOT_TYPE == XDDP_TYPE_CLAMP)

#define PD_CLAMP_SENSOR_MAX_NUM 2 ///< 宏定义，夹爪传感器总数量
#define PD_FORCE_SENSOR_MAX_NUM 2 ///< 宏定义，六维力

///////////////////////////////////////////////////////////////////////
#pragma pack(2)
/**
 * @brief  结构体，机器人力传感器上传数据结构体定义
 */
typedef struct
{
  unsigned short dataNum; ///< 实际位置值
  float fx;               ///< X轴方向的力
  float fy;               ///< Y轴方向的力
  float fz;               ///< Z轴方向的力
  float mx;               ///< X轴方向的扭矩
  float my;               ///< Y轴方向的扭矩
  float mz;               ///< Z轴方向的扭矩
} AL_ROBOT_HAND_FORCE_INFO_STRUCT;

/**
 * @brief  结构体，机器人力传感器下发数据结构体定义
 */
typedef struct
{
  unsigned short para1; ///< 力传感器参数1
  short para2;          ///< 力传感器参数2
  short para3;          ///< 力传感器参数3
} AL_ROBOT_HAND_FORCE_CONTROL_STRUCT;
/**
 * @brief  结构体，机器人力传感器上传数据结构体定义
 */
typedef struct
{
  unsigned short actualPosition; ///< 实际位置
  unsigned short actualTorque;   ///< 实际扭矩
  unsigned char state;           ///< 状态字
  unsigned char errorCode;       ///< 错误代码
  unsigned char temperature;     ///< 温度值
  unsigned char reserver1;       ///< 错误代码
} AL_ROBOT_CLAMP_UPLOAD_DATA_INFO_STRUCT;

/**
 * @brief  结构体，机器人力传感器下发数据结构体定义
 */
typedef struct
{
  unsigned short targetPosition; ///< 目标位置值
  unsigned short targetVelocity; ///< 目标速度
  unsigned short targetTorque;   ///< 目标扭矩
  unsigned char command;         ///< 控制命令
  unsigned char reserved1;       ///< 保留位1
} AL_ROBOT_CLAMP_DOWNLOAD_DATA_INFO_STRUCT;

#pragma pack()
/**
 * @brief 结构体, XDDP上传数据结构提
 */
typedef struct
{
  AL_ROBOT_CLAMP_UPLOAD_DATA_INFO_STRUCT
  uploadDataStruct[PD_CLAMP_SENSOR_MAX_NUM];
} PD_ROBOT_CLAMP_UPLOAD_DATA_INFO_STRUCT;

/**
 * @brief 结构体, XDDP下发数据结构提
 */
typedef struct
{
  AL_ROBOT_CLAMP_DOWNLOAD_DATA_INFO_STRUCT
  downloadDataStruct[PD_CLAMP_SENSOR_MAX_NUM];
} PD_ROBOT_CLAMP_DOWNLOAD_DATA_INFO_STRUCT;

typedef struct
{
  AL_ROBOT_HAND_FORCE_INFO_STRUCT forceInfoStruct[PD_FORCE_SENSOR_MAX_NUM];
} PD_ROBOT_HAND_FORCE_INFO_STRUCT;
typedef struct
{
  AL_ROBOT_HAND_FORCE_CONTROL_STRUCT
  forceControlStruct[PD_FORCE_SENSOR_MAX_NUM];
} PD_ROBOT_HAND_FORCE_CONTROL_STRUCT;

typedef struct
{
  AL_ROBOT_CLAMP_UPLOAD_DATA_INFO_STRUCT clampInfoStruct[PD_CLAMP_SENSOR_MAX_NUM];
  AL_ROBOT_HAND_FORCE_INFO_STRUCT forceInfoStruct[PD_FORCE_SENSOR_MAX_NUM];
} AL_ROBOT_CLAMP_WITH_FORCE_UPLOAD_DATA_INFO_STRUCT;

typedef struct
{
  AL_ROBOT_CLAMP_DOWNLOAD_DATA_INFO_STRUCT clampControlStruct[PD_CLAMP_SENSOR_MAX_NUM];
  AL_ROBOT_HAND_FORCE_CONTROL_STRUCT forceControlStruct[PD_FORCE_SENSOR_MAX_NUM];
} AL_ROBOT_CLAMP_WITH_FORCE_DOWNLOAD_DATA_INFO_STRUCT;

#elif (ROBOT_TYPE == IDDP_TYPE_ARM)

/**
 * @brief  枚举,机器人轮臂算法关节电机类型
 */
// typedef enum
// {

//     ROBOT_WHEELARM_ALG_JOINT_TYPE_LEFT_SHOULDER_PITCH = 0,  ///< 左肩俯仰 Y
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_LEFT_SHOULDER_ROLL = 1,   ///< 左肩滚转 X
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_LEFT_SHOULDER_YAW = 2,    ///< 左肩偏航 Z
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_LEFT_ELBOW = 3,           ///< 左肘
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_LEFT_WRIST_YAW = 4,       ///< 左腕偏航 Z
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_LEFT_WRIST_PITCH = 5,     ///< 左腕俯仰 Y
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_LEFT_WRIST_ROLL = 6,      ///< 左腕滚转 X
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_RIGHT_SHOULDER_PITCH = 7, ///< 右肩俯仰 Y
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_RIGHT_SHOULDER_ROLL = 8,  ///< 右肩滚转 X
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_RIGHT_SHOULDER_YAW = 9,   ///< 右肩偏航 Z
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_RIGHT_ELBOW = 10,         ///< 右肘
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_RIGHT_WRIST_YAW = 11,     ///< 右腕偏航 Z
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_RIGHT_WRIST_PITCH = 12,   ///< 右腕俯仰 Y
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_RIGHT_WRIST_ROLL = 13,    ///< 右腕滚转 X
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_NECK_YAW = 14,            ///< 颈部偏航 Z
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_NECK_PITCH = 15,          ///< 颈部俯仰 Y

//     ROBOT_WHEELARM_ALG_JOINT_TYPE_WAIST_STRAIGHT = 16,         ///< 腰部直线
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_WAIST_YAW = 17,              ///< 腰部偏航
//     Z ROBOT_WHEELARM_ALG_JOINT_TYPE_WAIST_PITCH = 18,            ///<
//     腰部俯仰 Y

// } AL_ROBOT_WHEELARM_ALG_JOINT_TYPE_ENUM;

/**
 * @brief  枚举,机器人8自由度手臂WA2算法关节索引
 */
// typedef enum
// {
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_TORSO_YAW = 0,       ///< 左躯偏航 Z
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_SHOULDER_PITCH = 1,  ///< 左肩俯仰 Y
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_SHOULDER_ROLL = 2,   ///< 左肩滚转 X
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_SHOULDER_YAW = 3,    ///< 左肩偏航 Z
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_ELBOW = 4,           ///< 左肘
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_WRIST_YAW = 5,       ///< 左腕偏航 Z
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_WRIST_PITCH = 6,     ///< 左腕俯仰 Y
//     ROBOT_ARM_ALG_JOINT_TYPE_LEFT_WRIST_ROLL = 7,      ///< 左腕滚转 X

//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_TORSO_YAW = 8,      ///< 右躯偏航 Z
//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_SHOULDER_PITCH = 9, ///< 右肩俯仰 Y
//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_SHOULDER_ROLL = 10, ///< 右肩滚转 X
//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_SHOULDER_YAW = 11,  ///< 右肩偏航 Z
//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_ELBOW = 12,         ///< 右肘
//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_WRIST_YAW = 13,     ///< 右腕偏航 Z
//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_WRIST_PITCH = 14,   ///< 右腕俯仰 Y
//     ROBOT_ARM_ALG_JOINT_TYPE_RIGHT_WRIST_ROLL = 15,    ///< 右腕滚转 X
//     ROBOT_ARM_ALG_JOINT_TYPE_NECK_YAW = 16,            ///< 颈部偏航 Z
//     ROBOT_ARM_ALG_JOINT_TYPE_NECK_PITCH = 17,          ///< 颈部俯仰 Y
//     ROBOT_ARM_ALG_JOINT_TYPE_ANKLE_PITCH = 18,          ///< Y1
//     ROBOT_ARM_ALG_JOINT_TYPE_KNEE_PITCH = 19,          ///< Y2
//     ROBOT_ARM_ALG_JOINT_TYPE_WAIST_YAW = 20,          ///< Z1
//     ROBOT_ARM_ALG_JOINT_TYPE_WAIST_PITCH = 21,          ///< Y3

// } AL_ROBOT_ARM_ALG_JOINT_TYPE_ENUM;

#elif (ROBOT_TYPE == IDDP_TYPE_LEG)

#define PD_ROBOT_FULL_MAX_NUM 29
#define MAX_UPLIMB_DEVICE_NUM 14   ///< 宏定义，上肢从站数量
#define MAX_HEAD_DEVICE_NUM 2      ///< 宏定义，头部从站数量
#define MAX_DOWNLIMB_DEVICE_NUM 13 ///< 宏定义，下肢从站数量
#define JOY_MAX_AXES_NUM 32
#define JOY_MAX_BTNS_NUM 32
#define IMU_DIMENSION 3

/*
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_SHOULDER_PITCH = 0,  ///< 左肩俯仰 Y
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_SHOULDER_ROLL = 1,   ///< 左肩滚转 X
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_SHOULDER_YAW = 2,    ///< 左肩偏航 Z
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_ELBOW = 3,           ///< 左肘
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_WRIST_YAW = 4,       ///< 左腕偏航 Z
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_WRIST_PITCH = 5,     ///< 左腕俯仰 Y
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_WRIST_ROLL = 6,      ///< 左腕滚转 X
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_SHOULDER_PITCH = 7, ///< 右肩俯仰
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_SHOULDER_ROLL = 8,  ///< 右肩滚转
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_SHOULDER_YAW = 9,   ///< 右肩偏航
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_ELBOW = 10,         ///< 右肘
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_WRIST_YAW = 11,     ///< 右腕偏航
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_WRIST_PITCH = 12,   ///< 右腕俯仰
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_WRIST_ROLL = 13,    ///< 右腕滚转


    ROBOT_LEG_ALG_JOINT_TYPE_WAIST = 14,              ///< 腰部
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_HIP_YAW = 15,       ///< 左髋滚转
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_HIP_ROLL = 16,      ///< 左髋偏航
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_HIP_PITCH = 17,     ///< 左髋俯仰
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_KNEE = 18,          ///< 左膝
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_ANKLE_PITCH = 19,   ///< 左踝俯仰
    ROBOT_LEG_ALG_JOINT_TYPE_LEFT_ANKLE_ROLL = 20,    ///< 左踝滚转
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_HIP_YAW = 21,      ///< 右髋滚转
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_HIP_ROLL = 22,     ///< 右髋偏航
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_HIP_PITCH = 23,    ///< 右髋俯仰
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_KNEE = 24,        ///< 右膝
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_ANKLE_PITCH = 25, ///< 右踝俯仰
    ROBOT_LEG_ALG_JOINT_TYPE_RIGHT_ANKLE_ROLL = 26,  ///< 右踝滚转
*/
typedef struct
{
  uint8_t mode[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  uint16_t statuswd[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  double act_pos[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机位置
  double act_vel[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机速度
  double act_tau[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机力矩
  double
      act_tmp[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机温度℃
  double
      act_cur[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机电流mA
  double uploadImuRPY[IMU_DIMENSION];
  double uploadImuAcc[IMU_DIMENSION];
  double uploadImuVel[IMU_DIMENSION];
  unsigned long long int uptime;
} FULL_INPUT_INFO_STRUCT;

typedef struct
{
  double offset_torque[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  double offset_vel[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  uint8_t mode_operation[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  uint16_t ctrlwd[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_pos[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_vel[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_tau[MAX_UPLIMB_DEVICE_NUM + MAX_DOWNLIMB_DEVICE_NUM];
  unsigned long long int downtime;
} FULL_OUTPUT_INFO_STRUCT;

typedef struct
{
  uint8_t mode[MAX_DOWNLIMB_DEVICE_NUM];
  uint16_t statuswd[MAX_DOWNLIMB_DEVICE_NUM];
  double act_pos[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机位置
  double act_vel[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机速度
  double act_tau[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机力矩
  double act_tmp[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机温度℃
  double act_cur[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机电流mA
  double uploadImuRPY[IMU_DIMENSION];
  double uploadImuAcc[IMU_DIMENSION];
  double uploadImuVel[IMU_DIMENSION];
  unsigned long long int uptime;
} DOWNLIMB_INPUT_INFO_STRUCT;

typedef struct
{
  double offset_torque[MAX_DOWNLIMB_DEVICE_NUM];
  double offset_vel[MAX_DOWNLIMB_DEVICE_NUM];
  uint8_t mode_operation[MAX_DOWNLIMB_DEVICE_NUM];
  uint16_t ctrlwd[MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_pos[MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_vel[MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_tau[MAX_DOWNLIMB_DEVICE_NUM];
  unsigned long long int downtime;
} DOWNLIMB_OUTPUT_INFO_STRUCT;

/**
 * @brief  结构体，机器人上传数据信息结构体定义
 */
typedef struct
{
  uint64_t index;
  unsigned long long int upTime; // ns
  uint8_t mode[PD_ROBOT_FULL_MAX_NUM];
  uint16_t statuswd[PD_ROBOT_FULL_MAX_NUM];
  double act_pos[PD_ROBOT_FULL_MAX_NUM]; ///< 电机位置
  double act_vel[PD_ROBOT_FULL_MAX_NUM]; ///< 电机速度
  // double act_acc[PD_ROBOT_FULL_MAX_NUM];
  double act_tau[PD_ROBOT_FULL_MAX_NUM]; ///< 电机力矩
  double act_tmp[PD_ROBOT_FULL_MAX_NUM]; ///< 电机温度℃
  double act_cur[PD_ROBOT_FULL_MAX_NUM]; ///< 电机电流mA
  double uploadImuRPY[IMU_DIMENSION];
  double uploadImuAcc[IMU_DIMENSION];
  double uploadImuVel[IMU_DIMENSION];
  int joyAxesValue[JOY_MAX_AXES_NUM];
  char joyBtnsValue[JOY_MAX_BTNS_NUM];
} PD_ROBOT_FULL_UPLOAD_DATA_INFO_STRUCT;

/**
 * @brief  结构体，机器人下发数据信息结构体定义
 */
typedef struct
{
  uint64_t index;
  unsigned long long int downTime;
  double offset_torque[PD_ROBOT_FULL_MAX_NUM];
  double offset_vel[PD_ROBOT_FULL_MAX_NUM];
  uint8_t mode_operation[PD_ROBOT_FULL_MAX_NUM];
  uint16_t ctrlwd[PD_ROBOT_FULL_MAX_NUM];
  double cmd_pos[PD_ROBOT_FULL_MAX_NUM];
  double cmd_vel[PD_ROBOT_FULL_MAX_NUM];
  double cmd_tau[PD_ROBOT_FULL_MAX_NUM];

} PD_ROBOT_FULL_DOWNLOAD_DATA_INFO_STRUCT;
///////////////////////////////////////////////////////////////////////
#elif ((ROBOT_TYPE == IDDP_TYPE_FULL))

#define PD_ROBOT_FULL_MAX_NUM 29
#define MAX_UPLIMB_DEVICE_NUM 17   ///< 宏定义，上肢从站数量
#define MAX_DOWNLIMB_DEVICE_NUM 12 ///< 宏定义，下肢从站数量
#define JOY_MAX_AXES_NUM 32
#define JOY_MAX_BTNS_NUM 32
#define IMU_DIMENSION 3

/*
    //ROBOT_FULL_ALG_JOINT_TYPE_WAIST = 0,              ///< 腰部

    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_YAW = 0,       ///< 左髋滚转
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_ROLL,      ///< 左髋偏航
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_PITCH,     ///< 左髋俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_KNEE,          ///< 左膝
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ANKLE_PITCH,   ///< 左踝俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ANKLE_ROLL,    ///< 左踝滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_YAW = 6,      ///< 右髋滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_ROLL,     ///< 右髋偏航
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_PITCH,    ///< 右髋俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_KNEE,        ///< 右膝
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ANKLE_PITCH, ///< 右踝俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ANKLE_ROLL = 11,  ///< 右踝滚转
*/

typedef struct
{
  uint8_t mode[MAX_DOWNLIMB_DEVICE_NUM];
  uint16_t statuswd[MAX_DOWNLIMB_DEVICE_NUM];
  double act_pos[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机位置
  double act_vel[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机速度
  double act_tau[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机力矩
  double act_tmp[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机温度℃
  double act_cur[MAX_DOWNLIMB_DEVICE_NUM]; ///< 电机电流mA
  double uploadImuRPY[IMU_DIMENSION];
  double uploadImuAcc[IMU_DIMENSION];
  double uploadImuVel[IMU_DIMENSION];
  unsigned long long int uptime;
} DOWNLIMB_INPUT_INFO_STRUCT;

typedef struct
{
  double offset_torque[MAX_DOWNLIMB_DEVICE_NUM];
  double offset_vel[MAX_DOWNLIMB_DEVICE_NUM];
  uint8_t mode_operation[MAX_DOWNLIMB_DEVICE_NUM];
  uint16_t ctrlwd[MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_pos[MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_vel[MAX_DOWNLIMB_DEVICE_NUM];
  double cmd_tau[MAX_DOWNLIMB_DEVICE_NUM];
  unsigned long long int downtime;
} DOWNLIMB_OUTPUT_INFO_STRUCT;

/*
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_SHOULDER_PITCH = 0,  ///< 左肩俯仰 Y
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_SHOULDER_ROLL = 1,   ///< 左肩滚转 X
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_SHOULDER_YAW = 2,    ///< 左肩偏航 Z
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ELBOW = 3,           ///< 左肘
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_WRIST_YAW = 4,       ///< 左腕偏航 Z
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_WRIST_PITCH = 5,     ///< 左腕俯仰 Y
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_WRIST_ROLL = 6,      ///< 左腕滚转 X
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_SHOULDER_PITCH = 7, ///< 右肩俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_SHOULDER_ROLL = 8,  ///< 右肩滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_SHOULDER_YAW = 9,   ///< 右肩偏航
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ELBOW = 10,         ///< 右肘
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_WRIST_YAW = 11,     ///< 右腕偏航
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_WRIST_PITCH = 12,   ///< 右腕俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_WRIST_ROLL = 13,    ///< 右腕滚转
    ROBOT_FULL_ALG_JOINT_TYPE_NECK_YAW = 14,            ///< 颈部偏航 Z
    ROBOT_FULL_ALG_JOINT_TYPE_NECK_PITCH = 15,          ///< 颈部俯仰 Y

    ROBOT_FULL_ALG_JOINT_TYPE_WAIST = 16,              ///< 腰部

    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_YAW = 17,       ///< 左髋滚转
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_ROLL = 18,      ///< 左髋偏航
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_PITCH = 19,     ///< 左髋俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_KNEE = 20,          ///< 左膝
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ANKLE_PITCH = 21,   ///< 左踝俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ANKLE_ROLL = 22,    ///< 左踝滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_YAW = 23,      ///< 右髋滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_ROLL = 24,     ///< 右髋偏航
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_PITCH = 25,    ///< 右髋俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_KNEE = 26,        ///< 右膝
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ANKLE_PITCH = 27, ///< 右踝俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ANKLE_ROLL = 28,  ///< 右踝滚转
*/

/**
 * @brief  结构体，机器人上传数据信息结构体定义
 */
typedef struct
{
  uint64_t index;
  unsigned long long int upTime; // ns
  uint8_t mode[PD_ROBOT_FULL_MAX_NUM];
  uint16_t statuswd[PD_ROBOT_FULL_MAX_NUM];
  double act_pos[PD_ROBOT_FULL_MAX_NUM]; ///< 电机位置
  double act_vel[PD_ROBOT_FULL_MAX_NUM]; ///< 电机速度
  // double act_acc[PD_ROBOT_FULL_MAX_NUM];
  double act_tau[PD_ROBOT_FULL_MAX_NUM]; ///< 电机力矩
  double act_tmp[PD_ROBOT_FULL_MAX_NUM]; ///< 电机温度℃
  double act_cur[PD_ROBOT_FULL_MAX_NUM]; ///< 电机电流mA
  double uploadImuRPY[IMU_DIMENSION];
  double uploadImuAcc[IMU_DIMENSION];
  double uploadImuVel[IMU_DIMENSION];
  int joyAxesValue[JOY_MAX_AXES_NUM];
  char joyBtnsValue[JOY_MAX_BTNS_NUM];
} PD_ROBOT_FULL_UPLOAD_DATA_INFO_STRUCT;

/**
 * @brief  结构体，机器人下发数据信息结构体定义
 */
typedef struct
{
  uint64_t index;
  unsigned long long int downTime;
  double offset_torque[PD_ROBOT_FULL_MAX_NUM];
  double offset_vel[PD_ROBOT_FULL_MAX_NUM];
  uint8_t mode_operation[PD_ROBOT_FULL_MAX_NUM];
  uint16_t ctrlwd[PD_ROBOT_FULL_MAX_NUM];
  double cmd_pos[PD_ROBOT_FULL_MAX_NUM];
  double cmd_vel[PD_ROBOT_FULL_MAX_NUM];
  double cmd_tau[PD_ROBOT_FULL_MAX_NUM];

} PD_ROBOT_FULL_DOWNLOAD_DATA_INFO_STRUCT;

#elif ((ROBOT_TYPE == IDDP_TYPE_WHOLE) || (ROBOT_TYPE == IDDP_TYPE_NONE))

/*
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_SHOULDER_PITCH = 0,  ///< 左肩俯仰 Y
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_SHOULDER_ROLL = 1,   ///< 左肩滚转 X
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_SHOULDER_YAW = 2,    ///< 左肩偏航 Z
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ELBOW = 3,           ///< 左肘
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_WRIST_YAW = 4,       ///< 左腕偏航 Z
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_WRIST_PITCH = 5,     ///< 左腕俯仰 Y
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_WRIST_ROLL = 6,      ///< 左腕滚转 X
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_SHOULDER_PITCH = 7, ///< 右肩俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_SHOULDER_ROLL = 8,  ///< 右肩滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_SHOULDER_YAW = 9,   ///< 右肩偏航
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ELBOW = 10,         ///< 右肘
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_WRIST_YAW = 11,     ///< 右腕偏航
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_WRIST_PITCH = 12,   ///< 右腕俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_WRIST_ROLL = 13,    ///< 右腕滚转
    ROBOT_FULL_ALG_JOINT_TYPE_NECK_YAW = 14,            ///< 颈部偏航
    ROBOT_FULL_ALG_JOINT_TYPE_NECK_PITCH = 15,          ///< 颈部俯仰

//     ROBOT_WHEELARM_ALG_JOINT_TYPE_WAIST_STRAIGHT = 16,         ///< 腰部直线
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_WAIST_YAW = 17,              ///< 腰部偏航
Z
//     ROBOT_WHEELARM_ALG_JOINT_TYPE_WAIST_PITCH = 18,            ///< 腰部俯仰
Y

    // ROBOT_FULL_ALG_JOINT_TYPE_WAIST = 16,              ///< 腰部

    // ROBOT_WHOLE_ALG_JOINT_TYPE_WAIST_LEFT = 16,     ///< 三自由度腰部
    // ROBOT_WHOLE_ALG_JOINT_TYPE_WAIST_RIGHT = 17,
    // ROBOT_WHOLE_ALG_JOINT_TYPE_WAIST_YAW = 18,

    ROBOT_WHOLE_ALG_JOINT_TYPE_WAIST_YAW = 16,          ///< 180腰部
    ROBOT_WHOLE_ALG_JOINT_TYPE_WAIST_LEFT = 17,
    ROBOT_WHOLE_ALG_JOINT_TYPE_WAIST_RIGHT = 18,

    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_YAW = 19,       ///< 左髋滚转
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_ROLL,      ///< 左髋偏航
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_HIP_PITCH,     ///< 左髋俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_KNEE,          ///< 左膝
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ANKLE_PITCH,   ///< 左踝俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_LEFT_ANKLE_ROLL,    ///< 左踝滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_YAW = 25,      ///< 右髋滚转
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_ROLL,     ///< 右髋偏航
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_HIP_PITCH,    ///< 右髋俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_KNEE,        ///< 右膝
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ANKLE_PITCH, ///< 右踝俯仰
    ROBOT_FULL_ALG_JOINT_TYPE_RIGHT_ANKLE_ROLL = 30,  ///< 右踝滚转


    ROBOT_FULL_ALG_HAND_TYPE_LEFT = 0,  ///< 左手
    ROBOT_FULL_ALG_HAND_TYPE_RIGHT = 1,   ///< 右手
    ROBOT_FULL_ALG_FORCE_TYPE_ARM_LEFT = 0,  ///< 左手六维力传感器
    ROBOT_FULL_ALG_FORCE_TYPE_ARM_RIGHT = 1,   ///< 右手六维力传感器
    ROBOT_FULL_ALG_FORCE_TYPE_LEG_LEFT = 2,  ///< 左脚六维力传感器
    ROBOT_FULL_ALG_FORCE_TYPE_LEG_RIGHT = 3,   ///< 右脚六维力传感器
*/

#define PD_PROTOCOL_JOINT_MAX_NUM 40
#define PD_HAND_SENSOR_MAX_NUM 2
#define PD_FORCE_SENSOR_MAX_NUM 4
#define PD_IMU_SENSOR_MAX_NUM 1
// 整机
#define PD_PROTOCOL_JOINT_UPLIMB_MAX_NUM 19   ///< 宏定义，上肢从站数量
#define PD_PROTOCOL_JOINT_DOWNLIMB_MAX_NUM 12 ///< 宏定义，下肢从站数量
// 轮臂 or 半身
//  #define PD_PROTOCOL_JOINT_UPLIMB_MAX_NUM 19 ///<宏定义，上肢从站数量
//  #define PD_PROTOCOL_JOINT_DOWNLIMB_MAX_NUM 0 ///<宏定义，下肢从站数量

#define PD_PROTOCOL_HAND_JOINT_MAX_NUM 13
#define PD_PROTOCOL_HAND_PRESS_MAX_NUM 8

typedef struct
{
  uint8_t mode;             // 实际模式
  uint16_t statuswd;        // 状态字
  double act_pos;           // 实际位置rad
  double act_vel;           // 实际速度rad/s
  double act_tau;           // 实际力矩Nm
  double act_tmp;           // 实际温度℃
  double act_cur;           // 实际电流mA
  unsigned short errorCode; ///< 错误码
} PD_PROTOCOL_JOINT_UPLOAD_DATA_STRUCT;

typedef struct
{
  double offset_torque;   // 力矩前馈Nm
  double offset_vel;      // 速度前馈rad/s
  uint8_t mode_operation; // 目标模式
  uint16_t ctrlwd;        // 控制字
  double cmd_pos;         // 目标位置rad
  double cmd_vel;         // 目标速度rad/s
  double cmd_tau;         // 目标力矩Nm
} PD_PROTOCOL_JOINT_DOWNLOAD_DATA_STRUCT;

typedef struct
{
  float act_pos; // 实际位置 角度
  float act_cur; // 实际电流 mA
} PD_PROTOCOL_HAND_JOINT_UPLOAD_DATA_STRUCT;

typedef struct
{
  PD_PROTOCOL_HAND_JOINT_UPLOAD_DATA_STRUCT
  joint[PD_PROTOCOL_HAND_JOINT_MAX_NUM];
  float pressure[PD_PROTOCOL_HAND_PRESS_MAX_NUM]; // 压力 N
} PD_PROTOCOL_HAND_UPLOAD_DATA_STRUCT;

typedef struct
{
  float cmd_pos;           // 目标位置 角度
  unsigned short cmd_time; // 运动时间ms
  float cmd_vol;           // 最大电压V
} PD_PROTOCOL_HAND_JOINT_DOWNLOAD_DATA_STRUCT;

typedef struct
{
  PD_PROTOCOL_HAND_JOINT_DOWNLOAD_DATA_STRUCT
  joint[PD_PROTOCOL_HAND_JOINT_MAX_NUM];
} PD_PROTOCOL_HAND_DOWNLOAD_DATA_STRUCT;

typedef struct
{
  unsigned short dataNum; ///< 计数
  float fx;               ///< X轴方向的力
  float fy;               ///< Y轴方向的力
  float fz;               ///< Z轴方向的力
  float mx;               ///< X轴方向的扭矩
  float my;               ///< Y轴方向的扭矩
  float mz;               ///< Z轴方向的扭矩
} PD_PROTOCOL_FORCE_UPLOAD_DATA_STRUCT;

typedef struct
{
  float roll;
  float pitch;
  float yaw;
  float gyr_x; // x轴角速度
  float gyr_y; // y轴角速度
  float gyr_z; // z轴角速度
  float acc_x; // x轴加速度
  float acc_y; // y轴加速度
  float acc_z; // z轴加速度
  // 电池信息
  unsigned short voltage; // 电压 10mV
  short current;          // 电流 10mA
  unsigned short protect; // 保护状态
  unsigned char rsoc;     // 剩余电量百分比
} PD_PROTOCOL_IMU_UPLOAD_DATA_STRUCT;

typedef struct
{
  uint64_t index;
  unsigned long long int upTime; // ns
  PD_PROTOCOL_JOINT_UPLOAD_DATA_STRUCT joint[PD_PROTOCOL_JOINT_MAX_NUM];
  PD_PROTOCOL_HAND_UPLOAD_DATA_STRUCT hand[PD_HAND_SENSOR_MAX_NUM];
  PD_PROTOCOL_FORCE_UPLOAD_DATA_STRUCT force[PD_FORCE_SENSOR_MAX_NUM];
  PD_PROTOCOL_IMU_UPLOAD_DATA_STRUCT imu[PD_IMU_SENSOR_MAX_NUM];
} PD_PROTOCOL_ROBOT_UPLOAD_DATA_STRUCT;

typedef struct
{
  uint64_t index;
  unsigned long long int downTime;
  PD_PROTOCOL_JOINT_DOWNLOAD_DATA_STRUCT joint[PD_PROTOCOL_JOINT_MAX_NUM];
  PD_PROTOCOL_HAND_DOWNLOAD_DATA_STRUCT hand[PD_HAND_SENSOR_MAX_NUM];

} PD_PROTOCOL_ROBOT_DOWNLOAD_DATA_STRUCT;

typedef struct
{
  PD_PROTOCOL_JOINT_UPLOAD_DATA_STRUCT joint[PD_PROTOCOL_JOINT_MAX_NUM];
} ROBOT_JOINT_STATE_INFO_STRUCT;
typedef struct
{
  PD_PROTOCOL_JOINT_DOWNLOAD_DATA_STRUCT
  joint[PD_PROTOCOL_JOINT_UPLIMB_MAX_NUM];
} ROBOT_JOINT_UPLIMB_CMD_INFO_STRUCT;
typedef struct
{
  PD_PROTOCOL_JOINT_DOWNLOAD_DATA_STRUCT
  joint[PD_PROTOCOL_JOINT_DOWNLIMB_MAX_NUM];
} ROBOT_JOINT_DOWNLIMB_CMD_INFO_STRUCT;
typedef struct
{
  PD_PROTOCOL_JOINT_DOWNLOAD_DATA_STRUCT joint[PD_PROTOCOL_JOINT_MAX_NUM];
} ROBOT_JOINT_CMD_INFO_STRUCT;
typedef struct
{
  PD_PROTOCOL_HAND_UPLOAD_DATA_STRUCT hand[PD_HAND_SENSOR_MAX_NUM];
} ROBOT_HAND_STATE_INFO_STRUCT;
typedef struct
{
  PD_PROTOCOL_HAND_DOWNLOAD_DATA_STRUCT hand[PD_HAND_SENSOR_MAX_NUM];
} ROBOT_HAND_CMD_INFO_STRUCT;
typedef struct
{
  PD_PROTOCOL_FORCE_UPLOAD_DATA_STRUCT force[PD_FORCE_SENSOR_MAX_NUM];
} ROBOT_FORCE_STATE_INFO_STRUCT;
typedef struct
{
  float roll;
  float pitch;
  float yaw;
  float gyr_x; // x轴角速度
  float gyr_y; // y轴角速度
  float gyr_z; // z轴角速度
  float acc_x; // x轴加速度
  float acc_y; // y轴加速度
  float acc_z; // z轴加速度
} ROBOT_IMU_STATE_INFO_STRUCT;
typedef struct
{
  unsigned short voltage; // 电压 10mV
  short current;          // 电流 10mA
  unsigned short protect; // 保护状态
  unsigned char rsoc;     // 剩余电量百分比
} ROBOT_BATTERY_STATE_INFO_STRUCT;

////////////////////////////////////////////////////////////////////////

#endif

#ifdef __cplusplus
}
#endif

#endif
