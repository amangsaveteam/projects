#ifndef UL_SRC_UL_CONTROLLER_DYNAMICS_CONTROLLER_BASE_H_
#define UL_SRC_UL_CONTROLLER_DYNAMICS_CONTROLLER_BASE_H_

/**
 * @brief Real-time dynamics controller interface.
 *
 * This interface allows users to implement custom dynamics controllers that will be
 * executed inside the real-time control loop of the uplimb controller.
 *
 * The function update() is executed in a real-time thread (1 kHz control loop).
 * Therefore, the controller implementation must strictly follow real-time constraints.
 *
 * Real-time constraints for update():
 *
 * 1. The execution time of update() must be **deterministic and shorter than the control loop period**.
 *    Long or unpredictable computations may break the real-time control loop.
 *
 * 2. The function must be **non-blocking**.
 *    It must not wait for locks, condition variables, futures, or other blocking operations.
 *
 * 3. The function must **not throw exceptions**.
 *    Exception handling in a real-time thread may cause latency spikes or termination.
 *
 * 4. The function must **not perform file I/O or network I/O**, including:
 *      - file read/write
 *      - logging to disk
 *      - socket communication
 *
 * 5. The function must **not use sleep or delay operations**, such as:
 *      - std::this_thread::sleep_for
 *      - std::this_thread::sleep_until
 *
 * 6. **Dynamic memory allocation should be avoided** inside update().
 *    Memory allocations (e.g., new, malloc, vector resize) may introduce unpredictable latency.
 *    It is recommended to allocate all required memory in init().
 *
 * 7. The controller should be **initialized in a non-real-time context**:
 *      - init() will be called before the control loop starts.
 *      - reset() may be called when the controller is activated or reconfigured.
 *
 * 8. update() should only perform **pure computation based on the provided context**.
 *    It must not modify shared global state unless proper lock-free mechanisms are used.
 *
 * 9. The output torque vector (out.tau_cmd) must have the same dimension as the robot DOF.
 *    The controller must set out.valid = true when the command is valid.
 *
 * 10. If the controller fails to compute a valid command, it should return false or set
 *     out.valid = false. The system will fall back to a safe control strategy.
 *
 * Threading model:
 *   init()  -> called in non-real-time thread
 *   reset() -> called in non-real-time thread
 *   update()-> called in real-time control loop
 *
 * Recommended design pattern for controllers:
 *   - allocate memory in init()
 *   - precompute matrices if possible
 *   - keep update() lightweight and deterministic
 */

#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

#include <Eigen/Core>

namespace ul {
namespace controller {

using Scalar = double;
using Vector = ::Eigen::VectorXd;
using Matrix = ::Eigen::MatrixXd;
using IndexVector = ::Eigen::VectorXi;

struct InteractionControlContext {
  const Vector& cmd_q;
  const Vector& cmd_qd;
  const Vector& cmd_qdd;

  const Vector& act_q;
  const Vector& act_qd;
  const Vector& act_tau;

  const Vector& cmd_qd_filt;
  const Vector& act_qd_filt;
  const Vector& cmd_qdd_filt;
  const Vector& act_qdd_filt;

  const Matrix& M;
  const Vector& tau_c;
  const Vector& tau_g;
  const Vector& tau_f;

  const Matrix& M_filt;
  const Vector& tau_c_filt;
  const Vector& tau_g_filt;
  const Vector& tau_f_filt;

  const Vector& tau_est;
  const ::std::vector<Vector>& tau_tool;

  const Vector& joint_torque_limit;
  const ::std::vector<::std::uint8_t>& cmd_mode_operation;

  Scalar sampling_period;
  ::std::size_t dof;
};

struct InteractionControlOutput {
  Vector tau_cmd;
  bool valid;

  explicit InteractionControlOutput(::std::size_t dof)
      : tau_cmd(Vector::Zero(static_cast<::Eigen::Index>(dof))),
        valid(false) {}
};

class IDynamicsController {
 public:
  virtual ~IDynamicsController() = default;

  virtual bool init(::std::size_t dof) = 0;

  virtual void reset() = 0;
  // 负载补偿默认开启
  virtual bool update(const InteractionControlContext& ctx,
                      InteractionControlOutput& out) noexcept = 0;

  virtual const char* name() const noexcept = 0;
};

using DynamicsControllerPtr = ::std::shared_ptr<IDynamicsController>;

}  // namespace controller
}  // namespace ul

#endif  // UL_SRC_UL_CONTROLLER_DYNAMICS_CONTROLLER_BASE_H_