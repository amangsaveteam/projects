#pragma once

#include <vector>
#include "rtipc_common.h"
#if ((ROBOT_TYPE == IDDP_TYPE_ARM) || (ROBOT_TYPE == IDDP_TYPE_FULL) || (ROBOT_TYPE == IDDP_TYPE_WHOLE))
#include "UplimbController.h"
#elif (ROBOT_TYPE == IDDP_TYPE_LEG)
// #include "motion_control.h"
#include "UplimbController.h"
#endif

#if ((ROBOT_TYPE == XDDP_TYPE_HAND) || (ROBOT_TYPE == XDDP_TYPE_CMD) || (ROBOT_TYPE == XDDP_TYPE_CLAMP))
class RobotXddp
{
public:
    RobotXddp();
    ~RobotXddp();
    void robotXddpInit(void);

    void init(void)
    {
        robotXddpInit();
    }
    void Init(void)
    {
        robotXddpInit();
    }
#else
class RobotIddp
{
public:
    RobotIddp();
    ~RobotIddp();
#if (ROBOT_TYPE == IDDP_TYPE_WHOLE)
    typedef enum
    {
        ROBOT_WHOLE_MODEL_U1 = 0,
        ROBOT_WHOLE_MODEL_WA1,
        ROBOT_WHOLE_MODEL_WA2,
        ROBOT_WHOLE_MODEL_I2,
        ROBOT_WHOLE_MODEL_I3,
        ROBOT_WHOLE_MODEL_CUSTOM
    } ROBOT_WHOLE_MODEL_ENUM;

    void robotIddpInit(uint8_t uplimb_joint_num = PD_PROTOCOL_JOINT_MAX_NUM,
                       uint8_t downlimb_joint_num = 0);
    void robotIddpInit(ROBOT_WHOLE_MODEL_ENUM whole_model);
#else
    void robotIddpInit();
#endif
#endif
    const char *getSoftwareVersion() const;
    bool run;
    bool algoStart;

#if ((ROBOT_TYPE == IDDP_TYPE_ARM))
    bool getArmState(UPLIMB_INPUT_INFO_STRUCT &state);
    bool setArmDriver(UPLIMB_OUTPUT_INFO_STRUCT &cmd);
    bool getArmCmd(UPLIMB_OUTPUT_INFO_STRUCT &cmd);
    bool getArmVar(UPLIMB_VAR_OBSERVE &info);
#elif (ROBOT_TYPE == IDDP_TYPE_LEG)
    bool getLegState(DOWNLIMB_INPUT_INFO_STRUCT &state);
    bool setLegDriver(DOWNLIMB_OUTPUT_INFO_STRUCT &cmd);
    bool getFullState(FULL_INPUT_INFO_STRUCT &state);
    bool setFullDriver(FULL_OUTPUT_INFO_STRUCT &cmd);
#elif (ROBOT_TYPE == IDDP_TYPE_FULL)
bool getFullState(PD_ROBOT_FULL_UPLOAD_DATA_INFO_STRUCT &state);
bool setFullDriver(PD_ROBOT_FULL_DOWNLOAD_DATA_INFO_STRUCT &cmd);
bool getLegState(DOWNLIMB_INPUT_INFO_STRUCT &state);
bool setLegDriver(DOWNLIMB_OUTPUT_INFO_STRUCT &cmd);
bool getArmState(UPLIMB_INPUT_INFO_STRUCT &state);
// bool setArmDriver(UPLIMB_OUTPUT_INFO_STRUCT &cmd);
bool getArmCmd(UPLIMB_OUTPUT_INFO_STRUCT &cmd);
bool getArmVar(UPLIMB_VAR_OBSERVE &info);
#elif (ROBOT_TYPE == XDDP_TYPE_HAND)
bool GetHandState(PD_ROBOT_HAND_UPLOAD_DATA_INFO_STRUCT &state);
bool SetHandDriver(PD_ROBOT_HAND_DOWNLOAD_DATA_INFO_STRUCT &cmd);
bool GetForceState(PD_ROBOT_HAND_FORCE_INFO_STRUCT &state);
// bool SetForceDriver(PD_ROBOT_HAND_DOWNLOAD_DATA_INFO_STRUCT &cmd);
#elif (ROBOT_TYPE == XDDP_TYPE_CLAMP)
bool GetClampState(PD_ROBOT_CLAMP_UPLOAD_DATA_INFO_STRUCT &state);
bool SetClampDriver(PD_ROBOT_CLAMP_DOWNLOAD_DATA_INFO_STRUCT &cmd);
bool GetForceState(PD_ROBOT_HAND_FORCE_INFO_STRUCT &state);
#elif (ROBOT_TYPE == XDDP_TYPE_CMD)
bool SetRobotCmd(PD_SC_ROBOT_COMMOND_STRUCT &cmd);     // 透传接口
bool GetRobotCmd(PD_SC_ROBOT_COMMOND_STRUCT &cmd);     // 透传接口
bool SetRobotState(PD_SC_ROBOT_COMMOND_STRUCT &state); // 设置机器人状态
bool GetRobotState(PD_SC_ROBOT_COMMOND_STRUCT &state); // 获取机器人状态
// bool GetRobotBatteryState(PD_SC_ROBOT_COMMOND_STRUCT &state);
bool GetRobotBatteryState(PD_ROBOT_BATTERY_STATUS_STRUCT &state);                                        // 获取机器人电池状态
bool GetRobotJointTemperatureState(PD_SC_ROBOT_COMMOND_STRUCT &state);                                   // 获取机器人关节温度状态
bool GetRobotJointErrorcodeState(PD_SC_ROBOT_COMMOND_STRUCT &state);                                     // 获取机器人关节错误码状态
bool GetRobotWA2State(std::vector<PD_ECAT_WA2_STATUS_STRUCT> &state);                                    // 获取WA2状态
bool SetRobotWA2FanDuty(unsigned char fan1, unsigned char fan2, unsigned char fan3, unsigned char fan4); // 设置风扇转速0-100 %

#elif (ROBOT_TYPE == IDDP_TYPE_WHOLE)
bool getWholeState(PD_PROTOCOL_ROBOT_UPLOAD_DATA_STRUCT &state);
// bool setWholeDriver(PD_PROTOCOL_ROBOT_DOWNLOAD_DATA_STRUCT &cmd);
bool getJointState(ROBOT_JOINT_STATE_INFO_STRUCT &state);
bool setJointDriver(ROBOT_JOINT_CMD_INFO_STRUCT &cmd); // 使用上肢算法库时此接口失效
bool getArmState(UPLIMB_INPUT_INFO_STRUCT &state);
bool getArmCmd(UPLIMB_OUTPUT_INFO_STRUCT &cmd);
bool setArmDriver(ROBOT_JOINT_UPLIMB_CMD_INFO_STRUCT &cmd); // 使用上肢算法库时此接口失效
bool setArmDriver(const PD_PROTOCOL_JOINT_DOWNLOAD_DATA_STRUCT *cmd, uint8_t joint_num);
bool getArmVar(UPLIMB_VAR_OBSERVE &info);
// bool getLegState(DOWNLIMB_INPUT_INFO_STRUCT &state);
bool setLegDriver(ROBOT_JOINT_DOWNLIMB_CMD_INFO_STRUCT &cmd);
bool setLegDriver(const PD_PROTOCOL_JOINT_DOWNLOAD_DATA_STRUCT *cmd, uint8_t joint_num);
bool getIMUState(ROBOT_IMU_STATE_INFO_STRUCT &state);
bool getBatteryState(ROBOT_BATTERY_STATE_INFO_STRUCT &state);
bool getHandState(ROBOT_HAND_STATE_INFO_STRUCT &state);
bool setHandDriver(ROBOT_HAND_CMD_INFO_STRUCT &cmd);
bool getForceState(ROBOT_FORCE_STATE_INFO_STRUCT &state);
uint8_t getUplimbJointNum() const;
uint8_t getDownlimbJointNum() const;
ROBOT_WHOLE_MODEL_ENUM getWholeModel() const;
#endif
};
