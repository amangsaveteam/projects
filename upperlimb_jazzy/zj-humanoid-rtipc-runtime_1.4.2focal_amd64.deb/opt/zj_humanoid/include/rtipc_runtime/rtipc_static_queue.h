#pragma once

#include <array>
#include <atomic>
#include <condition_variable>
#include <mutex>

struct iddp_msg_t
{
    uint64_t uploadTime;
    uint64_t downTime;
    uint64_t downTimeDiff;
    uint64_t curTime;
    uint64_t curTimeDiff;
    double act_pos;
    double act_vel;
    double cmd_pos;

    uint64_t rtipcCurTime;
    uint64_t rtipcCurTimeDiff;
    double rtipc_act_pos;
    double rtipc_act_vel;
    double rtipc_cmd_pos;
};

extern struct iddp_msg_t g_message;
template <typename T, size_t Capacity>
class StaticQueue
{
public:
    bool push(T &item)
    {
        std::unique_lock<std::mutex> lock(mutex_);
        if (count_ == Capacity)
        {
            return false;
        }
        buffer_[tail_] = std::move(item);
        tail_ = (tail_ + 1) % Capacity;
        // cond_.notify_one();
        ++count_;
        return true;
    }

    bool pop(T &item)
    {
        std::unique_lock<std::mutex> lock(mutex_);
        // cond_.wait(lock, [this]
        //            { return count_ > 0; });
        item = std::move(buffer_[head_]);
        head_ = (head_ + 1) % Capacity;
        --count_;
        return true;
    }

    bool isEmpty() const
    {
        std::lock_guard<std::mutex> lock(mutex_);
        return count_ == 0;
    }

    size_t size() const
    {
        std::lock_guard<std::mutex> lock(mutex_);
        return count_;
    }

    void clear()
    {
        std::lock_guard<std::mutex> lock(mutex_);
        head_ = 0;
        tail_ = 0;
        count_ = 0;
    }

private:
    std::array<T, Capacity> buffer_;
    size_t head_ = 0;
    size_t tail_ = 0;
    size_t count_ = 0;
    mutable std::mutex mutex_;
    mutable std::condition_variable cond_;
};
