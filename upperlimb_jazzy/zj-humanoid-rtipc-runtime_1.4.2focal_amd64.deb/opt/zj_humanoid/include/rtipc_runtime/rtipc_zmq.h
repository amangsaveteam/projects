#pragma once

#include <zmq.h>
#include "rtipc_static_queue.h"
#include "robot_rtipc.hpp"
#include "rtipc_api.h"

// #define USING_ZMQ

#include <alchemy/task.h>
#include <alchemy/sem.h>
#include <alchemy/mutex.h>

bool robotIddpZmqInit(void);
bool robotIddpZmqDeinit(void);
bool robotIddpZmqPush(struct iddp_msg_t &message);
bool robotIddpZmqPop(struct iddp_msg_t &outMessage);