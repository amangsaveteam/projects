#ifndef _ROBOT_RTIPC_H_
#define _ROBOT_RTIPC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "rtipc_common.h"
#include <stdbool.h>

void robot_iddp_init(void);
void robot_iddp_Deinit(void);
bool robot_iddp_getRunVar(void);
bool robot_iddp_setAlgoStart(bool start);

#if (ROBOT_TYPE == IDDP_TYPE_ARM)
#include "UplimbController.h"
bool robot_iddp_getArmState(UPLIMB_INPUT_INFO_STRUCT *state);
bool robot_iddp_getArmCmd(UPLIMB_OUTPUT_INFO_STRUCT *cmd);
bool robot_iddp_getArmVar(UPLIMB_VAR_OBSERVE *info);
bool robot_iddp_setArmDriver(UPLIMB_OUTPUT_INFO_STRUCT *cmd);

#elif (ROBOT_TYPE == XDDP_TYPE_HAND)
bool robot_iddp_getHandState(PD_ROBOT_HAND_UPLOAD_DATA_INFO_STRUCT &state);
bool robot_iddp_setHandDriver(PD_ROBOT_HAND_DOWNLOAD_DATA_INFO_STRUCT &cmd);

#elif (ROBOT_TYPE == IDDP_TYPE_FULL)
#include "UplimbController.h"
// #include "motion_control.h"
bool robot_iddp_getFullState(PD_ROBOT_FULL_UPLOAD_DATA_INFO_STRUCT *state);
bool robot_iddp_getFullCmd(PD_ROBOT_FULL_DOWNLOAD_DATA_INFO_STRUCT *cmd);
#endif

#ifdef __cplusplus
}
#endif

#endif